// Admin authentication helpers for KYVROXA Creatives.
//
// Simple password-based admin auth via httpOnly cookie. The password is read
// from the ADMIN_PASSWORD env var (falls back to a default for the demo).
// In production, set ADMIN_PASSWORD in .env to something strong.

import { cookies } from "next/headers";

const ADMIN_COOKIE = "kyvroxa_admin_session";
// Default password — change via ADMIN_PASSWORD env var in production
const DEFAULT_PASSWORD = "kyvroxa-admin-2024";

export function getAdminPassword(): string {
  return process.env.ADMIN_PASSWORD?.trim() || DEFAULT_PASSWORD;
}

/** Returns true if the current request carries a valid admin session cookie. */
export async function isAdmin(): Promise<boolean> {
  const cookieStore = await cookies();
  const session = cookieStore.get(ADMIN_COOKIE)?.value;
  if (!session) return false;
  // Session token = password hash-ish (simple base64 for the demo).
  // Any non-empty session that decodes to the configured password is valid.
  try {
    const decoded = Buffer.from(session, "base64").toString("utf-8");
    return decoded === getAdminPassword();
  } catch {
    return false;
  }
}

/** Sets the admin session cookie (called after a successful login). */
export async function setAdminCookie(password: string): Promise<boolean> {
  const valid = password === getAdminPassword();
  if (!valid) return false;
  const cookieStore = await cookies();
  const token = Buffer.from(password, "utf-8").toString("base64");
  cookieStore.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  });
  return true;
}

/** Clears the admin session cookie (logout). */
export async function clearAdminCookie(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(ADMIN_COOKIE);
}
