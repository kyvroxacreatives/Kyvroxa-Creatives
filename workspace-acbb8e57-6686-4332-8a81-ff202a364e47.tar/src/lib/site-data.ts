// Central editable data structure for KYVROXA Creatives.
// All services, pricing, portfolio, process steps and FAQs live here so the
// agency can update content without touching page components.

export type ServiceSlug =
  | "graphic-designing"
  | "website-designing"
  | "mobile-app-designing"
  | "video-editing"
  | "social-media-marketing"
  | "digital-marketing";

export interface PricingPackage {
  name: string;
  price: string;
  cadence?: string;
  description: string;
  features: string[];
  popular?: boolean;
}

export interface ServiceFaq {
  question: string;
  answer: string;
}

export interface ServiceData {
  slug: ServiceSlug;
  title: string;
  shortName: string;
  eyebrow: string;
  tagline: string;
  headline: string;
  description: string;
  heroVisual: string;
  services: string[];
  process: { step: string; detail: string }[];
  packages: PricingPackage[];
  exclusions?: string;
  faqs: ServiceFaq[];
  deliverables: string[];
  accent: string;
}

export const SERVICES: ServiceData[] = [
  {
    slug: "graphic-designing",
    title: "Graphic Designing",
    shortName: "Graphic Design",
    eyebrow: "BRAND IDENTITY · MARKETING GRAPHICS",
    tagline: "Design that makes your brand impossible to ignore.",
    headline: "DESIGN THAT MAKES YOUR BRAND IMPOSSIBLE TO IGNORE.",
    description:
      "We create distinctive visual identities and marketing graphics that help businesses communicate clearly, build recognition, and present themselves professionally.",
    heroVisual: "canvases",
    accent: "from-yellow-400 to-yellow-600",
    services: [
      "Logo Design and Brand Identity",
      "Social Media Post Design",
      "Carousel and Campaign Design",
      "Marketing and Advertising Creatives",
      "Brochures and Company Profiles",
      "Business Cards and Stationery",
      "Packaging and Promotional Materials",
      "Presentation and Pitch Deck Design",
      "Custom Illustrations",
    ],
    deliverables: [
      "Logo & visual identity",
      "Social media creatives",
      "Brand guideline document",
    ],
    process: [
      { step: "Discovery", detail: "We gather brand background, target audience, references, and the goals your visuals need to support." },
      { step: "Creative Direction", detail: "We define the visual language — palette, typography, layout grid, and treatment direction." },
      { step: "Initial Concepts", detail: "We deliver the first concept set. The number of concepts depends on the selected package." },
      { step: "Feedback", detail: "You review the concepts and consolidate feedback so revisions stay focused." },
      { step: "Revisions", detail: "We refine the chosen direction. Revision rounds vary per package and milestone." },
      { step: "Final Delivery", detail: "We deliver high-resolution exports plus editable source files for the agreed deliverables." },
    ],
    packages: [
      { name: "Starter Design", price: "PKR 8,000", description: "Best for individuals and small businesses starting their visual communication.", features: ["5 static social media designs", "1 consistent visual direction", "1 revision round per design", "High-resolution JPG and PNG exports", "Delivery in approximately 3–5 working days"] },
      { name: "Growth Design", price: "PKR 20,000", popular: true, description: "Best for brands requiring consistent promotional content.", features: ["12 static social media designs", "2 carousel designs of up to 5 slides each", "Consistent campaign styling", "Up to 2 revision rounds per design", "High-resolution exports and editable source files for agreed deliverables", "Delivery in approximately 7–10 working days"] },
      { name: "Premium Brand Design", price: "PKR 45,000", description: "Best for businesses seeking a more complete visual identity.", features: ["Logo and visual identity development", "Primary and secondary logo variations", "Color palette and typography guidelines", "10 social media designs", "Business card design", "Basic brand guideline document", "Up to 3 revision rounds across agreed milestones", "Delivery in approximately 12–18 working days"] },
    ],
    exclusions: "Printing, paid fonts, stock assets, complex illustrations, and additional deliverables may cost extra. Prices are starting estimates and configurable by the agency.",
    faqs: [
      { question: "Do you provide the editable source files?", answer: "Source files are included for agreed deliverables in Growth Design and Premium Brand Design packages. Starter Design exports high-resolution JPG and PNG files." },
      { question: "How many revision rounds are included?", answer: "Starter includes 1 revision round per design, Growth includes up to 2, and Premium Brand Design includes up to 3 across agreed milestones." },
      { question: "Can you work with our existing brand guidelines?", answer: "Yes. Share your guidelines and reference assets during discovery and we'll design within your existing visual system." },
      { question: "Do you handle printing?", answer: "Printing, paid fonts, and stock assets are not included in the package prices. We can recommend print partners and provide print-ready files." },
    ],
  },
  {
    slug: "website-designing",
    title: "Website Designing",
    shortName: "Web Design",
    eyebrow: "BUSINESS WEBSITES · LANDING PAGES",
    tagline: "Websites designed to impress. Built to perform.",
    headline: "WEBSITES DESIGNED TO IMPRESS. BUILT TO PERFORM.",
    description:
      "From professional business websites to conversion-focused landing pages, we create responsive digital experiences that communicate your value and make it easy for customers to take action.",
    heroVisual: "screens",
    accent: "from-yellow-400 to-yellow-600",
    services: [
      "Business Website Design",
      "Landing Page Design",
      "Portfolio Website Design",
      "E-commerce Website Design",
      "UI/UX Design and Wireframing",
      "Responsive Website Layouts",
      "Website Redesign",
      "Basic On-Page SEO Setup",
      "CMS-Based Website Implementation where included",
    ],
    deliverables: ["Custom responsive design", "Conversion-focused layout", "Basic on-page SEO"],
    process: [
      { step: "Discovery", detail: "We map business goals, audience, content structure, and required functionality." },
      { step: "Wireframing", detail: "We design low-fidelity layouts that define information architecture and user flow." },
      { step: "Visual Design", detail: "We craft the look and feel — typography, color, components, imagery, and motion." },
      { step: "Implementation", detail: "Where included in the package, we build, integrate CMS, connect forms, and optimize performance." },
      { step: "Review & Revisions", detail: "You review on desktop, tablet, and mobile. We refine based on focused feedback." },
      { step: "Launch", detail: "We deliver the site, hand over credentials, and provide a walkthrough of how to manage content." },
    ],
    packages: [
      { name: "Landing Page", price: "PKR 25,000", description: "A focused, single-page experience built for conversion.", features: ["One custom-designed landing page", "Up to 6 main content sections", "Responsive layout", "Contact form integration", "Basic on-page SEO setup", "2 revision rounds", "Estimated delivery: 5–8 working days"] },
      { name: "Business Website", price: "PKR 60,000", popular: true, description: "A complete multi-page presence for growing brands.", features: ["Up to 5 core pages", "Custom visual design", "Responsive desktop, tablet, and mobile layouts", "Contact form and WhatsApp integration", "Basic on-page SEO", "Basic performance optimization", "CMS setup where agreed", "2 revision rounds", "Estimated delivery: 12–18 working days"] },
      { name: "Professional Website", price: "PKR 120,000", description: "Advanced functionality for serious digital operations.", features: ["Up to 10 core pages", "Custom UI/UX design and website implementation", "CMS integration", "Advanced contact or lead-generation forms", "Blog or portfolio functionality", "Analytics integration", "Basic technical SEO and performance optimization", "3 revision rounds", "Estimated delivery: 20–30 working days"] },
    ],
    exclusions: "Domain registration, premium hosting, paid plugins, advanced e-commerce functionality, custom backend systems, and third-party subscription costs are not included unless explicitly agreed.",
    faqs: [
      { question: "Do these packages include development or only design?", answer: "Packages include both UI/UX design and website implementation. The depth of implementation (CMS setup, integrations) varies by package as listed above." },
      { question: "Will my website work on mobile?", answer: "Yes. Every package delivers responsive layouts for desktop, tablet, and mobile." },
      { question: "Do you provide hosting and domain?", answer: "Domain registration and premium hosting are separate. We can recommend reliable providers and configure deployment." },
      { question: "Can I edit content myself?", answer: "Where a CMS is included (Business and Professional packages), you'll be able to edit defined content areas. We provide a walkthrough at handoff." },
    ],
  },
  {
    slug: "mobile-app-designing",
    title: "Mobile App Designing",
    shortName: "Mobile App Design",
    eyebrow: "UI/UX · PROTOTYPES · DESIGN SYSTEMS",
    tagline: "Mobile experiences people love to use.",
    headline: "MOBILE EXPERIENCES PEOPLE LOVE TO USE.",
    description:
      "We design intuitive, attractive mobile experiences that make complex journeys feel simple, helping businesses transform ideas into clear, usable digital products.",
    heroVisual: "phone",
    accent: "from-yellow-400 to-yellow-600",
    services: [
      "Mobile App UI/UX Design",
      "User Research and User Flows",
      "Wireframes and Prototypes",
      "iOS and Android Interface Design",
      "E-commerce App Design",
      "Booking and Service Apps",
      "Dashboard and SaaS Mobile Interfaces",
      "Design Systems and UI Components",
      "Interactive Prototypes for Testing",
    ],
    deliverables: ["User flows & wireframes", "High-fidelity UI design", "Interactive Figma prototype"],
    process: [
      { step: "Research & Flows", detail: "We define user journeys, primary tasks, and the architecture of each screen." },
      { step: "Wireframes", detail: "Low-fidelity screens confirm structure and flow before visual work begins." },
      { step: "UI Design", detail: "We design high-fidelity screens with a cohesive visual language and reusable components." },
      { step: "Prototype", detail: "We connect key flows into an interactive prototype you can click through and test." },
      { step: "Review & Revisions", detail: "We refine based on focused feedback. Revision rounds vary by package." },
      { step: "Developer Handoff", detail: "We deliver organized Figma files, specs, and a clean developer handoff." },
    ],
    packages: [
      { name: "App Starter", price: "PKR 35,000", description: "For early-stage concepts that need clear visual direction.", features: ["Up to 8 unique mobile screens", "Basic user flow", "Low- and high-fidelity interface design", "One visual direction", "2 revision rounds", "Figma handoff", "Estimated delivery: 7–10 working days"] },
      { name: "App Growth", price: "PKR 75,000", popular: true, description: "For apps that need depth, polish, and a system behind them.", features: ["Up to 20 unique mobile screens", "User flows and wireframes", "Custom UI design system", "Clickable prototype", "Core empty, loading, and error states where required", "2 revision rounds", "Developer handoff", "Estimated delivery: 12–18 working days"] },
      { name: "App Professional", price: "PKR 150,000", description: "For production-grade products with detailed journeys.", features: ["Up to 40 unique mobile screens", "Detailed user journeys", "Advanced UI/UX design", "Reusable component library", "Interactive prototype", "Responsive considerations for supported devices", "Usability review", "3 revision rounds", "Detailed developer handoff", "Estimated delivery: 20–30 working days"] },
    ],
    exclusions: "These packages cover design and prototyping only, not native app development, backend engineering, app-store publication, or ongoing maintenance.",
    faqs: [
      { question: "Do you build the app or only design it?", answer: "These packages cover UI/UX design and prototyping only. Native development, backend, and app-store publication are separate engagements." },
      { question: "Which tools do you use?", answer: "We design in Figma and deliver an organized file with components, specs, and a developer handoff ready for engineering." },
      { question: "Do you cover both iOS and Android?", answer: "Yes. We design platform-aware interfaces following iOS and Android conventions where relevant." },
      { question: "Can you design an e-commerce app?", answer: "Absolutely. E-commerce app design is one of our specialty areas, including catalog, cart, checkout, and account flows." },
    ],
  },
  {
    slug: "video-editing",
    title: "Video Editing",
    shortName: "Video Editing",
    eyebrow: "SHORT-FORM · MOTION GRAPHICS · AD CREATIVES",
    tagline: "Every second has a purpose.",
    headline: "EVERY SECOND HAS A PURPOSE.",
    description:
      "We transform raw footage into polished, engaging video content designed to communicate your message, strengthen your brand, and capture attention across digital platforms.",
    heroVisual: "timeline",
    accent: "from-yellow-400 to-yellow-600",
    services: [
      "Short-Form Social Media Videos",
      "Reels and Shorts Editing",
      "Promotional and Brand Videos",
      "YouTube Video Editing",
      "Product Videos",
      "Motion Graphics and Titles",
      "Subtitles and Captions",
      "Basic Color Correction and Audio Cleanup",
      "Video Ad Creatives",
    ],
    deliverables: ["Punchy short-form edits", "Branded motion graphics", "Platform-ready exports"],
    process: [
      { step: "Brief & Assets", detail: "You share raw footage, brand assets, references, and the message you want to land." },
      { step: "Story & Pacing", detail: "We shape a narrative spine — opening hook, key beats, and call to action." },
      { step: "Edit", detail: "We cut, color, and clean audio so the video feels tight and intentional." },
      { step: "Motion Graphics", detail: "Where included, we add branded titles, captions, and motion elements." },
      { step: "Review & Revisions", detail: "You review the cut. Revision rounds vary per package." },
      { step: "Platform Exports", detail: "We export in the agreed formats and aspect ratios for each platform." },
    ],
    packages: [
      { name: "Short-Form Starter", price: "PKR 10,000", description: "A quick-turnaround package for social-first video content.", features: ["4 short-form videos", "Up to 30 seconds per video", "Basic cuts and transitions", "Music and simple captions", "1 revision round per video", "Estimated delivery: 4–6 working days"] },
      { name: "Content Creator", price: "PKR 25,000", popular: true, description: "For creators who need consistent, branded output.", features: ["10 short-form videos", "Up to 60 seconds per video", "Branded captions and motion elements", "Basic color correction and audio cleanup", "Platform-ready exports", "2 revision rounds per video", "Estimated delivery: 7–12 working days"] },
      { name: "Brand Video Pro", price: "PKR 55,000", description: "For promotional videos with production polish.", features: ["4 professionally edited promotional videos", "Up to 90 seconds per video", "Advanced pacing and storytelling", "Custom motion graphics and branded titles", "Color grading and audio enhancement", "Multiple agreed export formats", "2 revision rounds per video", "Estimated delivery: 10–18 working days"] },
    ],
    exclusions: "The client must supply footage and necessary assets unless otherwise agreed. Advanced animation, filming, voice-over talent, premium stock footage, and extensive AI-generated video production may require additional fees.",
    faqs: [
      { question: "Do you provide the raw footage?", answer: "Clients supply footage and necessary assets unless we agree otherwise in writing. We can recommend shooters and stock libraries when needed." },
      { question: "Can you add captions and subtitles?", answer: "Yes. Captions and subtitles are included in the Content Creator and Brand Video Pro packages; Starter includes simple captions only." },
      { question: "Do you handle filming or voice-overs?", answer: "Filming, professional voice-over talent, and premium stock footage are not included and would be quoted separately." },
      { question: "Which platforms do you export for?", answer: "We deliver platform-ready exports for Instagram, TikTok, YouTube, and other agreed channels in the required aspect ratios." },
    ],
  },
  {
    slug: "social-media-marketing",
    title: "Social Media Marketing",
    shortName: "Social Media",
    eyebrow: "CONTENT STRATEGY · COMMUNITY · CAMPAIGNS",
    tagline: "Turn scrolls into meaningful connections.",
    headline: "TURN SCROLLS INTO MEANINGFUL CONNECTIONS.",
    description:
      "We help brands build a consistent social presence through strategic content planning, professional creative production, and platform-specific communication.",
    heroVisual: "network",
    accent: "from-yellow-400 to-yellow-600",
    services: [
      "Social Media Strategy",
      "Monthly Content Calendars",
      "Post and Carousel Design",
      "Caption Writing",
      "Brand Consistency",
      "Content Scheduling and Publishing",
      "Community Management where contracted",
      "Monthly Performance Reporting",
      "Campaign Creative Development",
    ],
    deliverables: ["Monthly content calendar", "On-brand post & carousel design", "Monthly performance report"],
    process: [
      { step: "Audit & Strategy", detail: "We review current channels, audience, and competitors, then set a clear content strategy." },
      { step: "Content Calendar", detail: "We map themes, post types, and captions across the month, aligned to your goals." },
      { step: "Creative Production", detail: "We design posts and carousels in your visual system with platform-aware formatting." },
      { step: "Scheduling & Publishing", detail: "We schedule and publish content at agreed times across contracted platforms." },
      { step: "Community", detail: "Where contracted, we respond to messages and comments within a defined allowance." },
      { step: "Reporting", detail: "We deliver a monthly summary or detailed analytics report depending on the package." },
    ],
    packages: [
      { name: "Social Starter", price: "PKR 25,000", cadence: "/month", description: "A focused single-platform presence.", features: ["Management of 1 social platform", "12 static posts per month", "Basic captions and hashtags", "Monthly content calendar", "Scheduling and publishing", "Monthly summary report", "1 monthly strategy call"] },
      { name: "Social Growth", price: "PKR 45,000", cadence: "/month", popular: true, description: "Scale content depth and add a second platform.", features: ["Management of up to 2 social platforms", "16 static posts per month", "4 carousel posts per month, up to 5 slides each", "Captions and content calendar", "Scheduling and publishing", "Monthly performance report", "Community management up to an agreed monthly time allowance", "2 strategy calls per month"] },
      { name: "Social Premium", price: "PKR 80,000", cadence: "/month", description: "Multi-platform content engine with video.", features: ["Management of up to 3 social platforms", "20 static posts per month", "4 carousel posts per month", "4 short-form edited videos using client-supplied footage", "Monthly campaign planning", "Scheduling and publishing", "Defined community management allowance", "Detailed monthly analytics report", "Monthly strategy meeting"] },
    ],
    exclusions: "Ad spend, influencer fees, professional photography, on-location filming, and additional platforms are not included unless explicitly specified. Follower growth, virality, leads, and sales cannot be guaranteed.",
    faqs: [
      { question: "Can you guarantee follower growth or sales?", answer: "No. Organic social media results depend on many variables outside our control. We focus on consistent, professional, on-strategy content." },
      { question: "Do you handle paid ads?", answer: "Paid advertising is handled under our Digital Media Marketing service. Social Media Marketing focuses on organic content and community." },
      { question: "Who writes the captions?", answer: "We write captions in your brand voice. You can review and approve before publishing." },
      { question: "Can you produce video for social?", answer: "Yes — the Social Premium package includes 4 short-form edited videos using client-supplied footage." },
    ],
  },
  {
    slug: "digital-marketing",
    title: "Digital Media Marketing",
    shortName: "Digital Marketing",
    eyebrow: "PAID ADS · ANALYTICS · OPTIMIZATION",
    tagline: "Smarter campaigns. Clearer performance.",
    headline: "SMARTER CAMPAIGNS. CLEARER PERFORMANCE.",
    description:
      "We help businesses reach the right audiences through structured digital campaigns, creative testing, analytics, and data-informed optimization.",
    heroVisual: "dashboard",
    accent: "from-yellow-400 to-yellow-600",
    services: [
      "Paid Social Advertising",
      "Meta Ads Campaign Management",
      "Google Ads Management",
      "Campaign Strategy and Setup",
      "Audience and Keyword Research",
      "Landing Page Recommendations",
      "Conversion Tracking Setup",
      "Campaign Creative Testing",
      "Retargeting Setup where technically available",
      "Performance Reporting",
    ],
    deliverables: ["Campaign strategy & setup", "Conversion tracking", "Monthly performance report"],
    process: [
      { step: "Goals & Tracking", detail: "We define the conversion events, tracking setup, and success metrics before spend begins." },
      { step: "Audience & Creative", detail: "We research audiences and produce the ad creative variations needed for clean testing." },
      { step: "Launch", detail: "We build, configure, and launch campaigns across the contracted platforms." },
      { step: "Optimization", detail: "We monitor performance, pause underperformers, and reallocate budget to what works." },
      { step: "Creative Testing", detail: "We run structured creative tests to find the angles that move your metrics." },
      { step: "Reporting", detail: "We deliver a monthly report with recommendations for the next cycle." },
    ],
    packages: [
      { name: "Campaign Launch", price: "PKR 20,000", cadence: "/month", description: "For a single-platform paid campaign.", features: ["Management of 1 advertising platform", "1 campaign setup or restructuring", "Up to 3 ad creative variations", "Basic audience or keyword research", "Conversion tracking review", "Monthly performance report"] },
      { name: "Growth Campaigns", price: "PKR 40,000", cadence: "/month", popular: true, description: "Multi-platform management with active testing.", features: ["Management of up to 2 advertising platforms", "Up to 3 active campaigns, depending on complexity", "Up to 6 ad creative variations per month", "Audience research and campaign optimization", "Conversion tracking review and agreed event setup", "Biweekly optimization checks", "Monthly reporting and recommendations"] },
      { name: "Performance Partner", price: "PKR 75,000", cadence: "/month", description: "A senior-level partnership for serious growth.", features: ["Management of up to 3 advertising platforms", "Up to 5 active campaigns, depending on complexity", "Up to 10 ad creative variations per month", "Campaign and audience strategy", "Landing page and conversion-funnel recommendations", "Tracking and analytics review", "Weekly optimization checks", "Monthly strategy meeting and performance report"] },
    ],
    exclusions: "These prices cover agency management fees, not advertising spend. Media budgets, landing page development, premium analytics tools, additional creative production, and complex tracking implementations are separate unless agreed in writing.",
    faqs: [
      { question: "Does the fee include ad spend?", answer: "No. Package prices cover agency management fees only. Media budgets (the money paid to platforms like Meta and Google) are separate." },
      { question: "How is digital marketing different from social media marketing?", answer: "Digital Media Marketing focuses on paid campaigns, traffic acquisition, and measurement. Social Media Marketing focuses on organic content and community." },
      { question: "Do you build landing pages?", answer: "We provide landing page recommendations. Landing page development is a separate engagement under our Website Designing service." },
      { question: "Can you guarantee results?", answer: "No agency can ethically guarantee sales or ROAS. We bring structure, testing, and optimization to maximize the chance of strong performance." },
    ],
  },
];

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Services", href: "/services", hasMegaMenu: true },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Our Process", href: "/process" },
  { label: "Pricing", href: "/pricing" },
  { label: "Contact", href: "/contact" },
] as const;

export interface PortfolioItem {
  slug: string;
  title: string;
  category: string;
  categorySlug: ServiceSlug;
  status: "Concept Project" | "Live Project";
  objective: string;
  services: string[];
  outcome?: string;
  summary: string;
  accent: string;
}

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    slug: "vertex-brand-identity",
    title: "Vertex — Brand Identity System",
    category: "Brand Identity",
    categorySlug: "graphic-designing",
    status: "Concept Project",
    objective: "Build a confident, modern identity for a fictional B2B analytics startup that needed to look credible alongside legacy competitors.",
    services: ["Logo Design", "Visual Identity", "Brand Guidelines"],
    summary: "A geometric mark built from a single line that resolves into a 'V', paired with a structured wordmark and a restrained palette built around black, white, and electric yellow.",
    accent: "from-yellow-500/30 to-yellow-500/5",
  },
  {
    slug: "lumen-social-campaign",
    title: "Lumen — 30-Day Social Campaign",
    category: "Social Media Campaigns",
    categorySlug: "social-media-marketing",
    status: "Concept Project",
    objective: "Develop a month-long content engine for a fictional wellness brand that needed a recognizable, scroll-stopping presence.",
    services: ["Content Calendar", "Post Design", "Carousel Design"],
    summary: "A campaign built around three pillars — calm, energy, and ritual — expressed through a consistent grid treatment, motion-friendly carousels, and on-brand captions.",
    accent: "from-yellow-500/30 to-yellow-500/5",
  },
  {
    slug: "horizon-web-platform",
    title: "Horizon — Business Website Platform",
    category: "Website Design",
    categorySlug: "website-designing",
    status: "Concept Project",
    objective: "Replace a cluttered legacy site with a focused, conversion-led platform for a fictional B2B SaaS company.",
    services: ["UX Design", "UI Design", "Web Implementation"],
    summary: "A modular site architecture with a calm reading rhythm, a confident product hero, and clear lead-generation paths supported by accessible forms.",
    accent: "from-yellow-500/30 to-yellow-500/5",
  },
  {
    slug: "pulse-mobile-app",
    title: "Pulse — Fitness App UI/UX",
    category: "Mobile App UI/UX",
    categorySlug: "mobile-app-designing",
    status: "Concept Project",
    objective: "Design an intuitive fitness tracking experience for a fictional consumer app focused on small, sustainable habits.",
    services: ["User Flows", "UI Design", "Prototyping"],
    summary: "A focused flow from onboarding to daily check-in, with a warm but disciplined visual system, empty/loading/error states, and a reusable component library.",
    accent: "from-yellow-500/30 to-yellow-500/5",
  },
  {
    slug: "atlas-motion-graphics",
    title: "Atlas — Brand Motion Graphics",
    category: "Video Editing & Motion",
    categorySlug: "video-editing",
    status: "Concept Project",
    objective: "Produce a series of branded motion graphics that could travel across social and product surfaces for a fictional logistics brand.",
    services: ["Motion Graphics", "Branded Titles", "Short-Form Editing"],
    summary: "A set of motion templates built on a single typography system and yellow accent motion language, designed for fast, consistent content production.",
    accent: "from-yellow-500/30 to-yellow-500/5",
  },
  {
    slug: "northwind-ads",
    title: "Northwind — Paid Acquisition Pilot",
    category: "Digital Marketing Campaigns",
    categorySlug: "digital-marketing",
    status: "Concept Project",
    objective: "Structure a 60-day paid pilot for a fictional DTC brand looking to validate demand before scaling spend.",
    services: ["Meta Ads", "Conversion Tracking", "Creative Testing"],
    summary: "A clean campaign architecture with a defined testing matrix, conversion tracking setup, and a weekly optimization cadence with structured creative refreshes.",
    accent: "from-yellow-500/30 to-yellow-500/5",
  },
];

export interface ProcessStep {
  number: string;
  title: string;
  clientProvides: string;
  agencyDelivers: string;
  approvalNeeded: string;
}

export const PROCESS_STEPS: ProcessStep[] = [
  { number: "01", title: "Discovery and Brief", clientProvides: "Business background, audience, goals, references, and any existing brand assets.", agencyDelivers: "A clarified brief, success metrics, and a project scope outline.", approvalNeeded: "Brief sign-off before scope is finalized." },
  { number: "02", title: "Proposal and Scope", clientProvides: "Feedback on the proposed scope, deliverables, and timeline.", agencyDelivers: "A written proposal with scope, package, price, timeline, and exclusions.", approvalNeeded: "Proposal approval and advance payment to lock the project." },
  { number: "03", title: "Research and Strategy", clientProvides: "Access to competitors, market context, and any analytics.", agencyDelivers: "Strategy document — audience, positioning, creative direction, and plan.", approvalNeeded: "Strategy sign-off before production begins." },
  { number: "04", title: "Design and Production", clientProvides: "Content, copy, product details, footage, or data as required.", agencyDelivers: "First concepts, designs, edits, or campaign setups aligned to the strategy.", approvalNeeded: "Concept approval before refinement proceeds." },
  { number: "05", title: "Client Review and Revisions", clientProvides: "Consolidated, focused feedback within the revision window.", agencyDelivers: "Revised deliverables based on agreed revision rounds.", approvalNeeded: "Final approval before delivery or launch." },
  { number: "06", title: "Final Delivery or Launch", clientProvides: "Final approval, plus access to any required platforms.", agencyDelivers: "Final exported files, source files where agreed, or campaign go-live.", approvalNeeded: "Acceptance of final deliverables." },
  { number: "07", title: "Ongoing Support", clientProvides: "Monthly retainer confirmation where applicable (e.g. social, ads).", agencyDelivers: "Defined ongoing support — optimization, reporting, content refreshes.", approvalNeeded: "Retainer renewal at agreed intervals." },
];

export interface CompanyValue { title: string; description: string; }

export const COMPANY_VALUES: CompanyValue[] = [
  { title: "Creativity", description: "We design and produce work that earns attention and supports clear business goals." },
  { title: "Clarity", description: "We explain scope, deliverables, pricing, and timeline in plain language." },
  { title: "Reliability", description: "We commit to realistic timelines and communicate proactively throughout." },
  { title: "Collaboration", description: "We treat your feedback as part of the work, not an interruption to it." },
  { title: "Continuous Improvement", description: "We review results and refine our approach for the next cycle, every cycle." },
];

export interface Capability { label: string; }

export const CAPABILITIES: Capability[] = [
  { label: "GRAPHIC DESIGN" },
  { label: "WEB EXPERIENCES" },
  { label: "MOBILE UI/UX" },
  { label: "VIDEO PRODUCTION" },
  { label: "SOCIAL MEDIA" },
  { label: "DIGITAL MARKETING" },
];

export interface Differentiator { title: string; description: string; }

export const DIFFERENTIATORS: Differentiator[] = [
  { title: "Creative thinking with business objectives in mind", description: "Every visual decision is anchored to a business outcome — not just aesthetics." },
  { title: "Consistent, professional brand presentation", description: "We design systems, not one-offs, so your brand stays coherent across surfaces." },
  { title: "Tailored solutions, not generic templates", description: "Each engagement starts from your brief — never a templated starting point." },
  { title: "Transparent project scope and pricing", description: "You know what's included, what's not, and what each phase costs before we begin." },
  { title: "Responsive communication and collaborative workflows", description: "You'll always know where the project stands and what's needed from you next." },
  { title: "Design and marketing focused on measurable goals", description: "Where results can be measured, we define what success looks like upfront." },
];

export const CONTACT_FORM_SERVICES = [
  "Graphic Designing",
  "Website Designing",
  "Mobile App Designing",
  "Video Editing",
  "Social Media Marketing",
  "Digital Media Marketing",
  "Custom Project",
] as const;

export const BUDGET_RANGES = [
  "Under PKR 15,000",
  "PKR 15,000–30,000",
  "PKR 30,000–60,000",
  "PKR 60,000–100,000",
  "PKR 100,000+",
  "Not sure yet",
] as const;

export const TIMELINE_OPTIONS = [
  "ASAP (rush)",
  "1–2 weeks",
  "3–4 weeks",
  "1–2 months",
  "Flexible",
] as const;

export function getService(slug: string): ServiceData | undefined {
  return SERVICES.find((s) => s.slug === slug);
}
