import { z } from "zod";
import {
  CONTACT_FORM_SERVICES,
  BUDGET_RANGES,
  TIMELINE_OPTIONS,
} from "@/lib/site-data";

/**
 * Shared contact form schema — used by both the client <ContactForm>
 * (via react-hook-form + zodResolver) and the server Route Handler at
 * src/app/api/contact/route.ts so validation stays in lockstep.
 *
 * Honeypot: `company_website` — must be empty. The server returns a
 * fake-success payload (`{ ok: true, spam: true }`) without persisting.
 */

export const ACCEPTED_FILE_TYPES = [
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
  "image/gif",
] as const;

export const MAX_FILE_BYTES = 5 * 1024 * 1024; // 5MB

export const contactSchema = z.object({
  fullName: z
    .string()
    .min(2, "Please enter your full name (at least 2 characters).")
    .max(80, "Please keep your name under 80 characters."),
  businessName: z
    .string()
    .max(120, "Business name is too long.")
    .optional()
    .or(z.literal("")),
  email: z
    .string()
    .min(1, "Email is required.")
    .email("Please enter a valid email address."),
  whatsapp: z
    .string()
    .max(40, "Phone number is too long.")
    .optional()
    .or(z.literal("")),
  service: z.enum(CONTACT_FORM_SERVICES, {
    error: "Please choose a service.",
  }),
  budget: z.enum(BUDGET_RANGES, {
    error: "Please select a budget range.",
  }),
  timeline: z.enum(TIMELINE_OPTIONS, {
    error: "Please select a timeline.",
  }),
  description: z
    .string()
    .min(30, "Please describe your project in at least 30 characters.")
    .max(4000, "Project description is too long (max 4000 characters)."),
  // honeypot — server-side silent rejection. The schema accepts any string
  // (so a bot filling it doesn't trigger a 422) and the API decides whether
  // to silently drop the submission.
  company_website: z.string().optional().or(z.literal("")),
});

export type ContactInput = z.infer<typeof contactSchema>;

/** Result of running the contact API. */
export type ContactApiResult =
  | { ok: true; id: string }
  | { ok: true; spam: true }
  | { ok: false; errors: { field: string; message: string }[] };
