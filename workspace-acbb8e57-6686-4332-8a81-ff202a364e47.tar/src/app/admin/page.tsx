import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/admin";
import { PageShell } from "@/components/site/page-shell";
import { Eyebrow } from "@/components/site/reveal";
import { AdminClient } from "./admin-client";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata: Metadata = {
  title: "Admin",
  description: "KYVROXA Creatives admin access.",
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  const loggedIn = await isAdmin();

  // If logged in, show the logged-in client (with logout button).
  // If not, show the login client.
  return (
    <PageShell>
      <section className="relative flex min-h-[70vh] items-center justify-center overflow-hidden bg-brand-black px-4 py-20">
        <div className="pointer-events-none absolute inset-0 bg-grid opacity-20" aria-hidden="true" />
        <div className="pointer-events-none absolute inset-0 bg-spotlight" aria-hidden="true" />

        <div className="relative w-full max-w-md">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-brand-gray transition-colors hover:text-brand-yellow"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to site
          </Link>

          <div className="mt-6 rounded-2xl border border-white/10 bg-brand-charcoal p-8">
            <Eyebrow>STUDIO ACCESS</Eyebrow>
            <h1 className="mt-4 font-poster text-4xl uppercase tracking-tight text-foreground">
              {loggedIn ? "Welcome back" : "Admin Login"}
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-brand-gray">
              {loggedIn
                ? "You're signed in. Delete buttons for negative testimonials will now appear on the homepage testimonials section."
                : "Sign in to enable the admin-only delete controls on testimonials."}
            </p>

            <AdminClient loggedIn={loggedIn} />
          </div>

          <p className="mt-4 text-center text-[10px] uppercase tracking-widest text-brand-gray/60">
            Demo password: kyvroxa-admin-2024
          </p>
        </div>
      </section>
    </PageShell>
  );
}
