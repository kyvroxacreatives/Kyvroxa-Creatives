"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ShieldCheck, Loader2, LogOut } from "lucide-react";

/**
 * Client-side admin panel.
 * - If `loggedIn` is true (server-passed), shows the logged-in state with a
 *   logout button + a link to the testimonials section.
 * - Otherwise shows a password form that POSTs to /api/admin/login and
 *   reloads the page on success so the server re-evaluates the cookie.
 */
export function AdminClient({ loggedIn }: { loggedIn: boolean }) {
  const router = useRouter();
  const [password, setPassword] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data?.error || "Login failed.");
      }
      // Force a server re-render so the cookie is re-evaluated
      router.refresh();
      // Then push to /admin (which will now show the logged-in view)
      router.push("/admin");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleLogout() {
    setSubmitting(true);
    try {
      await fetch("/api/admin/logout", { method: "POST" });
      router.refresh();
      router.push("/admin");
    } finally {
      setSubmitting(false);
    }
  }

  if (loggedIn) {
    return (
      <div className="mt-6 space-y-3">
        <div className="flex items-center gap-2 rounded-lg border border-brand-yellow/30 bg-brand-yellow/10 px-4 py-3 text-xs font-semibold uppercase tracking-wider text-brand-yellow">
          <ShieldCheck className="h-4 w-4" />
          Admin mode active
        </div>
        <button
          onClick={handleLogout}
          disabled={submitting}
          className="flex w-full items-center justify-center gap-2 rounded-full border border-white/15 px-6 py-3 text-xs font-bold uppercase tracking-wider text-foreground transition-colors hover:border-brand-yellow hover:text-brand-yellow disabled:opacity-50"
        >
          {submitting ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <LogOut className="h-4 w-4" />
          )}
          Sign out
        </button>
        <Link
          href="/#testimonials"
          className="block w-full rounded-full bg-brand-yellow px-6 py-3 text-center text-xs font-bold uppercase tracking-wider text-brand-black transition-colors hover:bg-white"
        >
          Go to testimonials
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleLogin} className="mt-6 space-y-4">
      <div>
        <label
          htmlFor="password"
          className="block text-[10px] font-semibold uppercase tracking-widest text-brand-gray"
        >
          Password
        </label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-2 w-full rounded-lg border border-white/10 bg-brand-black px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-brand-yellow focus:ring-2 focus:ring-brand-yellow/30"
          placeholder="Enter admin password"
        />
      </div>
      {error && (
        <p className="text-xs text-red-300">{error}</p>
      )}
      <button
        type="submit"
        disabled={submitting}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-brand-yellow px-6 py-3 text-xs font-bold uppercase tracking-wider text-brand-black transition-colors hover:bg-white disabled:opacity-50"
      >
        {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
        Sign in
      </button>
    </form>
  );
}
