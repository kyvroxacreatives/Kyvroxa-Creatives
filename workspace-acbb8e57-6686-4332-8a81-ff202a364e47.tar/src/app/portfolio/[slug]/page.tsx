import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { PageShell } from "@/components/site/page-shell";
import {
  Eyebrow,
  Reveal,
  RevealText,
} from "@/components/site/reveal";
import { Button } from "@/components/site/button";
import { PortfolioCard } from "@/components/site/portfolio-card";
import { PORTFOLIO_ITEMS } from "@/lib/site-data";

type Params = { slug: string };

/** Pre-render all portfolio detail pages at build time. */
export function generateStaticParams(): Params[] {
  return PORTFOLIO_ITEMS.map((item) => ({ slug: item.slug }));
}

/** Per-project SEO metadata. */
export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const item = PORTFOLIO_ITEMS.find((i) => i.slug === slug);
  if (!item) {
    return {
      title: "Portfolio | KYVROXA Creatives",
    };
  }
  return {
    title: `${item.title} | Portfolio`,
    description: item.summary,
    openGraph: {
      title: `${item.title} | KYVROXA Creatives`,
      description: item.summary,
      images: [{ url: `/portfolio/${item.slug}.png` }],
    },
  };
}

export default async function PortfolioDetailPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const item = PORTFOLIO_ITEMS.find((i) => i.slug === slug);
  if (!item) {
    notFound();
  }

  // Two related items (different slug, prefer same category then fall back).
  const related = PORTFOLIO_ITEMS.filter((i) => i.slug !== item.slug)
    .sort((a, b) => {
      const aMatch = a.categorySlug === item.categorySlug ? -1 : 0;
      const bMatch = b.categorySlug === item.categorySlug ? 1 : 0;
      return aMatch + bMatch;
    })
    .slice(0, 2);

  // Generic deliverable phrases derived from the item's services list.
  const deliverables = item.services.map((s) => s);

  return (
    <PageShell>
      {/* HERO */}
      <section className="relative overflow-hidden bg-brand-black">
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-spotlight opacity-70"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-grid opacity-25"
        />
        <div className="relative mx-auto max-w-7xl px-4 pb-12 pt-16 sm:px-6 sm:pt-20 lg:px-8 lg:pb-16 lg:pt-24">
          <div className="flex flex-col gap-5">
            <Eyebrow>{item.category}</Eyebrow>
            <h1 className="font-display text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-5xl md:text-6xl">
              <RevealText text={item.title} highlightWords={item.title.split("—")[0]?.trim().split(" ").slice(-1) ?? []} />
            </h1>
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="inline-flex items-center rounded-full border border-brand-yellow/40 bg-brand-yellow/5 px-3 py-1 font-mono text-[11px] uppercase tracking-wider text-brand-yellow">
                {item.category}
              </span>
              <span className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1 font-mono text-[11px] uppercase tracking-wider text-white/75">
                {item.status}
              </span>
            </div>
            <p className="max-w-3xl text-base leading-relaxed text-brand-gray sm:text-lg">
              {item.summary}
            </p>
          </div>
        </div>
      </section>

      {/* LARGE MOCKUP SHOWCASE */}
      <section className="bg-brand-black">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
          <Reveal>
            <div className="relative aspect-[16/9] w-full overflow-hidden rounded-2xl border border-white/10 bg-brand-charcoal">
              {/* Fallback gradient layer (visible if image missing). */}
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-br from-brand-yellow/15 via-transparent to-transparent"
              />
              <Image
                src={`/portfolio/${item.slug}.png`}
                alt={item.title}
                fill
                priority
                sizes="(min-width: 1024px) 80vw, 100vw"
                className="relative object-cover"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* OVERVIEW */}
      <section className="bg-brand-charcoal">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-14 sm:px-6 lg:grid-cols-3 lg:px-8 lg:py-20">
          <Reveal>
            <div>
              <Eyebrow>BUSINESS CHALLENGE</Eyebrow>
              <p className="mt-4 text-base leading-relaxed text-white/90">
                {item.objective}
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="lg:col-span-2">
              <Eyebrow>CREATIVE STRATEGY</Eyebrow>
              <p className="mt-4 text-base leading-relaxed text-brand-gray">
                {item.summary}
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {item.services.map((s) => (
                  <span
                    key={s}
                    className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/80"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* EXECUTION */}
      <section className="bg-brand-black">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <Reveal>
            <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
              <div>
                <Eyebrow>EXECUTION</Eyebrow>
                <h2 className="mt-4 font-display text-2xl font-bold text-white sm:text-3xl">
                  How the work was approached.
                </h2>
                <p className="mt-5 text-base leading-relaxed text-brand-gray">
                  As a concept project, the execution followed our standard
                  working rhythm: discovery, creative direction, initial
                  concepts, refinement, and final delivery. Detailed production
                  notes will be added alongside verified client case studies.
                </p>
              </div>
              <div>
                <Eyebrow>DELIVERABLES</Eyebrow>
                <ul className="mt-4 flex flex-col gap-3">
                  {deliverables.map((d) => (
                    <li
                      key={d}
                      className="flex items-start gap-3 rounded-lg border border-white/8 bg-brand-charcoal p-3"
                    >
                      <span
                        aria-hidden="true"
                        className="mt-1.5 inline-block h-2 w-2 shrink-0 rounded-full bg-brand-yellow shadow-[0_0_8px_rgba(255,213,0,0.7)]"
                      />
                      <span className="text-sm leading-relaxed text-white/85">
                        {d}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* RESULTS */}
      <section className="border-t border-white/5 bg-brand-charcoal">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <Reveal>
            <Eyebrow>RESULTS</Eyebrow>
            <p className="mt-4 max-w-3xl text-base leading-relaxed text-brand-gray">
              Results are presented for verified client projects only. For this
              concept project, illustrative outcomes are not shown.
            </p>
          </Reveal>
        </div>
      </section>

      {/* RELATED */}
      <section className="bg-brand-black">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <Reveal>
            <div className="mb-8 flex items-end justify-between">
              <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
                Related Projects
              </h2>
              <Button href="/portfolio" variant="ghost" size="sm">
                View all
              </Button>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            {related.map((rel) => (
              <PortfolioCard key={rel.slug} item={rel} />
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="border-t border-white/5 bg-brand-charcoal">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
          <Reveal>
            <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
              <div>
                <Eyebrow>NEXT STEP</Eyebrow>
                <p className="mt-3 max-w-xl text-base leading-relaxed text-white/90">
                  Like what you see? Let&apos;s start a similar project tailored
                  to your business.
                </p>
              </div>
              <Button href="/contact" variant="primary" size="lg">
                Start a Similar Project
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
    </PageShell>
  );
}
