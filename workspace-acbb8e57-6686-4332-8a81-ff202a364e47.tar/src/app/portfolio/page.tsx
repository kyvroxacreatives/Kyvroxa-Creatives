import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import {
  Eyebrow,
  Reveal,
  RevealText,
  SectionHeading,
} from "@/components/site/reveal";
import { Button } from "@/components/site/button";
import { PortfolioFilters } from "@/components/site/portfolio-filters";
import { PORTFOLIO_ITEMS } from "@/lib/site-data";

export const metadata: Metadata = {
  title: "Portfolio | Concept Projects",
  description:
    "A curated set of concept projects across brand identity, web, app, video, social, and digital marketing created to demonstrate the KYVROXA Creatives approach.",
  openGraph: {
    title: "Portfolio | KYVROXA Creatives",
    description:
      "A curated set of concept projects across brand identity, web, app, video, social, and digital marketing.",
  },
};

export default function PortfolioPage() {
  return (
    <PageShell>
      {/* Hero / heading */}
      <section className="relative overflow-hidden bg-brand-black">
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-spotlight opacity-70"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-grid opacity-30"
        />
        <div className="relative mx-auto max-w-7xl px-4 pb-12 pt-16 sm:px-6 sm:pt-20 lg:px-8 lg:pb-16 lg:pt-24">
          <SectionHeading
            eyebrow="PORTFOLIO"
            title={
              <RevealText
                text="IDEAS BUILT TO STAND OUT."
                highlightWords={["STAND OUT."]}
              />
            }
            description="A curated set of concept projects across brand identity, web, app, video, social, and digital marketing."
          />
        </div>
      </section>

      {/* Filters + grid */}
      <section className="relative bg-brand-black">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
          <Reveal>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-4">
              <Eyebrow>SELECTED WORK</Eyebrow>
              <span className="font-mono text-xs uppercase tracking-wider text-brand-gray">
                {PORTFOLIO_ITEMS.length} projects · all concept
              </span>
            </div>
          </Reveal>
          <PortfolioFilters items={PORTFOLIO_ITEMS} />
        </div>
      </section>

      {/* Note + CTA */}
      <section className="relative border-t border-white/5 bg-brand-charcoal">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
          <Reveal>
            <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
              <p className="max-w-2xl text-sm leading-relaxed text-brand-gray">
                These are illustrative concept projects created to demonstrate
                our creative approach. Verified client case studies will be
                added as they become available.
              </p>
              <Button href="/contact" variant="outline" size="md">
                Start a Similar Project
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
    </PageShell>
  );
}
