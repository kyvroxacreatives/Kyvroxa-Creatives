import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import {
  Eyebrow,
  Reveal,
  RevealText,
  SectionHeading,
} from "@/components/site/reveal";
import { Scene3D } from "@/components/site/scene-3d";
import { Button } from "@/components/site/button";
import { ProjectChecklist } from "@/components/site/project-checklist";
import { PROCESS_STEPS } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Our Process | How We Work",
  description:
    "The seven-step KYVROXA Creatives process — from discovery and brief, to proposal, research, design, revisions, final delivery, and ongoing support.",
  openGraph: {
    title: "Our Process | KYVROXA Creatives",
    description:
      "From inquiry to launch — how we move from brief to delivery, with clarity at every step.",
  },
};

export default function ProcessPage() {
  return (
    <PageShell>
      {/* HERO */}
      <section className="relative isolate overflow-hidden bg-brand-black">
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-spotlight opacity-70"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-grid opacity-25"
        />
        {/* 3D scene behind hero */}
        <Scene3D
          kind="home-hero"
          className="pointer-events-none absolute inset-0 z-0 opacity-50"
        />
        <div className="relative z-10 mx-auto max-w-7xl px-4 pb-20 pt-16 sm:px-6 sm:pt-20 lg:px-8 lg:pb-28 lg:pt-24">
          <div className="max-w-4xl">
            <Eyebrow>OUR PROCESS</Eyebrow>
            <h1 className="mt-6 font-poster text-5xl uppercase leading-[0.95] tracking-tight text-white sm:text-6xl md:text-7xl">
              <RevealText
                text="FROM INQUIRY TO LAUNCH."
                highlightWords={["LAUNCH."]}
              />
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
              A clear, repeatable process that keeps scope, timeline, and
              approvals visible from the first conversation to ongoing support.
            </p>
          </div>
        </div>
      </section>

      {/* TIMELINE */}
      <section className="relative bg-brand-black">
        <div
          aria-hidden="true"
          className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-white/10 to-transparent md:block"
        />
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <ol className="flex flex-col gap-12 md:gap-20">
            {PROCESS_STEPS.map((step, idx) => {
              const isRight = idx % 2 === 1;
              return (
                <li
                  key={step.number}
                  className={cn(
                    "relative flex flex-col md:flex-row md:items-center md:gap-10",
                    isRight && "md:flex-row-reverse",
                  )}
                >
                  {/* Big yellow number */}
                  <div
                    className={cn(
                      "mb-4 flex items-center md:mb-0 md:w-1/2",
                      isRight
                        ? "md:justify-start"
                        : "md:justify-end",
                    )}
                  >
                    <Reveal>
                      <div className="flex items-center gap-4">
                        <span
                          className={cn(
                            "font-poster text-7xl leading-none text-brand-yellow drop-shadow-[0_0_20px_rgba(255,213,0,0.35)] sm:text-8xl md:text-9xl",
                          )}
                        >
                          {step.number}
                        </span>
                      </div>
                    </Reveal>
                  </div>

                  {/* Card */}
                  <div className="md:w-1/2">
                    <Reveal delay={0.05}>
                      <article className="rounded-2xl border border-white/8 bg-brand-charcoal p-6 transition-colors hover:border-white/15 sm:p-8">
                        <h3 className="font-display text-xl font-bold text-white sm:text-2xl">
                          {step.title}
                        </h3>
                        <dl className="mt-5 flex flex-col gap-4">
                          <StepRow
                            label="What you provide"
                            value={step.clientProvides}
                          />
                          <StepRow
                            label="What we deliver"
                            value={step.agencyDelivers}
                          />
                          <StepRow
                            label="Approval needed"
                            value={step.approvalNeeded}
                            highlight
                          />
                        </dl>
                      </article>
                    </Reveal>
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </section>

      {/* CHECKLIST */}
      <section className="border-t border-white/5 bg-brand-charcoal">
        <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <div className="mb-8">
            <SectionHeading
              eyebrow="BEFORE WE BEGIN"
              title={
                <RevealText
                  text="PREPARE A SHARP BRIEF."
                  highlightWords={["SHARP."]}
                />
              }
              description="Use this checklist to gather what we'll need before kickoff. Tick items off as you go, then print or share with your team."
            />
          </div>
          <ProjectChecklist />
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="border-t border-white/5 bg-brand-black">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
          <Reveal>
            <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <Eyebrow>READY?</Eyebrow>
                <h2 className="mt-3 font-display text-2xl font-bold text-white sm:text-3xl">
                  Let&apos;s start a project.
                </h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-brand-gray">
                  Submit a brief and we&apos;ll come back within 1–2 working
                  days with the next step.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Button href="/contact" variant="primary" size="lg">
                  Start a Project
                </Button>
                <Button href="/pricing" variant="outline" size="lg">
                  See Pricing
                </Button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </PageShell>
  );
}

function StepRow({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5 border-l-2 border-white/8 pl-4">
      <dt
        className={cn(
          "font-mono text-[11px] uppercase tracking-[0.2em]",
          highlight ? "text-brand-yellow" : "text-brand-gray",
        )}
      >
        {label}
      </dt>
      <dd className="text-sm leading-relaxed text-white/85">{value}</dd>
    </div>
  );
}
