import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono, Anton } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
});

const anton = Anton({
  variable: "--font-anton",
  subsets: ["latin"],
  weight: "400",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://kyvroxa.com"),
  title: {
    default: "KYVROXA Creatives | Graphic Design & Digital Creative Studio",
    template: "%s | KYVROXA Creatives",
  },
  description:
    "KYVROXA Creatives is a creative studio specializing in graphic design, branding, UI/UX design, web design, social media marketing, video editing, and creative digital solutions.",
  keywords: [
    "KYVROXA Creatives",
    "creative agency",
    "graphic design",
    "branding",
    "web design",
    "mobile app design",
    "video editing",
    "social media marketing",
    "digital marketing",
  ],
  authors: [{ name: "KYVROXA Creatives" }],
  creator: "KYVROXA Creatives",
  icons: {
    icon: "/logo.png",
    apple: "/logo.png",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://kyvroxa.com",
    siteName: "KYVROXA Creatives",
    title: "KYVROXA Creatives | Creative & Digital Studio",
    description:
      "Independent creative & digital studio. We turn creative ideas into digital impact.",
  },
  twitter: {
    card: "summary_large_image",
    title: "KYVROXA Creatives",
    description:
      "Independent creative & digital studio. We turn creative ideas into digital impact.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable} ${anton.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <Sonner />
      </body>
    </html>
  );
}
