import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { PageShell, Button, Eyebrow } from "@/components/site";
import { SERVICES } from "@/lib/site-data";

export default function ServiceNotFound() {
  return (
    <PageShell>
      <section className="relative isolate flex min-h-[80vh] items-center overflow-hidden bg-brand-black">
        {/* geometric backdrop */}
        <div className="absolute inset-0 bg-grid opacity-40" aria-hidden="true" />
        <div
          aria-hidden="true"
          className="absolute left-1/2 top-1/3 h-[60vh] w-[60vh] -translate-x-1/2 rounded-full bg-brand-yellow/10 blur-[120px]"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-b from-brand-black/60 via-brand-black/80 to-brand-black"
        />

        <div className="relative z-10 mx-auto w-full max-w-5xl px-4 py-24 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center text-center">
            <Eyebrow>ERROR 404</Eyebrow>

            {/* giant 404 in poster font */}
            <h1 className="mt-8 font-poster text-[22vw] leading-none text-white/5 sm:text-[14rem] md:text-[16rem]">
              404
            </h1>

            <p className="mt-2 font-poster text-3xl uppercase leading-[0.95] text-white sm:text-4xl md:text-5xl">
              That service doesn&apos;t exist
            </p>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-brand-gray">
              The page you tried to open isn&apos;t part of our current service
              catalogue. Here are the six disciplines we do offer — pick one to
              keep exploring.
            </p>

            {/* pills linking to all 6 services */}
            <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
              {SERVICES.map((s) => (
                <Link
                  key={s.slug}
                  href={`/services/${s.slug}`}
                  className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-brand-charcoal/60 px-4 py-2.5 text-sm text-white transition-all duration-300 hover:border-brand-yellow hover:bg-brand-yellow/[0.04] hover:text-brand-yellow"
                >
                  <span
                    aria-hidden="true"
                    className="font-mono text-xs text-brand-yellow"
                  >
                    {String(SERVICES.findIndex((x) => x.slug === s.slug) + 1).padStart(2, "0")}
                  </span>
                  {s.shortName}
                  <ArrowUpRight className="h-3.5 w-3.5 text-white/40 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-brand-yellow" />
                </Link>
              ))}
            </div>

            <div className="mt-12 flex flex-col gap-4 sm:flex-row">
              <Button href="/services" magnetic variant="primary" size="lg">
                <ArrowLeft className="h-4 w-4" />
                All Services
              </Button>
              <Button href="/" variant="outline" size="lg">
                Back to Home
              </Button>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
