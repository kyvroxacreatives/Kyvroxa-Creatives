import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageShell, ServicePageClient } from "@/components/site";
import { SERVICES, getService } from "@/lib/site-data";

/** Pre-render all 6 service pages at build time. */
export function generateStaticParams() {
  return SERVICES.map((s) => ({ slug: s.slug }));
}

/** Dynamic per-service metadata. */
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const service = getService(slug);

  if (!service) {
    return {
      title: "Service Not Found",
      description: "The service you're looking for doesn't exist.",
    };
  }

  const url = `https://kyvroxa.com/services/${service.slug}`;

  return {
    title: service.title,
    description: service.tagline,
    keywords: [
      service.shortName,
      service.title,
      "KYVROXA Creatives",
      "creative agency",
      ...service.services.slice(0, 4),
    ],
    alternates: {
      canonical: url,
    },
    openGraph: {
      type: "article",
      url,
      title: `${service.title} | KYVROXA Creatives`,
      description: service.tagline,
      siteName: "KYVROXA Creatives",
      locale: "en_US",
    },
    twitter: {
      card: "summary_large_image",
      title: `${service.title} | KYVROXA Creatives`,
      description: service.tagline,
    },
  };
}

export default async function ServiceRoutePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = getService(slug);

  if (!service) {
    notFound();
  }

  return (
    <PageShell topPad={false}>
      <ServicePageClient service={service} />
    </PageShell>
  );
}
