import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Layers, Tag, FolderOpen } from "lucide-react";
import { PageShell, Scene3D } from "@/components/site";
import {
  Button,
  Reveal,
  RevealText,
  Eyebrow,
  SectionHeading,
  ServiceCard,
} from "@/components/site";
import { SERVICES } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Services | Creative & Digital Disciplines",
  description:
    "Six disciplines under one studio: graphic designing, website designing, mobile app designing, video editing, social media marketing, and digital media marketing. Explore each service in depth.",
  alternates: {
    canonical: "https://kyvroxa.com/services",
  },
  openGraph: {
    type: "website",
    url: "https://kyvroxa.com/services",
    title: "Services | KYVROXA Creatives",
    description:
      "Six disciplines under one studio. Explore each service in depth.",
    siteName: "KYVROXA Creatives",
  },
};

const SECTION = "mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8";

const CROSS_LINKS = [
  {
    href: "/process",
    icon: Layers,
    title: "Our Process",
    description:
      "A clear, seven-step workflow from discovery to ongoing support — what you provide, what we deliver, and where approval is needed.",
  },
  {
    href: "/pricing",
    icon: Tag,
    title: "Pricing Overview",
    description:
      "Compare packages across every discipline in one place. Starting estimates, inclusions, and what's outside scope.",
  },
  {
    href: "/portfolio",
    icon: FolderOpen,
    title: "Selected Work",
    description:
      "Concept projects across brand identity, social, web, mobile, motion, and paid acquisition — see our craft in context.",
  },
];

export default function ServicesIndexPage() {
  return (
    <PageShell topPad={false}>
      {/* HERO -------------------------------------------------------------- */}
      <section className="relative isolate flex min-h-[88vh] items-center overflow-hidden bg-brand-black pt-16">
        <div className="absolute inset-0" aria-hidden="true">
          <Scene3D kind="home-hero" interactive className="opacity-70" />
        </div>
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-b from-brand-black/60 via-brand-black/70 to-brand-black"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-brand-black/80 via-transparent to-transparent"
        />

        <div className={cn(SECTION, "relative z-10 w-full py-20")}>
          <div className="max-w-4xl">
            <Reveal>
              <Eyebrow>SIX DISCIPLINES · ONE STUDIO</Eyebrow>
            </Reveal>
            <h1 className="mt-6 font-poster text-4xl uppercase leading-[0.92] text-white sm:text-5xl md:text-6xl lg:text-7xl">
              <RevealText
                text="CREATIVE SERVICES FOR EVERY STAGE OF YOUR BRAND"
                highlightWords={["CREATIVE", "EVERY", "BRAND"]}
                delay={0.15}
              />
            </h1>
            <Reveal delay={0.4}>
              <p className="mt-6 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
                From a single logo to a multi-platform content engine — KYVROXA
                covers the full creative and digital spectrum. Each service
                below includes clear scope, transparent pricing, and a defined
                process so you always know what you&apos;re paying for.
              </p>
            </Reveal>
            <Reveal delay={0.55} as="div">
              <div className="mt-8 flex flex-col gap-4 sm:flex-row">
                <Button href="/contact" magnetic variant="primary" size="lg">
                  Get a Custom Quote
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button href="#all-services" variant="outline" size="lg">
                  Browse Services
                </Button>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* STATS STRIP ------------------------------------------------------- */}
      <section className="border-y border-white/5 bg-brand-charcoal/40">
        <div
          className={cn(
            SECTION,
            "grid grid-cols-2 divide-x divide-white/8 py-8 sm:grid-cols-4",
          )}
        >
          {[
            { num: "06", label: "Disciplines" },
            { num: "07", label: "Step Process" },
            { num: "18", label: "Packages" },
            { num: "100%", label: "Transparent Scope" },
          ].map((stat) => (
            <Reveal
              key={stat.label}
              className="flex flex-col items-center gap-1 px-2 text-center"
              as="div"
            >
              <span className="font-poster text-3xl text-brand-yellow sm:text-4xl">
                {stat.num}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-brand-gray sm:text-xs">
                {stat.label}
              </span>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ALL SERVICES GRID ------------------------------------------------- */}
      <section id="all-services" className={cn(SECTION, "py-20 sm:py-24 md:py-28")}>
        <SectionHeading
          eyebrow="WHAT WE DO"
          title={<RevealText text="THE FULL CREATIVE STACK" highlightWords={["FULL", "STACK"]} />}
          description="Six interlocking services that cover brand, product, content, and growth — designed to work alone or stack into a complete creative engine."
        />

        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((svc, i) => (
            <Reveal key={svc.slug} delay={i * 0.06} className="h-full" as="div">
              <ServiceCard service={svc} index={i} />
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center" as="div">
          <Button href="/contact" magnetic variant="primary" size="lg">
            Not sure which fits? Get a recommendation
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Reveal>
      </section>

      {/* CROSS-LINKS ------------------------------------------------------- */}
      <section className="relative overflow-hidden border-t border-white/5 bg-brand-charcoal/40">
        <div className="absolute inset-0 bg-grid opacity-30" aria-hidden="true" />
        <div className={cn(SECTION, "relative z-10 py-20 sm:py-24 md:py-28")}>
          <SectionHeading
            eyebrow="KEEP EXPLORING"
            title={<RevealText text="HOW WE WORK & WHAT IT COSTS" />}
            description="Before you commit, see the process we follow on every engagement and the packages and pricing across all six services."
          />

          <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-3">
            {CROSS_LINKS.map((card, i) => {
              const Icon = card.icon;
              return (
                <Reveal key={card.href} delay={i * 0.08} className="h-full" as="div">
                  <Link
                    href={card.href}
                    className="group relative flex h-full flex-col gap-4 overflow-hidden rounded-2xl border border-white/8 bg-brand-charcoal p-6 transition-all duration-300 hover:border-brand-yellow"
                  >
                    <span
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-0 bg-gradient-to-br from-brand-yellow/10 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                    />
                    <div className="relative z-10 flex items-center justify-between">
                      <span className="flex h-11 w-11 items-center justify-center rounded-lg border border-brand-yellow/30 bg-brand-yellow/[0.06]">
                        <Icon className="h-5 w-5 text-brand-yellow" />
                      </span>
                      <ArrowUpRight className="h-5 w-5 text-white/30 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brand-yellow" />
                    </div>
                    <div className="relative z-10 flex flex-col gap-2">
                      <h3 className="font-display text-xl font-bold text-white transition-colors group-hover:text-brand-yellow">
                        {card.title}
                      </h3>
                      <p className="text-sm leading-relaxed text-brand-gray">
                        {card.description}
                      </p>
                    </div>
                  </Link>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>
    </PageShell>
  );
}
