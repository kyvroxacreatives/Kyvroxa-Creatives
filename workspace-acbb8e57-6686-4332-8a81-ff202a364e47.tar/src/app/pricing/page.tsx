import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import {
  Eyebrow,
  Reveal,
  RevealText,
} from "@/components/site/reveal";
import { Button } from "@/components/site/button";
import { PricingFilter } from "@/components/site/pricing-filter";

export const metadata: Metadata = {
  title: "Pricing | Starting Estimates in PKR",
  description:
    "Transparent starting estimates in PKR across graphic design, web design, mobile app design, video editing, social media marketing, and digital media marketing. Final quotations depend on scope, deliverables, and timeline.",
  openGraph: {
    title: "Pricing | KYVROXA Creatives",
    description:
      "Clear pricing in PKR across all six services. No surprises — every package lists what's included and what's not.",
  },
};

export default function PricingPage() {
  return (
    <PageShell>
      {/* HERO */}
      <section className="relative isolate overflow-hidden bg-brand-black">
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-spotlight opacity-70"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-grid opacity-25"
        />
        <div className="relative z-10 mx-auto max-w-7xl px-4 pb-12 pt-16 sm:px-6 sm:pt-20 lg:px-8 lg:pb-16 lg:pt-24">
          <Eyebrow>PRICING</Eyebrow>
          <h1 className="mt-6 font-poster text-5xl uppercase leading-[0.95] tracking-tight text-white sm:text-6xl md:text-7xl">
            <RevealText
              text="CLEAR PRICING. NO SURPRISES."
              highlightWords={["NO SURPRISES."]}
            />
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
            All prices are starting estimates in PKR. Final quotations depend
            on project complexity, deliverables, timeline, revisions,
            integrations, and any third-party costs. Ongoing services are billed
            monthly unless otherwise agreed.
          </p>
        </div>
      </section>

      {/* PRICING */}
      <section className="relative bg-brand-black">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <Reveal>
            <div className="mb-8 flex flex-wrap items-end justify-between gap-3">
              <Eyebrow>STARTING ESTIMATES</Eyebrow>
              <span className="font-mono text-xs uppercase tracking-wider text-brand-gray">
                PKR · Pakistan
              </span>
            </div>
          </Reveal>
          <PricingFilter />
        </div>
      </section>

      {/* CUSTOM QUOTE CTA */}
      <section className="border-t border-white/5 bg-brand-charcoal">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
          <Reveal>
            <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <Eyebrow>DON&apos;T SEE A FIT?</Eyebrow>
                <h2 className="mt-3 font-display text-2xl font-bold text-white sm:text-3xl">
                  We&apos;ll quote for your scope.
                </h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-brand-gray">
                  Tell us about your project and we&apos;ll send a tailored
                  proposal with scope, deliverables, timeline, and price.
                </p>
              </div>
              <Button href="/contact" variant="primary" size="lg">
                Get a Custom Quote
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
    </PageShell>
  );
}
