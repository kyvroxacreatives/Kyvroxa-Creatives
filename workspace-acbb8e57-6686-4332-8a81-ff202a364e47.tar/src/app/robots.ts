import type { MetadataRoute } from "next";

const BASE_URL = "https://kyvroxa.com";

/**
 * robots.txt — allow the entire public site, disallow the API layer, and
 * reference the dynamic sitemap.
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/"],
      },
    ],
    sitemap: `${BASE_URL}/sitemap.xml`,
    host: BASE_URL,
  };
}
