import { PageShell } from "@/components/site";
import { HomeClient } from "@/components/site/sections/home-client";
import { StructuredData } from "@/components/site";

export default function HomePage() {
  return (
    <PageShell topPad={false}>
      <StructuredData />
      <HomeClient />
    </PageShell>
  );
}
