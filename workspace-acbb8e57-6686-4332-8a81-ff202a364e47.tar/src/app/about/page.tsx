import type { Metadata } from "next";
import { PageShell, Reveal, RevealText, Eyebrow, Button, Scene3D, LogoSymbol } from "@/components/site";
import { COMPANY_VALUES } from "@/lib/site-data";
import { ArrowRight, Compass, Eye, Sparkles } from "lucide-react";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "KYVROXA Creatives is a creative and digital marketing studio focused on helping businesses build stronger brands and more effective digital experiences.",
  openGraph: {
    title: "About KYVROXA Creatives",
    description:
      "A creative and digital marketing studio focused on helping businesses build stronger brands and more effective digital experiences.",
  },
};

const APPROACH_PARAGRAPHS: string[] = [
  "Every engagement starts with a brief — not a template. We take the time to understand the business goal behind the project, the audience it needs to reach, and the constraints it needs to respect before any design or campaign work begins.",
  "From there we work in milestones: strategy, concept, refinement, and delivery. Each milestone has a clear deliverable, an approval point, and a focused revision window — so you always know where the project stands and what is needed from you next.",
  "Where results can be measured, we agree on what success looks like upfront. Where it cannot, we hold ourselves to clear, professional craft standards — so the work earns its place regardless of platform or channel.",
];

const VISION_PARAGRAPH =
  "We see a creative studio as a long-term partner — not a one-off vendor. Our vision is to be the studio brands return to whenever they need to communicate clearly, look credible, and grow with intent. We build systems, not one-offs, so the work we deliver today keeps producing value long after the project closes.";

export default function AboutPage() {
  return (
    <PageShell>
      {/* ---------------------------------------------------------------- */}
      {/* 1. Split-screen hero                                            */}
      {/* ---------------------------------------------------------------- */}
      <section
        aria-label="About KYVROXA Creatives"
        className="relative w-full overflow-hidden border-b border-white/5 bg-brand-black px-4 pt-12 sm:pt-16 md:pt-20"
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-grid opacity-50"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-spotlight"
        />
        <div className="relative z-10 mx-auto grid w-full max-w-7xl grid-cols-1 items-center gap-10 py-12 md:grid-cols-2 md:gap-12 md:py-20">
          {/* LEFT — text */}
          <div className="flex flex-col gap-6">
            <Reveal>
              <Eyebrow>ABOUT KYVROXA CREATIVES</Eyebrow>
            </Reveal>
            <h1 className="font-display text-3xl font-bold leading-[1.05] tracking-tight text-white sm:text-4xl md:text-5xl">
              <RevealText
                text="CREATIVITY WITH A CLEAR DIRECTION."
                highlightWords={["DIRECTION."]}
              />
            </h1>
            <Reveal delay={0.1}>
              <p className="max-w-xl text-base leading-relaxed text-brand-gray sm:text-lg">
                KYVROXA Creatives is an independent creative and digital
                marketing studio. We bring together design, technology,
                content, and strategy to help businesses look credible,
                communicate clearly, and grow with intent.
              </p>
            </Reveal>
            <Reveal delay={0.18}>
              <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] uppercase tracking-[0.22em] text-white/60">
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                  Design
                </span>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                  Technology
                </span>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                  Content
                </span>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                  Marketing Strategy
                </span>
              </div>
            </Reveal>
          </div>

          {/* RIGHT — Scene3D */}
          <Reveal delay={0.12} className="flex justify-center md:justify-end">
            <div className="relative aspect-square w-full max-w-[600px] overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-brand-charcoal to-brand-black p-6">
              <Scene3D kind="about" interactive className="h-full w-full" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* 2. Mission + Vision                                             */}
      {/* ---------------------------------------------------------------- */}
      <section
        aria-labelledby="mission-vision-title"
        className="w-full bg-brand-charcoal px-4 py-20 sm:py-24 md:py-28"
      >
        <div className="mx-auto w-full max-w-7xl">
          <Reveal className="mb-10">
            <Eyebrow>MISSION &amp; VISION</Eyebrow>
          </Reveal>
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 md:gap-12">
            {/* Mission */}
            <Reveal>
              <article className="relative h-full overflow-hidden rounded-2xl border border-white/10 bg-brand-black p-6 sm:p-8">
                <span
                  aria-hidden="true"
                  className="absolute left-0 top-0 h-1 w-16 bg-brand-yellow"
                />
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full border border-brand-yellow/40 bg-brand-yellow/10 text-brand-yellow">
                    <Compass className="h-5 w-5" />
                  </span>
                  <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
                    Our Mission
                  </h2>
                </div>
                <p className="mt-5 text-base leading-relaxed text-brand-gray sm:text-[17px]">
                  KYVROXA Creatives is a creative and digital marketing agency
                  focused on helping businesses build stronger brands and more
                  effective digital experiences. We bring together design,
                  technology, content, and marketing strategy to create
                  solutions aligned with real business objectives.
                </p>
              </article>
            </Reveal>

            {/* Vision */}
            <Reveal delay={0.08}>
              <article className="relative h-full overflow-hidden rounded-2xl border border-white/10 bg-brand-black p-6 sm:p-8">
                <span
                  aria-hidden="true"
                  className="absolute left-0 top-0 h-1 w-16 bg-brand-yellow"
                />
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full border border-brand-yellow/40 bg-brand-yellow/10 text-brand-yellow">
                    <Eye className="h-5 w-5" />
                  </span>
                  <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
                    Our Vision
                  </h2>
                </div>
                <p className="mt-5 text-base leading-relaxed text-brand-gray sm:text-[17px]">
                  {VISION_PARAGRAPH}
                </p>
              </article>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* 3. Core values grid                                             */}
      {/* ---------------------------------------------------------------- */}
      <section
        aria-labelledby="core-values-title"
        className="w-full border-t border-white/5 bg-brand-black px-4 py-20 sm:py-24 md:py-28"
      >
        <div className="mx-auto w-full max-w-7xl">
          <div className="mb-10 flex flex-col gap-4">
            <Reveal>
              <Eyebrow>CORE VALUES</Eyebrow>
            </Reveal>
            <Reveal delay={0.06}>
              <h2
                id="core-values-title"
                className="font-display text-3xl font-bold leading-[1.05] tracking-tight text-white sm:text-4xl md:text-5xl"
              >
                <RevealText text="FIVE PRINCIPLES THAT GUIDE EVERY PROJECT." />
              </h2>
            </Reveal>
          </div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:gap-6 lg:grid-cols-3">
            {COMPANY_VALUES.map((value, i) => (
              <Reveal key={value.title} delay={i * 0.06}>
                <article className="group relative h-full overflow-hidden rounded-2xl border border-white/8 bg-brand-charcoal p-6 transition-colors duration-300 hover:border-brand-yellow/50">
                  <span
                    aria-hidden="true"
                    className="absolute left-0 top-0 h-full w-1 origin-top scale-y-0 bg-brand-yellow transition-transform duration-300 group-hover:scale-y-100"
                  />
                  <div className="flex items-start gap-3">
                    <span className="font-poster text-3xl text-brand-yellow sm:text-4xl">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <h3 className="mt-1 font-display text-lg font-bold leading-tight text-white">
                      {value.title}
                    </h3>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-brand-gray sm:text-[15px]">
                    {value.description}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* 4. Founder section (clearly-labeled editable placeholder)        */}
      {/* ---------------------------------------------------------------- */}
      <section
        aria-labelledby="founder-title"
        className="w-full border-t border-white/5 bg-brand-charcoal px-4 py-20 sm:py-24 md:py-28"
      >
        <div className="mx-auto w-full max-w-4xl">
          <Reveal className="mb-8 flex justify-center">
            <Eyebrow>FOUNDER</Eyebrow>
          </Reveal>

          <Reveal delay={0.05}>
            <div className="flex flex-col items-center gap-6 rounded-2xl border border-dashed border-white/15 bg-brand-black/60 p-8 text-center sm:p-10">
              {/* placeholder avatar — KC monogram on yellow circle */}
              <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-brand-yellow shadow-[0_0_40px_-8px_rgba(255,213,0,0.5)]">
                <LogoSymbol className="h-12 w-12" />
                <span
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full border border-white/10 bg-brand-charcoal px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-[0.18em] text-white/70"
                >
                  Placeholder
                </span>
              </div>

              <div className="flex flex-col items-center gap-2">
                <h2
                  id="founder-title"
                  className="font-display text-xl font-bold text-white sm:text-2xl"
                >
                  Founder Name
                </h2>
                <p className="font-mono text-xs uppercase tracking-[0.22em] text-brand-gray italic">
                  Founder &amp; Creative Lead — to be published
                </p>
              </div>

              <p className="max-w-xl text-base leading-relaxed text-brand-gray">
                Founder biography will appear here once published.
              </p>

              <p className="max-w-xl text-sm leading-relaxed text-brand-gray/80">
                This section is intentionally a placeholder. KYVROXA Creatives
                will publish a verified founder profile, photo, and biography
                here when ready. No information has been fabricated.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* 5. Approach explanation                                          */}
      {/* ---------------------------------------------------------------- */}
      <section
        aria-labelledby="approach-title"
        className="w-full border-t border-white/5 bg-brand-black px-4 py-20 sm:py-24 md:py-28"
      >
        <div className="mx-auto w-full max-w-4xl">
          <Reveal>
            <Eyebrow>OUR APPROACH</Eyebrow>
          </Reveal>
          <Reveal delay={0.06}>
            <h2
              id="approach-title"
              className="mt-4 font-display text-3xl font-bold leading-[1.05] tracking-tight text-white sm:text-4xl md:text-5xl"
            >
              <RevealText text="A DISCIPLINED PROCESS BUILT AROUND YOUR GOALS." />
            </h2>
          </Reveal>

          <div className="mt-8 flex flex-col gap-5">
            {APPROACH_PARAGRAPHS.map((p, i) => (
              <Reveal key={i} delay={0.08 + i * 0.06}>
                <p className="max-w-3xl text-base leading-relaxed text-brand-gray sm:text-lg">
                  {p}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* 6. CTA                                                           */}
      {/* ---------------------------------------------------------------- */}
      <section
        aria-labelledby="about-cta-title"
        className="relative w-full overflow-hidden border-t border-white/5 bg-brand-charcoal px-4 py-20 sm:py-24 md:py-32"
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-spotlight"
        />
        <div className="relative z-10 mx-auto flex w-full max-w-4xl flex-col items-center text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-yellow/30 bg-brand-yellow/10 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.22em] text-brand-yellow">
              <Sparkles className="h-3.5 w-3.5" />
              Let&rsquo;s talk
            </span>
          </Reveal>
          <Reveal delay={0.06}>
            <h2
              id="about-cta-title"
              className="mt-6 font-display text-3xl font-bold leading-[1.05] tracking-tight text-white sm:text-4xl md:text-5xl"
            >
              <RevealText
                text="READY TO PUT CREATIVITY TO WORK?"
                highlightWords={["WORK?"]}
              />
            </h2>
          </Reveal>
          <Reveal delay={0.12}>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
              Explore our services or start a conversation about your project.
              We&rsquo;ll bring the structure, the craft, and the business
              thinking — you bring the ambition.
            </p>
          </Reveal>
          <Reveal delay={0.18}>
            <div className="mt-9 flex flex-col items-center gap-4 sm:flex-row">
              <Button
                href="/services/graphic-designing"
                variant="primary"
                size="lg"
                magnetic
                className="w-full sm:w-auto"
              >
                Explore Services
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                href="/contact"
                variant="outline"
                size="lg"
                className="w-full sm:w-auto"
              >
                Discuss a Project
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
    </PageShell>
  );
}
