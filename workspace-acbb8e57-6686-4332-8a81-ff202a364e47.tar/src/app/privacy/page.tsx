import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage, P, Ul, Strong } from "@/components/site/legal-page";
import { ArrowUpRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How KYVROXA Creatives collects, uses, and protects your information when you use our website or work with us.",
  openGraph: {
    title: "Privacy Policy | KYVROXA Creatives",
    description:
      "How we collect, use, and protect your information.",
  },
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <LegalPage
      eyebrow="LEGAL"
      title="PRIVACY POLICY."
      highlightWords={["POLICY."]}
      intro="This Privacy Policy explains how KYVROXA Creatives collects, uses, and protects your information when you visit our website or work with us. By using this site, you agree to the practices described below."
      lastUpdated="October 2025"
      sections={[
        {
          id: "information-we-collect",
          heading: "Information We Collect",
          body: (
            <>
              <P>
                We collect only the information needed to operate our website,
                respond to inquiries, and deliver our services. This includes:
              </P>
              <Ul>
                <li>
                  <Strong>Contact information</Strong> you provide via our
                  inquiry form — full name, business or brand name, email
                  address, WhatsApp number, and any details you include in your
                  project description or attached brief.
                </li>
                <li>
                  <Strong>File metadata</Strong> when you upload a brief or
                  reference file. We record the file name, type, and size to
                  help us route your inquiry. We do not currently store the
                  file itself beyond its metadata.
                </li>
                <li>
                  <Strong>Automatic information</Strong> such as IP address,
                  browser type, pages visited, and referral source. This is
                  collected via standard server logs and analytics tools to help
                  us understand how the website is used.
                </li>
                <li>
                  <Strong>Communications</Strong> you send us by email or
                  messaging platforms. We retain those messages for as long as
                  needed to respond to you and to keep a record of our
                  engagement.
                </li>
              </Ul>
            </>
          ),
        },
        {
          id: "how-we-use-information",
          heading: "How We Use Your Information",
          body: (
            <>
              <P>
                The information we collect is used strictly to operate the
                studio. Specifically, we use it to:
              </P>
              <Ul>
                <li>Respond to your inquiry and prepare a proposal or quote.</li>
                <li>Deliver services you have engaged us for.</li>
                <li>
                  Send you project updates, deliverables, and invoices for active
                  engagements.
                </li>
                <li>
                  Improve the website, fix bugs, and analyze usage patterns in
                  aggregate (not linked to your identity).
                </li>
                <li>
                  Meet our legal, accounting, and record-keeping obligations.
                </li>
              </Ul>
              <P>
                We never sell your personal information. We do not share it with
                third parties for their own marketing purposes.
              </P>
            </>
          ),
        },
        {
          id: "cookies-and-analytics",
          heading: "Cookies and Analytics",
          body: (
            <>
              <P>
                This website may use cookies and similar technologies to keep
                the site working and to understand how it is used.
              </P>
              <Ul>
                <li>
                  <Strong>Essential cookies</Strong> are required for the site
                  to function (for example, remembering your admin session if
                  you are signed in to studio controls).
                </li>
                <li>
                  <Strong>Analytics</Strong> may be configured to understand
                  traffic patterns in aggregate. Where analytics is enabled, it
                  is configured to anonymize IP addresses where possible.
                </li>
              </Ul>
              <P>
                You can disable cookies in your browser settings; the public
                parts of the site will continue to work normally.
              </P>
            </>
          ),
        },
        {
          id: "data-sharing",
          heading: "When We Share Your Information",
          body: (
            <>
              <P>
                We only share your information in a small number of clearly
                defined situations:
              </P>
              <Ul>
                <li>
                  With <Strong>service providers</Strong> we use to operate the
                  business (for example hosting, email, or accounting tools).
                  These providers are bound by their own privacy obligations and
                  only receive the data they need to perform their service.
                </li>
                <li>
                  When <Strong>legally required</Strong> — for example in
                  response to a valid legal request, or to protect the rights,
                  property, or safety of KYVROXA Creatives, our clients, or
                  others.
                </li>
                <li>
                  With <Strong>your explicit consent</Strong> — for example, if
                  you ask us to coordinate with another vendor on your project.
                </li>
              </Ul>
              <P>
                We never sell your personal information to anyone.
              </P>
            </>
          ),
        },
        {
          id: "data-retention",
          heading: "Data Retention",
          body: (
            <>
              <P>
                We retain personal information only for as long as needed to
                fulfill the purposes described in this policy or to meet legal
                and accounting obligations. Specifically:
              </P>
              <Ul>
                <li>
                  Inquiries submitted through the contact form are retained for
                  as long as we may need them to respond to you, and for a
                  reasonable period afterward for record-keeping.
                </li>
                <li>
                  Active client records are retained for the duration of the
                  engagement plus the period required by applicable tax and
                  accounting law.
                </li>
                <li>
                  Server log and analytics data is retained in aggregate form
                  for a limited period and then deleted or anonymized.
                </li>
              </Ul>
              <P>
                If you would like us to delete your inquiry record early, you
                can request this by email and we will action it within a
                reasonable timeframe, subject to any legal retention
                obligations.
              </P>
            </>
          ),
        },
        {
          id: "your-rights",
          heading: "Your Rights",
          body: (
            <>
              <P>
                Depending on where you live, you may have rights regarding your
                personal information, including:
              </P>
              <Ul>
                <li>
                  <Strong>Access</Strong> — request a copy of the personal
                  information we hold about you.
                </li>
                <li>
                  <Strong>Correction</Strong> — ask us to correct information
                  that is inaccurate or incomplete.
                </li>
                <li>
                  <Strong>Deletion</Strong> — ask us to delete your personal
                  information, subject to legal retention obligations.
                </li>
                <li>
                  <Strong>Opt-out</Strong> — unsubscribe from marketing
                  communications at any time using the link in the email or by
                  replying to us.
                </li>
              </Ul>
              <P>
                To exercise any of these rights, email us at{" "}
                <a
                  href="mailto:kyvroxacreatives@gmail.com"
                  className="font-medium text-brand-yellow hover:underline"
                >
                  kyvroxacreatives@gmail.com
                </a>
                .
              </P>
            </>
          ),
        },
        {
          id: "security",
          heading: "Security",
          body: (
            <>
              <P>
                We take reasonable technical and organizational measures to
                protect your information, including encrypted connections
                (HTTPS), access controls, and regular reviews of how data is
                stored and accessed.
              </P>
              <P>
                No method of transmission over the internet is fully secure. We
                cannot guarantee absolute security, but we work to protect your
                information using industry-standard practices.
              </P>
            </>
          ),
        },
        {
          id: "third-party-links",
          heading: "Third-Party Links",
          body: (
            <>
              <P>
                Our website may link to third-party platforms — for example,
                our Dribbble profile, social media accounts, or tools we use to
                deliver client work. We are not responsible for the privacy
                practices of those third parties. We encourage you to read their
                privacy policies before submitting any personal information to
                them.
              </P>
            </>
          ),
        },
        {
          id: "children",
          heading: "Children's Privacy",
          body: (
            <>
              <P>
                Our services are intended for businesses and professionals. We
                do not knowingly collect personal information from children. If
                you believe a child has submitted information to us, please
                contact us and we will delete it.
              </P>
            </>
          ),
        },
        {
          id: "changes",
          heading: "Changes to This Policy",
          body: (
            <>
              <P>
                We may update this Privacy Policy from time to time to reflect
                changes in our practices, technology, or legal requirements. The
                "Last updated" date at the top of this page will always reflect
                the most recent revision. Material changes will be highlighted
                on our website or communicated directly to active clients where
                relevant.
              </P>
            </>
          ),
        },
        {
          id: "contact",
          heading: "Contact Us",
          body: (
            <>
              <P>
                If you have any questions about this Privacy Policy or how we
                handle your information, please contact us:
              </P>
              <P>
                <Strong>Email:</Strong>{" "}
                <a
                  href="mailto:kyvroxacreatives@gmail.com"
                  className="font-medium text-brand-yellow hover:underline"
                >
                  kyvroxacreatives@gmail.com
                </a>
                <br />
                <Strong>Location:</Strong> Pakistan · Remote worldwide
              </P>
            </>
          ),
        },
      ]}
      contactCta={
        <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-brand-yellow">
              Questions about privacy?
            </div>
            <p className="mt-2 text-sm text-brand-gray sm:text-base">
              Email us any time — we usually reply within 1–2 working days.
            </p>
          </div>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-brand-yellow px-6 py-3 text-xs font-bold uppercase tracking-wider text-brand-black transition-colors hover:bg-white"
          >
            Contact the studio
            <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      }
    />
  );
}
