import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage, P, Ul, Strong } from "@/components/site/legal-page";
import { ArrowUpRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "The terms and conditions that govern your use of the KYVROXA Creatives website and our creative services.",
  openGraph: {
    title: "Terms of Service | KYVROXA Creatives",
    description: "The terms that govern your use of our website and services.",
  },
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <LegalPage
      eyebrow="LEGAL"
      title="TERMS OF SERVICE."
      highlightWords={["SERVICE."]}
      intro="These Terms of Service govern your use of the KYVROXA Creatives website and the creative services we provide. By using this site or engaging us for a project, you agree to the terms below. Please read them carefully."
      lastUpdated="October 2025"
      sections={[
        {
          id: "acceptance",
          heading: "Acceptance of These Terms",
          body: (
            <>
              <P>
                By accessing this website or engaging KYVROXA Creatives
                (&ldquo;we&rdquo;, &ldquo;us&rdquo;, &ldquo;the studio&rdquo;)
                for any creative service, you confirm that you have read,
                understood, and agree to be bound by these Terms of Service. If
                you do not agree, please do not use the website or submit an
                inquiry.
              </P>
              <P>
                If you are entering into an agreement on behalf of a company,
                you represent that you have the authority to bind that company
                to these terms.
              </P>
            </>
          ),
        },
        {
          id: "services",
          heading: "Our Services",
          body: (
            <>
              <P>
                KYVROXA Creatives is an independent creative and digital
                marketing studio. We provide services including brand identity
                and graphic design, website design, mobile app UI/UX design,
                video editing, social media marketing, and digital media
                marketing.
              </P>
              <P>
                The exact scope, deliverables, timeline, and price of any
                engagement are defined in a separate written proposal or
                statement of work that we agree with you. The package
                descriptions and starting prices shown on this website are
                illustrative and not a binding offer until confirmed in a signed
                proposal.
              </P>
              <P>
                Some package descriptions explicitly exclude certain items
                (for example, printing, paid fonts, premium stock assets,
                domain registration, premium hosting, paid plugins, native app
                development, backend engineering, app-store publication, ad
                spend, influencer fees, and on-location filming). Those
                exclusions apply unless they are explicitly included in a
                signed proposal.
              </P>
            </>
          ),
        },
        {
          id: "quotes-and-scope",
          heading: "Quotes, Scope, and Revisions",
          body: (
            <>
              <P>
                All quotes provided by the studio are starting estimates. Final
                pricing depends on project complexity, deliverables, timeline,
                revision rounds, integrations, and any third-party costs.
              </P>
              <Ul>
                <li>
                  Each package includes a defined number of revision rounds.
                  Additional revisions beyond the agreed scope are billed
                  separately.
                </li>
                <li>
                  Estimates of working days are not guaranteed delivery dates.
                  We communicate timelines proactively, but external factors
                  (client feedback delays, third-party dependencies, force
                  majeure) can affect schedules.
                </li>
                <li>
                  Any change to scope after a proposal is signed will be
                  documented in writing and may affect price and timeline.
                </li>
              </Ul>
            </>
          ),
        },
        {
          id: "payment",
          heading: "Payment Terms",
          body: (
            <>
              <P>
                Payment terms for each engagement are defined in the signed
                proposal or invoice. Unless otherwise agreed in writing:
              </P>
              <Ul>
                <li>
                  A project is confirmed when an advance payment is received.
                  Work does not begin before this confirmation.
                </li>
                <li>
                  Ongoing services (for example monthly social media management
                  or digital marketing) are billed in advance for each billing
                  cycle.
                </li>
                <li>
                  Invoices are due within the timeframe stated on the invoice
                  (typically 7–14 days unless otherwise agreed).
                </li>
                <li>
                  Prices are in Pakistani Rupees (PKR) unless a different
                  currency is agreed in writing. The studio is not responsible
                  for currency conversion fees or exchange-rate fluctuations.
                </li>
              </Ul>
              <P>
                Late payments may pause ongoing work until the balance is
                settled. We will communicate proactively before pausing.
              </P>
            </>
          ),
        },
        {
          id: "client-responsibilities",
          heading: "Client Responsibilities",
          body: (
            <>
              <P>
                To deliver work on time and to standard, we rely on the client
                to:
              </P>
              <Ul>
                <li>
                  Provide accurate business background, audience, goals, and
                  references at the start of the engagement.
                </li>
                <li>
                  Share content, copy, footage, product details, brand assets,
                  or access to required platforms in a timely manner.
                </li>
                <li>
                  Provide consolidated feedback within the agreed revision
                  window so revisions stay focused.
                </li>
                <li>
                  Assign a single point of contact where possible. Multiple
                  conflicting points of contact may slow delivery.
                </li>
                <li>
                  Confirm approvals at each milestone so the next phase can
                  proceed.
                </li>
              </Ul>
              <P>
                Delays caused by late client input or feedback may extend the
                timeline and, in some cases, the price.
              </P>
            </>
          ),
        },
        {
          id: "intellectual-property",
          heading: "Intellectual Property",
          body: (
            <>
              <P>
                <Strong>Client-provided material.</Strong> You retain ownership
                of any content, logos, brand assets, footage, or data you
                provide to us. You grant us a limited license to use those
                materials for the purpose of delivering the engagement. You
                confirm you have the rights to share those materials with us.
              </P>
              <P>
                <Strong>Deliverables.</Strong> On full payment of all invoices,
                ownership of the final deliverables transfers to you, except
                for:
              </P>
              <Ul>
                <li>
                  Third-party assets (paid fonts, stock photography,
                  illustrations, plugins, libraries) — these are licensed to
                  you under their respective licenses.
                </li>
                <li>
                  Source files — included only where explicitly stated in the
                  package or proposal.
                </li>
                <li>
                  Pre-existing templates, components, or processes we built
                  before your engagement — these remain our property and are
                  licensed to you for use within the deliverable only.
                </li>
              </Ul>
              <P>
                <Strong>Portfolio use.</Strong> We reserve the right to display
                the work we create for you in our portfolio, on our website, on
                Dribbble, and on our social media profiles — unless you request
                otherwise in writing before the project starts. Confidential
                projects can be shown under a non-disclosure agreement.
              </P>
            </>
          ),
        },
        {
          id: "confidentiality",
          heading: "Confidentiality",
          body: (
            <>
              <P>
                We treat all information you share with us as confidential and
                use it only to deliver your engagement. We do not share your
                confidential information with third parties except where needed
                to deliver the work (for example with a contractor under a
                similar confidentiality obligation) or where legally required.
              </P>
              <P>
                If your project requires a formal non-disclosure agreement,
                please let us know before sharing any sensitive materials.
              </P>
            </>
          ),
        },
        {
          id: "warranties-and-liability",
          heading: "Warranties and Liability",
          body: (
            <>
              <P>
                We warrant that our work will be performed with reasonable care
                and skill, consistent with industry standards for a creative
                studio of our size.
              </P>
              <P>
                To the maximum extent permitted by law, the studio is not liable
                for:
              </P>
              <Ul>
                <li>
                  Indirect, incidental, special, or consequential damages
                  arising from the use of our work.
                </li>
                <li>
                  Business outcomes such as follower growth, virality, leads,
                  sales, or return on ad spend. We use our best efforts, but no
                  agency can ethically guarantee these outcomes.
                </li>
                <li>
                  Issues caused by third-party platforms, plugins, hosting
                  providers, ad networks, or analytics tools outside our
                  control.
                </li>
                <li>
                  Issues caused by client-provided materials that infringe the
                  rights of third parties.
                </li>
              </Ul>
              <P>
                Our total liability for any engagement is limited to the fees
                paid by you for that specific engagement.
              </P>
            </>
          ),
        },
        {
          id: "termination",
          heading: "Termination",
          body: (
            <>
              <P>
                Either party may terminate an engagement by providing written
                notice. On termination:
              </P>
              <Ul>
                <li>
                  You are responsible for payment for all work performed up to
                  the date of termination, including work in progress that has
                  not yet been delivered.
                </li>
                <li>
                  We will deliver any completed milestones that have been paid
                  for.
                </li>
                <li>
                  Ongoing services (monthly retainers) end at the end of the
                  current billing cycle unless a longer notice period is agreed
                  in the proposal.
                </li>
              </Ul>
            </>
          ),
        },
        {
          id: "website-use",
          heading: "Use of This Website",
          body: (
            <>
              <P>
                You may use this website for personal, non-commercial browsing
                and for submitting legitimate project inquiries. You agree not
                to:
              </P>
              <Ul>
                <li>
                  Attempt to access restricted areas (for example, admin
                  controls) without authorization.
                </li>
                <li>
                  Submit spam, malicious payloads, or honeypot-triggering
                  content through the contact form.
                </li>
                <li>
                  Scrape, copy, or redistribute our portfolio content without
                  permission.
                </li>
                <li>
                  Use the website in any way that could damage, overload, or
                  disrupt it.
                </li>
              </Ul>
              <P>
                We may restrict access to the website at our discretion, without
                notice, if we believe these terms are being violated.
              </P>
            </>
          ),
        },
        {
          id: "governing-law",
          heading: "Governing Law",
          body: (
            <>
              <P>
                These Terms of Service are governed by the laws of the Islamic
                Republic of Pakistan. Any disputes arising in connection with
                these terms or our services will be resolved in good faith
                through discussion first. If a formal resolution is required,
                the courts of Pakistan will have jurisdiction, unless we both
                agree to a different venue in writing.
              </P>
            </>
          ),
        },
        {
          id: "changes-to-terms",
          heading: "Changes to These Terms",
          body: (
            <>
              <P>
                We may update these Terms of Service from time to time. The
                "Last updated" date at the top of this page will reflect the
                most recent revision. For active engagements, the version of
                the Terms in force at the time of the signed proposal continues
                to apply unless both parties agree otherwise in writing.
              </P>
            </>
          ),
        },
        {
          id: "contact",
          heading: "Contact Us",
          body: (
            <>
              <P>
                If you have any questions about these Terms of Service, please
                contact us:
              </P>
              <P>
                <Strong>Email:</Strong>{" "}
                <a
                  href="mailto:kyvroxacreatives@gmail.com"
                  className="font-medium text-brand-yellow hover:underline"
                >
                  kyvroxacreatives@gmail.com
                </a>
                <br />
                <Strong>Location:</Strong> Pakistan · Remote worldwide
              </P>
            </>
          ),
        },
      ]}
      contactCta={
        <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-brand-yellow">
              Ready to start a project?
            </div>
            <p className="mt-2 text-sm text-brand-gray sm:text-base">
              Read the terms, then send us your brief — we reply within 1–2
              working days.
            </p>
          </div>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-brand-yellow px-6 py-3 text-xs font-bold uppercase tracking-wider text-brand-black transition-colors hover:bg-white"
          >
            Start a project
            <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      }
    />
  );
}
