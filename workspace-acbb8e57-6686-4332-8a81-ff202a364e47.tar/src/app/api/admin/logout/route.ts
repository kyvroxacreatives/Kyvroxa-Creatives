import { NextResponse } from "next/server";
import { clearAdminCookie } from "@/lib/admin";

/** POST /api/admin/logout — clears the admin session cookie. */
export async function POST() {
  await clearAdminCookie();
  return NextResponse.json({ ok: true });
}
