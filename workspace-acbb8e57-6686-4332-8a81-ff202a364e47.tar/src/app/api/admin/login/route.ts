import { NextResponse } from "next/server";
import { setAdminCookie } from "@/lib/admin";

/**
 * POST /api/admin/login
 *  Body: { password: string }
 *  On success: sets httpOnly cookie, returns { ok: true }
 *  On failure: 401 Unauthorized
 *
 * This is a regular Route Handler (not a server action) so it works from any
 * HTTP client — including the admin login form, curl, or programmatic tests.
 */
export async function POST(req: Request) {
  let password: string;
  try {
    const body = await req.json();
    password = String(body?.password || "");
  } catch {
    // Allow form-encoded fallback
    const text = await req.text();
    const params = new URLSearchParams(text);
    password = String(params.get("password") || "");
  }

  const ok = await setAdminCookie(password);
  if (!ok) {
    return NextResponse.json(
      { ok: false, error: "Invalid password." },
      { status: 401 },
    );
  }
  return NextResponse.json({ ok: true });
}
