import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  contactSchema,
  ACCEPTED_FILE_TYPES,
  MAX_FILE_BYTES,
  type ContactApiResult,
} from "@/lib/validations/contact";

export const runtime = "nodejs";

/**
 * POST /api/contact
 *
 * Validates the contact form payload against the shared zod schema
 * (src/lib/validations/contact.ts), persists a real Inquiry row to the
 * database via Prisma, and returns a structured JSON response.
 *
 * Responses:
 *   200 — `{ ok: true, id }`            (successful submission)
 *   200 — `{ ok: true, spam: true }`    (honeypot tripped — silent reject)
 *   422 — `{ ok: false, errors: [] }`   (validation failed, fieldErrors)
 *   500 — `{ ok: false, error: string }` (unexpected DB / server error)
 */
export async function POST(req: Request) {
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return NextResponse.json(
      { ok: false, errors: [{ field: "form", message: "Invalid request body." }] } satisfies ContactApiResult,
      { status: 422 },
    );
  }

  // Parse + validate with the shared zod schema.
  const parsed = contactSchema.safeParse(json);

  if (!parsed.success) {
    const errors = parsed.error.issues.map((issue) => ({
      field: issue.path.join(".") || "form",
      message: issue.message,
    }));
    return NextResponse.json(
      { ok: false, errors } satisfies ContactApiResult,
      { status: 422 },
    );
  }

  const data = parsed.data;

  // Honeypot — silently return success without persisting.
  if (data.company_website && data.company_website.trim().length > 0) {
    return NextResponse.json(
      { ok: true, spam: true } satisfies ContactApiResult,
      { status: 200 },
    );
  }

  // File metadata (optional). The client sends fileName + fileType + fileSize
  // (no upload happens server-side — we only record metadata).
  const fileMeta = (json as { file?: { name?: string; type?: string; size?: number } } | null)?.file;

  let fileName: string | null = null;
  if (fileMeta?.name) {
    const type = fileMeta.type ?? "";
    const size = typeof fileMeta.size === "number" ? fileMeta.size : 0;
    if (!ACCEPTED_FILE_TYPES.includes(type as (typeof ACCEPTED_FILE_TYPES)[number])) {
      return NextResponse.json(
        {
          ok: false,
          errors: [
            {
              field: "file",
              message: "Unsupported file type. Please upload a PDF or image (PNG, JPG, WEBP, GIF).",
            },
          ],
        } satisfies ContactApiResult,
        { status: 422 },
      );
    }
    if (size > MAX_FILE_BYTES) {
      return NextResponse.json(
        {
          ok: false,
          errors: [{ field: "file", message: "File exceeds the 5MB limit." }],
        } satisfies ContactApiResult,
        { status: 422 },
      );
    }
    fileName = fileMeta.name.slice(0, 200);
  }

  try {
    const inquiry = await db.inquiry.create({
      data: {
        fullName: data.fullName.trim(),
        businessName: data.businessName?.trim() || null,
        email: data.email.trim().toLowerCase(),
        whatsapp: data.whatsapp?.trim() || null,
        service: data.service,
        budget: data.budget,
        timeline: data.timeline,
        description: data.description.trim(),
        fileName,
        honeypot: null,
      },
    });

    return NextResponse.json(
      { ok: true, id: inquiry.id } satisfies ContactApiResult,
      { status: 200 },
    );
  } catch (err) {
    console.error("[contact] DB insert failed:", err);
    return NextResponse.json(
      {
        ok: false,
        errors: [
          {
            field: "form",
            message: "We couldn't save your message. Please try again or email kyvroxacreatives@gmail.com.",
          },
        ],
      } satisfies ContactApiResult,
      { status: 500 },
    );
  }
}

export async function GET() {
  return NextResponse.json({ ok: false, error: "Method not allowed." }, { status: 405 });
}
