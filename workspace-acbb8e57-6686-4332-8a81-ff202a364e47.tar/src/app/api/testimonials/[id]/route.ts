import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/admin";

/**
 * DELETE /api/testimonials/[id]
 *  - Admin-only: hard-deletes a testimonial by id.
 *  - Returns 401 if the request isn't from an authenticated admin.
 *  - Returns 404 if the testimonial doesn't exist.
 *  - The public visitors never see the delete button (it only renders when
 *    `isAdmin` is true), but we still enforce auth server-side so a curious
 *    visitor can't just curl the endpoint.
 */
export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await isAdmin();
  if (!admin) {
    return NextResponse.json(
      { ok: false, error: "Unauthorized — admin access required." },
      { status: 401 },
    );
  }

  const { id } = await params;
  const existing = await db.testimonial.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json(
      { ok: false, error: "Testimonial not found." },
      { status: 404 },
    );
  }

  await db.testimonial.delete({ where: { id } });
  return NextResponse.json({ ok: true, id });
}
