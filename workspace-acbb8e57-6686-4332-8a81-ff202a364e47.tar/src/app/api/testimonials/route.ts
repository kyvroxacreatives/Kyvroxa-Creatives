import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin } from "@/lib/admin";

/**
 * GET /api/testimonials
 *  - Public: returns approved testimonials, ordered newest-first.
 *  - Response includes `isAdmin: true/false` so the client can decide
 *    whether to render the delete button. The flag is computed server-side
 *    from the httpOnly admin cookie, so visitors can't fake it.
 */
export async function GET() {
  const admin = await isAdmin();
  const testimonials = await db.testimonial.findMany({
    where: { approved: true },
    orderBy: [{ rating: "desc" }, { createdAt: "desc" }],
  });

  return NextResponse.json({
    testimonials,
    isAdmin: admin,
  });
}
