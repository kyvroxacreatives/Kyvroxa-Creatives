import type { Metadata } from "next";
import { Mail, MapPin, Clock, ArrowUpRight, Sparkles } from "lucide-react";
import { PageShell } from "@/components/site/page-shell";
import {
  Eyebrow,
  Reveal,
  RevealText,
} from "@/components/site/reveal";
import { ContactForm } from "@/components/site/contact-form";
import { ContactAnimatedBg } from "@/components/site/contact-animated-bg";

export const metadata: Metadata = {
  title: "Contact | Start a Project",
  description:
    "Start a project with KYVROXA Creatives. Send us your brief and we'll reply within 1–2 working days with scope, timeline, and price.",
  openGraph: {
    title: "Contact | KYVROXA Creatives",
    description: "Send your brief. We reply within 1–2 working days.",
  },
};

export default function ContactPage() {
  return (
    <PageShell>
      <section className="relative isolate overflow-hidden bg-brand-black">
        {/* ---------- Clean animated background (no messy 3D circles) ---------- */}
        <ContactAnimatedBg />

        <div className="relative z-10 mx-auto max-w-6xl px-4 pb-20 pt-16 sm:px-6 sm:pt-20 lg:px-8 lg:pb-28 lg:pt-24">
          {/* ---------- Centered hero ---------- */}
          <div className="flex flex-col items-center text-center">
            <Reveal>
              <div className="inline-flex w-fit items-center gap-2 rounded-full border border-brand-yellow/30 bg-brand-yellow/10 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-yellow">
                <span className="relative inline-flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-yellow opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-yellow" />
                </span>
                Available for select projects
              </div>
            </Reveal>

            <Reveal delay={0.05}>
              <Eyebrow className="mt-6 justify-center">CONTACT</Eyebrow>
            </Reveal>

            <h1 className="mt-5 max-w-3xl font-poster text-4xl uppercase leading-[0.92] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl">
              <RevealText
                text="LET'S BUILD SOMETHING THAT MATTERS."
                highlightWords={["MATTERS."]}
              />
            </h1>

            <Reveal delay={0.12}>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-brand-gray sm:text-lg">
                Tell us about your project. We&apos;ll review your brief and
                reply within{" "}
                <span className="font-semibold text-white">1–2 working days</span>{" "}
                with scope, timeline, and price.
              </p>
            </Reveal>
          </div>

          {/* ---------- Centered form (max-w-2xl) ---------- */}
          <Reveal delay={0.15} className="mt-12">
            <div className="mx-auto max-w-2xl">
              <ContactForm />
            </div>
          </Reveal>

          {/* ---------- Contact info strip — 3 cards horizontal ---------- */}
          <Reveal delay={0.2}>
            <div className="mt-12 grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4">
              <ContactCard
                icon={<Mail className="h-4 w-4" />}
                label="Email"
                value="kyvroxacreatives@gmail.com"
                href="mailto:kyvroxacreatives@gmail.com"
              />
              <ContactCard
                icon={<MapPin className="h-4 w-4" />}
                label="Location"
                value="Pakistan · Remote worldwide"
              />
              <ContactCard
                icon={<Clock className="h-4 w-4" />}
                label="Response time"
                value="1–2 working days"
              />
            </div>
          </Reveal>

          {/* ---------- Bottom trust line ---------- */}
          <Reveal delay={0.25}>
            <div className="mt-10 flex flex-col items-center gap-3 text-center">
              <div className="inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-brand-gray/60">
                <Sparkles className="h-3 w-3 text-brand-yellow" />
                KYVROXA Creatives · Independent Studio
              </div>
              <p className="max-w-xs text-xs leading-relaxed text-brand-gray/50">
                No pressure, no obligation — just a clear conversation about
                your project.
              </p>
            </div>
          </Reveal>
        </div>
      </section>
    </PageShell>
  );
}

/* ----------------- Contact info card ----------------- */

function ContactCard({
  icon,
  label,
  value,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  href?: string;
}) {
  const cls =
    "group relative flex items-center gap-4 overflow-hidden rounded-2xl border border-white/10 bg-brand-charcoal/60 p-4 backdrop-blur-md transition-all hover:border-brand-yellow/30 hover:bg-brand-charcoal/80";

  const inner = (
    <>
      <span
        aria-hidden="true"
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-brand-yellow/40 bg-brand-yellow/10 text-brand-yellow transition-all group-hover:bg-brand-yellow group-hover:text-brand-black"
      >
        {icon}
      </span>
      <span className="flex flex-col gap-0.5 overflow-hidden">
        <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-brand-gray">
          {label}
        </span>
        <span className="truncate text-sm font-medium text-white/90">
          {value}
        </span>
      </span>
      {href && (
        <ArrowUpRight className="ml-auto h-4 w-4 shrink-0 text-brand-gray opacity-0 transition-all group-hover:opacity-100 group-hover:text-brand-yellow" />
      )}
    </>
  );

  if (href) {
    return (
      <a href={href} className={cls}>
        {inner}
      </a>
    );
  }
  return <div className={cls}>{inner}</div>;
}
