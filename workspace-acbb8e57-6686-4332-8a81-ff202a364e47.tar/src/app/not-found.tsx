import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { Scene3D } from "@/components/site/scene-3d";
import { LogoSymbol } from "@/components/site/logo";
import { Button } from "@/components/site/button";

export default function NotFound() {
  return (
    <PageShell topPad={false}>
      <section className="relative isolate flex min-h-[calc(100vh-4rem)] items-center justify-center overflow-hidden bg-brand-black px-4 py-16 sm:px-6 lg:px-8">
        {/* Decorative backdrop */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-spotlight opacity-70"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-grid opacity-25"
        />
        <Scene3D
          kind="cta"
          className="pointer-events-none absolute inset-0 z-0 opacity-40"
        />

        <div className="relative z-10 flex flex-col items-center text-center">
          {/* KC monogram */}
          <LogoSymbol className="h-12 w-12 opacity-80" />

          {/* Huge yellow 404 */}
          <p
            aria-hidden="true"
            className="mt-8 font-poster text-[28vw] leading-[0.85] text-brand-yellow drop-shadow-[0_0_60px_rgba(255,213,0,0.35)] sm:text-[20vw] md:text-[16rem] lg:text-[20rem]"
          >
            404
          </p>
          <span className="sr-only">Error 404: page not found.</span>

          <h1 className="mt-6 font-display text-3xl font-bold uppercase tracking-tight text-white sm:text-4xl md:text-5xl">
            Page Not Found
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-brand-gray sm:text-base">
            The page you&apos;re looking for doesn&apos;t exist or has moved.
            Let&apos;s get you back on track.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button href="/" variant="primary" size="lg">
              Back to Home
            </Button>
            <Link
              href="/contact"
              className="font-display text-xs uppercase tracking-wider text-white/70 underline-offset-4 hover:text-brand-yellow hover:underline"
            >
              Report an issue
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
