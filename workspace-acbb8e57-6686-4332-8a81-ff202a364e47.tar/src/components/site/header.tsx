"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, ChevronDown } from "lucide-react";
import { NAV_LINKS, SERVICES } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { Logo } from "./logo";

/**
 * Header — fixed top navigation.
 * Transparent → bg-brand-black/80 backdrop-blur on scroll.
 * Logo left, 7 NAV_LINKS center (Services has a hover mega-menu showing all 6 services),
 * "Start a Project" CTA right (desktop). Mobile hamburger with full drawer.
 */
export function Header() {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [servicesOpen, setServicesOpen] = React.useState(false);
  const pathname = usePathname();

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // close mobile menu on route change
  React.useEffect(() => {
    setMobileOpen(false);
    setServicesOpen(false);
  }, [pathname]);

  // lock body scroll when mobile menu open
  React.useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-white/5 bg-brand-black/80 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" aria-label="KYVROXA Creatives home" className="flex items-center">
          <Logo size="sm" />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {NAV_LINKS.map((link) => {
            const active =
              link.href === "/"
                ? pathname === "/"
                : pathname?.startsWith(link.href);
            if ("hasMegaMenu" in link && link.hasMegaMenu) {
              return (
                <div
                  key={link.href}
                  className="relative"
                  onMouseEnter={() => setServicesOpen(true)}
                  onMouseLeave={() => setServicesOpen(false)}
                >
                  <Link
                    href={link.href}
                    data-active={active ? "true" : "false"}
                    className={cn(
                      "link-underline inline-flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-white/85 transition-colors hover:text-white",
                      active && "text-brand-yellow",
                    )}
                  >
                    {link.label}
                    <ChevronDown
                      className={cn(
                        "h-3.5 w-3.5 transition-transform",
                        servicesOpen && "rotate-180 text-brand-yellow",
                      )}
                    />
                  </Link>
                  <AnimatePresence>
                    {servicesOpen ? (
                      <MegaMenu />
                    ) : null}
                  </AnimatePresence>
                </div>
              );
            }
            return (
              <Link
                key={link.href}
                href={link.href}
                data-active={active ? "true" : "false"}
                className={cn(
                  "link-underline inline-flex items-center rounded-md px-3 py-2 text-sm font-medium text-white/85 transition-colors hover:text-white",
                  active && "text-brand-yellow",
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        {/* CTA + hamburger */}
        <div className="flex items-center gap-2">
          <Link
            href="/contact"
            className="hidden rounded-md border border-brand-yellow bg-brand-yellow px-5 py-2.5 text-xs font-medium uppercase tracking-wider text-brand-black transition-colors hover:bg-white sm:inline-flex"
          >
            Start a Project
          </Link>
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-white/10 text-white lg:hidden"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen ? (
          <MobileDrawer pathname={pathname} />
        ) : null}
      </AnimatePresence>
    </header>
  );
}

/* -------------------------------------------------------------------------- */
/*  MegaMenu — desktop Services dropdown showing all 6 services in 2 cols     */
/* -------------------------------------------------------------------------- */

function MegaMenu() {
  return (
    <motion.div
      className="absolute left-1/2 top-full z-50 w-[640px] -translate-x-1/2 pt-3"
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className="chrome-rim overflow-hidden rounded-2xl border border-white/10 bg-brand-charcoal/95 backdrop-blur-xl">
        <div className="flex items-center justify-between border-b border-white/5 px-6 py-3">
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow">
            What we do
          </span>
          <Link
            href="/services"
            className="font-mono text-xs uppercase tracking-wider text-brand-gray transition-colors hover:text-white"
          >
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-1 p-3">
          {SERVICES.map((svc, idx) => (
            <Link
              key={svc.slug}
              href={`/services/${svc.slug}`}
              className="group flex items-start gap-3 rounded-lg p-3 transition-colors hover:bg-white/5"
            >
              <span className="font-mono text-xs text-brand-yellow">
                {String(idx + 1).padStart(2, "0")}
              </span>
              <span className="flex-1">
                <span className="block font-display text-sm font-medium text-white transition-colors group-hover:text-brand-yellow">
                  {svc.shortName}
                </span>
                <span className="mt-0.5 block text-xs text-brand-gray line-clamp-1">
                  {svc.tagline}
                </span>
              </span>
            </Link>
          ))}
        </div>
        <div className="border-t border-white/5 px-6 py-3">
          <Link
            href="/contact"
            className="font-mono text-xs uppercase tracking-wider text-white transition-colors hover:text-brand-yellow"
          >
            Not sure? Start a project →
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

/* -------------------------------------------------------------------------- */
/*  MobileDrawer — full-screen mobile nav with all 7 links + all 6 services    */
/* -------------------------------------------------------------------------- */

function MobileDrawer({ pathname }: { pathname: string | null }) {
  return (
    <motion.div
      className="lg:hidden"
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
      style={{ overflow: "hidden" }}
    >
      <div className="border-t border-white/5 bg-brand-black/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-4">
          {NAV_LINKS.map((link) => {
            const active =
              link.href === "/"
                ? pathname === "/"
                : pathname?.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "rounded-md px-3 py-3 font-display text-base font-medium transition-colors",
                  active
                    ? "bg-white/5 text-brand-yellow"
                    : "text-white/85 hover:bg-white/5 hover:text-white",
                )}
              >
                {link.label}
              </Link>
            );
          })}

          <div className="mt-3 border-t border-white/5 pt-3">
            <div className="px-3 pb-2 font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow">
              Our Services
            </div>
            <div className="flex flex-col gap-1">
              {SERVICES.map((svc, idx) => (
                <Link
                  key={svc.slug}
                  href={`/services/${svc.slug}`}
                  className="flex items-center gap-3 rounded-md px-3 py-2.5 transition-colors hover:bg-white/5"
                >
                  <span className="font-mono text-xs text-brand-gray">
                    {String(idx + 1).padStart(2, "0")}
                  </span>
                  <span className="text-sm text-white/90">{svc.shortName}</span>
                </Link>
              ))}
            </div>
          </div>

          <Link
            href="/contact"
            className="mt-4 inline-flex h-12 items-center justify-center rounded-md border border-brand-yellow bg-brand-yellow px-6 text-sm font-medium uppercase tracking-wider text-brand-black"
          >
            Start a Project
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

export default Header;
