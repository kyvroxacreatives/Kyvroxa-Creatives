"use client";

import * as React from "react";
import { motion, useInView } from "framer-motion";
import { cn } from "@/lib/utils";

/* -------------------------------------------------------------------------- */
/*  Reveal — fade-up wrapper on scroll into view                              */
/* -------------------------------------------------------------------------- */

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
  y?: number;
  duration?: number;
  once?: boolean;
  className?: string;
  as?: "div" | "section" | "article" | "li" | "span";
}

export function Reveal({
  children,
  delay = 0,
  y = 24,
  duration = 0.6,
  once = true,
  className,
  as = "div",
}: RevealProps) {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const inView = useInView(ref, { once, margin: "-80px 0px -80px 0px" });
  const MotionTag = motion[as] as typeof motion.div;

  return (
    <MotionTag
      ref={ref as React.Ref<HTMLDivElement>}
      className={className}
      initial={{ opacity: 0, y }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y }}
      transition={{
        duration,
        delay,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      {children}
    </MotionTag>
  );
}

/* -------------------------------------------------------------------------- */
/*  RevealText — staggered word-by-word reveal, highlights specified words    */
/* -------------------------------------------------------------------------- */

interface RevealTextProps {
  text: string;
  highlightWords?: string[];
  className?: string;
  delay?: number;
  wordClassName?: string;
}

export function RevealText({
  text,
  highlightWords = [],
  className,
  delay = 0,
  wordClassName,
}: RevealTextProps) {
  const ref = React.useRef<HTMLSpanElement | null>(null);
  const inView = useInView(ref, { once: true, margin: "-40px 0px -40px 0px" });
  const words = text.split(" ");

  return (
    <span ref={ref} className={cn("inline", className)}>
      {words.map((word, i) => {
        const isHighlight = highlightWords
          .map((w) => w.toLowerCase())
          .includes(word.toLowerCase().replace(/[^a-z0-9]/gi, ""));
        return (
          <span key={`${word}-${i}`} className="inline-block overflow-hidden align-baseline">
            <motion.span
              className={cn(
                "inline-block",
                isHighlight && "text-brand-yellow",
                wordClassName,
              )}
              initial={{ y: "110%", opacity: 0 }}
              animate={inView ? { y: "0%", opacity: 1 } : { y: "110%", opacity: 0 }}
              transition={{
                duration: 0.55,
                delay: delay + i * 0.06,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              {word}
              {i < words.length - 1 ? "\u00A0" : ""}
            </motion.span>
          </span>
        );
      })}
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/*  Eyebrow — small yellow label with a bullet dot                             */
/* -------------------------------------------------------------------------- */

export function Eyebrow({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow",
        className,
      )}
    >
      <span
        aria-hidden="true"
        className="inline-block h-1.5 w-1.5 rounded-full bg-brand-yellow shadow-[0_0_8px_rgba(255,213,0,0.7)]"
      />
      {children}
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/*  SectionHeading — composes Eyebrow + title + description                    */
/* -------------------------------------------------------------------------- */

interface SectionHeadingProps {
  eyebrow?: string;
  title: React.ReactNode;
  description?: string;
  align?: "left" | "center";
  className?: string;
  highlightWords?: string[];
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
  highlightWords,
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "flex flex-col gap-4",
        align === "center" && "items-center text-center",
        className,
      )}
    >
      {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}
      <h2
        className={cn(
          "font-display text-3xl font-bold leading-[1.05] tracking-tight text-white sm:text-4xl md:text-5xl",
          align === "center" && "max-w-3xl",
        )}
      >
        {typeof title === "string" ? (
          <RevealText text={title} highlightWords={highlightWords} />
        ) : (
          title
        )}
      </h2>
      {description ? (
        <p
          className={cn(
            "max-w-2xl text-base leading-relaxed text-brand-gray",
            align === "center" && "mx-auto",
          )}
        >
          {description}
        </p>
      ) : null}
    </div>
  );
}

export { Reveal as default };
