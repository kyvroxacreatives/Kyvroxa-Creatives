import Image from "next/image";
import { cn } from "@/lib/utils";

/**
 * Logo — full horizontal KYVROXA logo from /public/logo.png (661x119).
 * Server component (no interactivity). Hover handled by parent or CSS.
 */
const SIZES = {
  sm: { height: 24 },
  md: { height: 32 },
  lg: { height: 44 },
} as const;

export function Logo({
  size = "md",
  className,
}: {
  size?: keyof typeof SIZES;
  className?: string;
}) {
  const cfg = SIZES[size];
  return (
    <span
      className={cn(
        "group inline-flex items-center transition-transform duration-300 hover:scale-105",
        className,
      )}
    >
      <Image
        src="/logo.png"
        alt="KYVROXA Creatives logo"
        height={cfg.height}
        width={cfg.height * (661 / 119)}
        priority
        style={{ height: cfg.height, width: cfg.height * (661 / 119) }}
      />
    </span>
  );
}

/**
 * LogoSymbol — backup SVG KC monogram used in the Scene3D plate.
 * A square 48x48 viewBox mark: K stem with yellow accent + C curve.
 */
export function LogoSymbol({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="KYVROXA monogram"
      className={cn("block", className)}
    >
      {/* K stem */}
      <rect x="9" y="10" width="5" height="28" rx="1" fill="#FFFFFF" />
      {/* K diagonal (upper) */}
      <path d="M14 24 L29 10 H23 L14 19 Z" fill="#FFFFFF" />
      {/* K diagonal (lower) */}
      <path d="M14 24 L29 38 H23 L14 29 Z" fill="#FFFFFF" />
      {/* yellow accent dot on K */}
      <circle cx="11.5" cy="24" r="2.4" fill="#FFD500" />
      {/* C curve */}
      <path
        d="M40 16.5 C36.5 13 31.5 11.5 27.5 13 C22 15 19 21 21 27 C23 33 29 36 35 34 C37.5 33.2 39.5 31.5 40.5 29.5"
        stroke="#FFD500"
        strokeWidth="4.5"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

export default Logo;
