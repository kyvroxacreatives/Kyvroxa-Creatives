"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { cn } from "@/lib/utils";
import { LogoSymbol } from "./logo";

export type Scene3DKind =
  | "home-hero"
  | "canvases"
  | "screens"
  | "phone"
  | "timeline"
  | "network"
  | "dashboard"
  | "cta"
  | "about";

interface Scene3DProps {
  kind: Scene3DKind;
  interactive?: boolean;
  className?: string;
  /** Title used for some scenes (home-hero/about) on the monogram plate. */
  title?: string;
}

/* -------------------------------------------------------------------------- */
/*  Primitives                                                                */
/* -------------------------------------------------------------------------- */

/** ChromeSphere — yellow gradient sphere with chrome rim glow. */
function ChromeSphere({
  className,
  size = 220,
  delay = 0,
}: {
  className?: string;
  size?: number;
  delay?: number;
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("absolute rounded-full metallic-yellow", className)}
      style={{ width: size, height: size }}
      animate={{ y: [0, -16, 0] }}
      transition={{
        duration: 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0 rounded-full"
        style={{
          background:
            "radial-gradient(circle at 30% 25%, rgba(255,255,255,0.9) 0%, rgba(255,213,0,1) 30%, rgba(212,168,0,1) 70%, rgba(140,110,0,1) 100%)",
          boxShadow:
            "inset -10px -16px 30px rgba(0,0,0,0.5), inset 8px 8px 20px rgba(255,255,255,0.4), 0 30px 80px -20px rgba(255,213,0,0.5)",
        }}
      />
      {/* highlight */}
      <div
        aria-hidden="true"
        className="absolute left-1/4 top-1/5 h-1/4 w-1/3 rounded-full bg-white/50 blur-md"
      />
    </motion.div>
  );
}

/** FloatingRing — bordered yellow ring with 3D tilt. */
function FloatingRing({
  className,
  size = 160,
  delay = 0,
  thickness = 2,
}: {
  className?: string;
  size?: number;
  delay?: number;
  thickness?: number;
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("absolute rounded-full", className)}
      style={{
        width: size,
        height: size,
        border: `${thickness}px solid rgba(255,213,0,0.55)`,
        boxShadow:
          "0 0 30px rgba(255,213,0,0.25), inset 0 0 30px rgba(255,213,0,0.15)",
      }}
      animate={{ rotate: 360 }}
      transition={{
        duration: 22,
        delay,
        repeat: Infinity,
        ease: "linear",
      }}
    >
      <div
        aria-hidden="true"
        className="absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rounded-full bg-brand-yellow shadow-[0_0_12px_rgba(255,213,0,0.9)]"
      />
    </motion.div>
  );
}

/** FloatingCube — dark metallic cube with yellow edge accent. */
function FloatingCube({
  className,
  size = 64,
  delay = 0,
}: {
  className?: string;
  size?: number;
  delay?: number;
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("absolute metallic-dark rounded-md", className)}
      style={{
        width: size,
        height: size,
        boxShadow:
          "inset 0 1px 0 rgba(255,255,255,0.1), 0 20px 40px -10px rgba(0,0,0,0.8)",
      }}
      animate={{ y: [0, -14, 0], rotate: [0, 6, 0] }}
      transition={{
        duration: 5.5,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0 rounded-md border border-brand-yellow/40"
      />
      <div
        aria-hidden="true"
        className="absolute left-1.5 top-1.5 font-mono text-[10px] text-brand-yellow/80"
      >
        K
      </div>
    </motion.div>
  );
}

/** WireframeShape — SVG wireframe pyramid. */
function WireframeShape({
  className,
  size = 140,
  delay = 0,
}: {
  className?: string;
  size?: number;
  delay?: number;
}) {
  return (
    <motion.svg
      aria-hidden="true"
      viewBox="0 0 100 100"
      className={cn("absolute", className)}
      width={size}
      height={size}
      animate={{ rotate: [0, 8, 0] }}
      transition={{
        duration: 7,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      <g
        stroke="rgba(255,213,0,0.55)"
        strokeWidth="1"
        fill="none"
        strokeLinejoin="round"
      >
        <path d="M50 8 L92 78 L8 78 Z" />
        <path d="M50 8 L50 78" />
        <path d="M8 78 L92 78" strokeOpacity="0.3" />
        <circle cx="50" cy="8" r="2.5" fill="rgba(255,213,0,0.9)" stroke="none" />
      </g>
    </motion.svg>
  );
}

/** MonogramPlate — central charcoal square with K (white) + C (yellow) letters. */
function MonogramPlate({
  size = 200,
  label,
  className,
  delay = 0,
}: {
  size?: number;
  label?: string;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("absolute metallic-dark rounded-2xl", className)}
      style={{
        width: size,
        height: size,
        boxShadow:
          "inset 0 1px 0 rgba(255,255,255,0.08), inset 0 -2px 6px rgba(0,0,0,0.7), 0 30px 60px -20px rgba(0,0,0,0.8), 0 0 80px -10px rgba(255,213,0,0.25)",
      }}
      animate={{ y: [0, -10, 0], rotateX: [0, 3, 0] }}
      transition={{
        duration: 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      <div className="flex h-full w-full flex-col items-center justify-center gap-3 rounded-2xl border border-brand-yellow/30 bg-brand-charcoal/70 backdrop-blur">
        <LogoSymbol className="h-16 w-16" />
        {label ? (
          <span className="font-poster text-xs uppercase tracking-[0.4em] text-white/80">
            {label}
          </span>
        ) : null}
      </div>
    </motion.div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene container with mouse-reactive tilt                                   */
/* -------------------------------------------------------------------------- */

export function Scene3D({
  kind,
  interactive = true,
  className,
  title = "KYVROXA",
}: Scene3DProps) {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rx = useSpring(useTransform(my, [-0.5, 0.5], [10, -10]), {
    stiffness: 80,
    damping: 18,
  });
  const ry = useSpring(useTransform(mx, [-0.5, 0.5], [-10, 10]), {
    stiffness: 80,
    damping: 18,
  });

  const handleMove = (e: React.MouseEvent) => {
    if (!interactive || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    mx.set(px);
    my.set(py);
  };
  const handleLeave = () => {
    mx.set(0);
    my.set(0);
  };

  return (
    <div
      ref={ref}
      aria-hidden="true"
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      className={cn(
        "perspective-1000 relative flex h-full w-full items-center justify-center overflow-hidden",
        className,
      )}
    >
      <motion.div
        className="preserve-3d relative h-full w-full"
        style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}
      >
        {/* shared ambient glow */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute left-1/2 top-1/2 h-1/2 w-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-yellow/10 blur-3xl"
        />

        <SceneContent kind={kind} title={title} />
      </motion.div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene content dispatch                                                     */
/* -------------------------------------------------------------------------- */

function SceneContent({ kind, title }: { kind: Scene3DKind; title: string }) {
  switch (kind) {
    case "home-hero":
      return <HomeHeroScene title={title} />;
    case "canvases":
      return <CanvasesScene />;
    case "screens":
      return <ScreensScene />;
    case "phone":
      return <PhoneScene />;
    case "timeline":
      return <TimelineScene />;
    case "network":
      return <NetworkScene />;
    case "dashboard":
      return <DashboardScene />;
    case "cta":
      return <CtaScene />;
    case "about":
      return <AboutScene title={title} />;
    default:
      return null;
  }
}

/* -------------------------------------------------------------------------- */
/*  Scene 1: home-hero — central KC plate + chrome sphere + orbiting cubes/rings/wireframes */
/* -------------------------------------------------------------------------- */

function HomeHeroScene({ title }: { title: string }) {
  return (
    <>
      <MonogramPlate size={220} label={title} className="relative z-20" delay={0.2} />
      <ChromeSphere size={140} className="left-[12%] top-[20%] z-10" delay={0.4} />
      <FloatingRing size={300} className="left-1/2 top-1/2 -z-0 -translate-x-1/2 -translate-y-1/2" delay={0.1} />
      <FloatingRing size={420} className="left-1/2 top-1/2 -z-0 -translate-x-1/2 -translate-y-1/2 opacity-60" thickness={1} delay={0.5} />
      <FloatingCube size={48} className="right-[14%] top-[18%] z-10" delay={0.6} />
      <FloatingCube size={32} className="left-[20%] bottom-[18%] z-10" delay={1.1} />
      <FloatingCube size={28} className="right-[18%] bottom-[22%] z-10" delay={1.4} />
      <WireframeShape size={120} className="right-[8%] bottom-[10%] z-10" delay={0.8} />
      <WireframeShape size={80} className="left-[10%] top-[10%] z-10 opacity-70" delay={1.2} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 2: canvases — floating design canvases with color swatches           */
/* -------------------------------------------------------------------------- */

function CanvasCard({
  className,
  delay = 0,
  swatches = ["#FFD500", "#FFFFFF", "#A6A6A6", "#050505"],
}: {
  className?: string;
  delay?: number;
  swatches?: string[];
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("absolute metallic-dark rounded-lg", className)}
      animate={{ y: [0, -12, 0], rotate: [-2, 1, -2] }}
      transition={{ duration: 5, delay, repeat: Infinity, ease: "easeInOut" }}
    >
      <div className="flex flex-col gap-2 rounded-lg border border-white/10 bg-brand-charcoal p-3">
        <div className="h-16 w-32 rounded bg-gradient-to-br from-brand-yellow/30 to-brand-yellow/5" />
        <div className="flex gap-1">
          {swatches.map((c, i) => (
            <span
              key={i}
              className="h-4 w-4 rounded-full border border-white/10"
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
        <div className="h-1.5 w-24 rounded bg-white/20" />
        <div className="h-1.5 w-16 rounded bg-white/10" />
      </div>
    </motion.div>
  );
}

function CanvasesScene() {
  return (
    <>
      <ChromeSphere size={120} className="left-[15%] top-[20%] z-20" delay={0.3} />
      <CanvasCard className="left-[25%] top-[30%] z-30" delay={0.1} />
      <CanvasCard className="right-[20%] top-[20%] z-30" delay={0.5} swatches={["#FFFFFF", "#FFD500", "#050505", "#A6A6A6"]} />
      <CanvasCard className="left-[35%] bottom-[18%] z-30" delay={0.9} swatches={["#A6A6A6", "#FFD500", "#FFFFFF", "#111111"]} />
      <FloatingRing size={200} className="right-[15%] bottom-[20%] opacity-50" thickness={1} delay={0.7} />
      <WireframeShape size={90} className="left-[8%] bottom-[10%] opacity-60" delay={1.1} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 3: screens — floating desktop + laptop with mini UI                  */
/* -------------------------------------------------------------------------- */

function ScreenFrame({
  className,
  delay = 0,
  variant = "desktop",
}: {
  className?: string;
  delay?: number;
  variant?: "desktop" | "laptop";
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("absolute metallic-dark rounded-lg", className)}
      animate={{ y: [0, -10, 0], rotate: [-1, 1, -1] }}
      transition={{ duration: 6, delay, repeat: Infinity, ease: "easeInOut" }}
    >
      <div className="rounded-lg border border-white/10 bg-brand-charcoal p-2.5">
        {/* mini UI */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <div className="h-1.5 w-10 rounded bg-brand-yellow/80" />
            <div className="flex gap-1">
              <div className="h-1 w-1 rounded-full bg-white/30" />
              <div className="h-1 w-1 rounded-full bg-white/20" />
              <div className="h-1 w-1 rounded-full bg-white/10" />
            </div>
          </div>
          <div className="h-8 w-full rounded bg-gradient-to-br from-brand-yellow/20 to-transparent" />
          <div className="flex gap-1">
            <div className="h-1.5 flex-1 rounded bg-white/20" />
            <div className="h-1.5 flex-1 rounded bg-white/10" />
          </div>
          <div className="h-1.5 w-2/3 rounded bg-white/10" />
        </div>
      </div>
      {variant === "laptop" ? (
        <div className="mx-auto h-1.5 w-1/2 rounded-b bg-brand-charcoal border-x border-b border-white/10" />
      ) : null}
    </motion.div>
  );
}

function ScreensScene() {
  return (
    <>
      <ScreenFrame variant="desktop" className="left-[20%] top-[22%] z-30 w-44" delay={0.2} />
      <ScreenFrame variant="laptop" className="right-[18%] top-[32%] z-30 w-36" delay={0.6} />
      <FloatingRing size={260} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-50" thickness={1} delay={0.3} />
      <FloatingCube size={36} className="left-[10%] bottom-[20%]" delay={1} />
      <FloatingCube size={28} className="right-[12%] bottom-[18%]" delay={1.4} />
      <WireframeShape size={100} className="right-[5%] top-[5%] opacity-60" delay={1.1} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 4: phone — floating smartphone with dashboard UI                    */
/* -------------------------------------------------------------------------- */

function PhoneFrame({ delay = 0 }: { delay?: number }) {
  return (
    <motion.div
      aria-hidden="true"
      className="absolute left-1/2 top-1/2 z-30 -translate-x-1/2 -translate-y-1/2"
      animate={{ y: [0, -12, 0], rotate: [-1, 1, -1] }}
      transition={{ duration: 6, delay, repeat: Infinity, ease: "easeInOut" }}
    >
      <div className="metallic-dark rounded-[2rem] border border-white/10 p-2 shadow-2xl">
        <div className="flex h-72 w-36 flex-col gap-2 rounded-[1.6rem] border border-white/5 bg-brand-charcoal p-2.5">
          {/* notch */}
          <div className="mx-auto h-1 w-10 rounded-full bg-white/15" />
          {/* header */}
          <div className="flex items-center justify-between">
            <div className="h-2 w-10 rounded bg-brand-yellow" />
            <div className="h-2 w-2 rounded-full bg-white/20" />
          </div>
          {/* stat */}
          <div className="rounded-lg border border-white/10 bg-brand-black/60 p-2">
            <div className="h-1.5 w-8 rounded bg-white/15" />
            <div className="mt-1 h-3 w-14 rounded bg-white/80" />
            <div className="mt-1 h-1 w-10 rounded bg-brand-yellow/60" />
          </div>
          {/* mini bar chart */}
          <div className="flex h-12 items-end gap-1 rounded-lg border border-white/10 bg-brand-black/60 p-2">
            {[40, 70, 50, 90, 60, 80].map((h, i) => (
              <div
                key={i}
                className="flex-1 rounded-t bg-brand-yellow/70"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
          {/* list rows */}
          <div className="flex flex-col gap-1.5">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="flex items-center gap-1.5 rounded border border-white/5 bg-brand-black/40 p-1.5"
              >
                <div className="h-3 w-3 rounded-full bg-brand-yellow/50" />
                <div className="flex-1">
                  <div className="h-1.5 w-10 rounded bg-white/30" />
                  <div className="mt-0.5 h-1 w-6 rounded bg-white/10" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function PhoneScene() {
  return (
    <>
      <PhoneFrame delay={0.3} />
      <FloatingRing size={260} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-50" thickness={1} delay={0.2} />
      <ChromeSphere size={70} className="left-[15%] top-[28%]" delay={0.6} />
      <FloatingCube size={28} className="right-[15%] top-[20%]" delay={0.9} />
      <FloatingCube size={24} className="left-[18%] bottom-[22%]" delay={1.2} />
      <WireframeShape size={80} className="right-[10%] bottom-[15%] opacity-60" delay={1.4} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 5: timeline — floating video timeline with playhead + audio waveforms */
/* -------------------------------------------------------------------------- */

function Waveform({ className, delay = 0 }: { className?: string; delay?: number }) {
  const bars = Array.from({ length: 32 });
  return (
    <motion.div
      aria-hidden="true"
      className={cn("flex h-10 items-center gap-0.5", className)}
      animate={{ opacity: [0.4, 1, 0.4] }}
      transition={{ duration: 2, delay, repeat: Infinity, ease: "easeInOut" }}
    >
      {bars.map((_, i) => {
        const h = 20 + Math.abs(Math.sin(i * 0.6)) * 80;
        return (
          <div
            key={i}
            className="w-1 rounded-full bg-brand-yellow/70"
            style={{ height: `${h}%` }}
          />
        );
      })}
    </motion.div>
  );
}

function TimelineScene() {
  return (
    <>
      <motion.div
        aria-hidden="true"
        className="absolute left-1/2 top-1/2 z-30 w-80 -translate-x-1/2 -translate-y-1/2"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="metallic-dark rounded-2xl border border-white/10 p-4 shadow-2xl">
          {/* preview window */}
          <div className="relative mb-3 h-28 overflow-hidden rounded-lg border border-white/5 bg-brand-black/60">
            <div className="absolute inset-0 bg-gradient-to-br from-brand-yellow/15 to-transparent" />
            <div className="absolute left-1/2 top-1/2 flex h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-brand-yellow bg-brand-black/70">
              <div className="ml-0.5 h-0 w-0 border-y-4 border-l-[7px] border-y-transparent border-l-brand-yellow" />
            </div>
            <div className="absolute right-2 top-2 rounded bg-brand-black/60 px-1.5 py-0.5 font-mono text-[10px] text-brand-yellow">
              00:42
            </div>
          </div>
          {/* waveform */}
          <Waveform className="mb-2" />
          {/* timeline track */}
          <div className="relative h-6 rounded border border-white/5 bg-brand-black/60">
            <div className="absolute left-0 top-0 h-full w-1/3 rounded-l bg-brand-yellow/40" />
            <div className="absolute left-1/3 top-0 h-full w-px -translate-x-1/2 bg-brand-yellow shadow-[0_0_8px_rgba(255,213,0,0.8)]" />
          </div>
        </div>
      </motion.div>
      <ChromeSphere size={90} className="left-[12%] top-[20%]" delay={0.4} />
      <FloatingCube size={28} className="right-[15%] top-[20%]" delay={0.8} />
      <FloatingRing size={220} className="right-[8%] bottom-[10%] opacity-40" thickness={1} delay={0.6} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 6: network — connected nodes graph with engagement cards            */
/* -------------------------------------------------------------------------- */

function NetworkScene() {
  const nodes = [
    { x: 20, y: 25, r: 8 },
    { x: 70, y: 18, r: 6 },
    { x: 80, y: 60, r: 10 },
    { x: 30, y: 70, r: 7 },
    { x: 50, y: 45, r: 14 },
    { x: 60, y: 80, r: 5 },
  ];
  return (
    <>
      <motion.svg
        aria-hidden="true"
        viewBox="0 0 100 100"
        className="absolute left-1/2 top-1/2 z-20 h-[80%] w-[80%] -translate-x-1/2 -translate-y-1/2"
        animate={{ rotate: [0, 2, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      >
        {/* connections */}
        <g stroke="rgba(255,213,0,0.35)" strokeWidth="0.5" fill="none">
          {nodes.map((a, i) =>
            nodes.slice(i + 1).map((b, j) => (
              <line
                key={`${i}-${j}`}
                x1={a.x}
                y1={a.y}
                x2={b.x}
                y2={b.y}
                strokeOpacity={Math.abs(a.x - b.x) + Math.abs(a.y - b.y) > 50 ? 0.15 : 0.4}
              />
            )),
          )}
        </g>
        {/* nodes */}
        {nodes.map((n, i) => (
          <motion.circle
            key={i}
            cx={n.x}
            cy={n.y}
            r={n.r / 2}
            fill="rgba(255,213,0,0.85)"
            animate={{ r: [n.r / 2, n.r / 2 + 1.5, n.r / 2] }}
            transition={{ duration: 3, delay: i * 0.2, repeat: Infinity, ease: "easeInOut" }}
          />
        ))}
        {/* center node */}
        <circle cx={50} cy={45} r="8" fill="rgba(255,213,0,0.18)" stroke="rgba(255,213,0,0.7)" strokeWidth="0.6" />
      </motion.svg>
      {/* engagement cards */}
      {[
        { label: "Reach", value: "12.4k", pos: "left-[8%] top-[14%]" },
        { label: "Engagement", value: "8.1%", pos: "right-[8%] top-[24%]" },
        { label: "Followers", value: "+432", pos: "left-[10%] bottom-[14%]" },
      ].map((c, i) => (
        <motion.div
          key={c.label}
          aria-hidden="true"
          className={cn("absolute z-30 rounded-lg border border-white/10 bg-brand-charcoal/90 p-2.5 backdrop-blur", c.pos)}
          animate={{ y: [0, -8, 0] }}
          transition={{ duration: 5, delay: i * 0.3, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="font-mono text-[9px] uppercase tracking-wider text-brand-gray">
            {c.label}
          </div>
          <div className="font-display text-sm font-bold text-brand-yellow">
            {c.value}
          </div>
        </motion.div>
      ))}
      <FloatingCube size={26} className="right-[14%] bottom-[16%]" delay={1.2} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 7: dashboard — floating analytics dashboard with charts            */
/* -------------------------------------------------------------------------- */

function DashboardScene() {
  return (
    <>
      <motion.div
        aria-hidden="true"
        className="absolute left-1/2 top-1/2 z-30 w-80 -translate-x-1/2 -translate-y-1/2"
        animate={{ y: [0, -10, 0], rotate: [-1, 1, -1] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="metallic-dark rounded-2xl border border-white/10 p-4 shadow-2xl">
          <div className="mb-3 flex items-center justify-between">
            <div className="h-2 w-16 rounded bg-brand-yellow" />
            <div className="font-mono text-[10px] text-brand-gray">REPORT</div>
          </div>
          {/* KPI row */}
          <div className="mb-3 grid grid-cols-3 gap-2">
            {[
              { v: "2.4k", l: "Visits" },
              { v: "8.1%", l: "CR" },
              { v: "PKR 92k", l: "Rev" },
            ].map((kpi) => (
              <div
                key={kpi.l}
                className="rounded border border-white/5 bg-brand-black/50 p-2"
              >
                <div className="font-display text-sm font-bold text-white">
                  {kpi.v}
                </div>
                <div className="font-mono text-[8px] uppercase text-brand-gray">
                  {kpi.l}
                </div>
              </div>
            ))}
          </div>
          {/* line chart */}
          <div className="relative h-20 overflow-hidden rounded border border-white/5 bg-brand-black/50 p-2">
            <svg viewBox="0 0 100 40" className="h-full w-full" preserveAspectRatio="none">
              <polyline
                points="0,32 15,22 30,28 45,12 60,18 75,8 90,14 100,4"
                fill="none"
                stroke="rgba(255,213,0,0.8)"
                strokeWidth="1.5"
              />
              <polyline
                points="0,38 15,30 30,34 45,28 60,30 75,22 90,26 100,20"
                fill="none"
                stroke="rgba(255,255,255,0.25)"
                strokeWidth="1"
                strokeDasharray="2,2"
              />
            </svg>
          </div>
          {/* mini bar */}
          <div className="mt-2 flex h-10 items-end gap-1">
            {[40, 60, 35, 80, 55, 70, 50].map((h, i) => (
              <div
                key={i}
                className="flex-1 rounded-t bg-brand-yellow/60"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
        </div>
      </motion.div>
      <ChromeSphere size={90} className="left-[12%] top-[20%]" delay={0.4} />
      <FloatingRing size={200} className="right-[8%] bottom-[10%] opacity-40" thickness={1} delay={0.6} />
      <FloatingCube size={28} className="right-[15%] top-[18%]" delay={1} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 8: cta — centered chrome sphere + concentric rings + cubes + wireframes */
/* -------------------------------------------------------------------------- */

function CtaScene() {
  return (
    <>
      <ChromeSphere size={180} className="left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2" delay={0.3} />
      <FloatingRing size={260} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-70" delay={0.2} />
      <FloatingRing size={360} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-50" thickness={1} delay={0.6} />
      <FloatingRing size={460} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-30" thickness={1} delay={1} />
      <FloatingCube size={36} className="left-[14%] top-[22%]" delay={0.8} />
      <FloatingCube size={28} className="right-[14%] top-[20%]" delay={1.1} />
      <FloatingCube size={32} className="left-[16%] bottom-[22%]" delay={1.4} />
      <FloatingCube size={26} className="right-[16%] bottom-[20%]" delay={1.7} />
      <WireframeShape size={120} className="left-[6%] bottom-[6%] opacity-60" delay={1.2} />
      <WireframeShape size={100} className="right-[6%] top-[6%] opacity-60" delay={1.5} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Scene 9: about — 3D KC brand sculpture (sphere + monogram plate + rings) */
/* -------------------------------------------------------------------------- */

function AboutScene({ title }: { title: string }) {
  return (
    <>
      <MonogramPlate size={180} label={title} className="left-1/2 top-1/2 z-30 -translate-x-1/2 -translate-y-1/2" delay={0.2} />
      <ChromeSphere size={120} className="left-[14%] top-[20%] z-20" delay={0.4} />
      <ChromeSphere size={70} className="right-[14%] bottom-[18%] z-20" delay={1} />
      <FloatingRing size={260} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-60" delay={0.1} />
      <FloatingRing size={360} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-40" thickness={1} delay={0.5} />
      <FloatingCube size={32} className="right-[15%] top-[20%]" delay={0.9} />
      <FloatingCube size={26} className="left-[18%] bottom-[22%]" delay={1.2} />
      <WireframeShape size={90} className="right-[8%] top-[8%] opacity-60" delay={1.4} />
    </>
  );
}

export default Scene3D;
