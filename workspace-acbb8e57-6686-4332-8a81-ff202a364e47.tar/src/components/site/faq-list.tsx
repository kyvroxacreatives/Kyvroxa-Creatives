"use client";

import * as React from "react";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import type { ServiceFaq } from "@/lib/site-data";
import { cn } from "@/lib/utils";

/**
 * FaqList — shadcn/ui Accordion wrapper for service FAQs.
 * Single-open collapsible, default first item open.
 */
export function FaqList({
  faqs,
  className,
}: {
  faqs: ServiceFaq[];
  className?: string;
}) {
  return (
    <Accordion
      type="single"
      collapsible
      defaultValue={faqs.length > 0 ? "faq-0" : undefined}
      className={cn("w-full", className)}
    >
      {faqs.map((faq, i) => (
        <AccordionItem
          key={`faq-${i}`}
          value={`faq-${i}`}
          className="border-b border-white/8 last:border-b-0"
        >
          <AccordionTrigger className="py-5 font-display text-base font-medium text-white hover:text-brand-yellow hover:no-underline data-[state=open]:text-brand-yellow">
            {faq.question}
          </AccordionTrigger>
          <AccordionContent className="text-sm leading-relaxed text-brand-gray">
            {faq.answer}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

export default FaqList;
