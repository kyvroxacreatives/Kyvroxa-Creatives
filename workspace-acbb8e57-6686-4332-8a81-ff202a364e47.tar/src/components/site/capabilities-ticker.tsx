"use client";

import * as React from "react";
import { CAPABILITIES } from "@/lib/site-data";
import { cn } from "@/lib/utils";

/**
 * CapabilitiesTicker — seamless horizontal marquee of CAPABILITIES.
 * Black background, yellow dots between items, edge fade gradients on both sides.
 */
export function CapabilitiesTicker({
  className,
}: {
  className?: string;
}) {
  // duplicate list to make a seamless loop
  const items = [...CAPABILITIES, ...CAPABILITIES];

  return (
    <div
      className={cn(
        "relative w-full overflow-hidden border-y border-white/5 bg-brand-black py-4",
        className,
      )}
      role="marquee"
      aria-label="KYVROXA capabilities"
    >
      {/* edge fade left */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-0 top-0 z-10 h-full w-24 bg-gradient-to-r from-brand-black to-transparent"
      />
      {/* edge fade right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-0 top-0 z-10 h-full w-24 bg-gradient-to-l from-brand-black to-transparent"
      />

      <div className="flex w-max animate-marquee items-center gap-8 pr-8">
        {items.map((cap, i) => (
          <React.Fragment key={`${cap.label}-${i}`}>
            <span className="font-poster text-2xl uppercase tracking-tight text-white/90">
              {cap.label}
            </span>
            <span
              aria-hidden="true"
              className="inline-block h-2 w-2 rounded-full bg-brand-yellow shadow-[0_0_10px_rgba(255,213,0,0.7)]"
            />
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

export default CapabilitiesTicker;
