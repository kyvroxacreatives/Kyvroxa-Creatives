import * as React from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { PageShell } from "@/components/site/page-shell";
import { Eyebrow, Reveal, RevealText } from "@/components/site/reveal";
import { BackToTopInline } from "./back-to-top-inline";

/**
 * LegalPage — shared layout for Privacy Policy, Terms of Service, etc.
 *
 * Structure:
 *  - Hero with title + "Last updated" date + intro paragraph
 *  - Sticky table of contents (left on desktop, top on mobile)
 *  - Long-form content sections with proper headings
 *  - Back-to-top floating control + back link
 *
 * Brand-consistent: black bg, yellow accents, Space Grotesk + Inter fonts.
 */
export interface LegalSection {
  id: string;
  heading: string;
  body: React.ReactNode;
}

interface LegalPageProps {
  eyebrow: string;
  title: string;
  highlightWords?: string[];
  intro: string;
  lastUpdated: string;
  sections: LegalSection[];
  contactCta?: React.ReactNode;
}

export function LegalPage({
  eyebrow,
  title,
  highlightWords = [],
  intro,
  lastUpdated,
  sections,
  contactCta,
}: LegalPageProps) {
  return (
    <PageShell>
      {/* ---------- Hero ---------- */}
      <section className="relative overflow-hidden border-b border-white/5 bg-brand-black">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-grid opacity-[0.05]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-spotlight"
        />
        <div className="relative mx-auto max-w-5xl px-4 pb-12 pt-20 sm:px-6 sm:pt-24 lg:px-8">
          <Reveal>
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-brand-gray transition-colors hover:text-brand-yellow"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to home
            </Link>
          </Reveal>
          <Reveal delay={0.05}>
            <Eyebrow className="mt-6">{eyebrow}</Eyebrow>
          </Reveal>
          <h1 className="mt-5 font-poster text-4xl uppercase leading-[0.95] tracking-tight text-white sm:text-5xl md:text-6xl">
            <RevealText text={title} highlightWords={highlightWords} />
          </h1>
          <Reveal delay={0.12}>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
              {intro}
            </p>
          </Reveal>
          <Reveal delay={0.18}>
            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-brand-charcoal/60 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-gray">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-brand-yellow" />
              Last updated · {lastUpdated}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------- Body: TOC + sections ---------- */}
      <section className="bg-brand-charcoal">
        <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
            {/* TOC — sticky on desktop */}
            <aside className="lg:col-span-3">
              <div className="sticky top-24">
                <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-brand-yellow">
                  On this page
                </div>
                <nav className="mt-4 flex flex-col gap-2 border-l border-white/10">
                  {sections.map((s, i) => (
                    <a
                      key={s.id}
                      href={`#${s.id}`}
                      className="border-l-2 border-transparent pl-4 -ml-px text-sm leading-snug text-brand-gray transition-colors hover:border-brand-yellow hover:text-brand-yellow"
                    >
                      <span className="mr-2 font-mono text-[10px] text-brand-yellow/60">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      {s.heading}
                    </a>
                  ))}
                </nav>
              </div>
            </aside>

            {/* Main content */}
            <div className="lg:col-span-9">
              <div className="flex flex-col gap-12 sm:gap-14">
                {sections.map((s, i) => (
                  <section
                    key={s.id}
                    id={s.id}
                    aria-labelledby={`${s.id}-heading`}
                    className="scroll-mt-24"
                  >
                    <Reveal>
                      <div className="flex items-baseline gap-3">
                        <span className="font-poster text-3xl text-brand-yellow sm:text-4xl">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <h2
                          id={`${s.id}-heading`}
                          className="font-display text-xl font-bold text-white sm:text-2xl"
                        >
                          {s.heading}
                        </h2>
                      </div>
                    </Reveal>
                    <Reveal delay={0.05}>
                      <div className="mt-4 space-y-4 text-sm leading-relaxed text-brand-gray sm:text-base">
                        {s.body}
                      </div>
                    </Reveal>
                  </section>
                ))}
              </div>

              {/* Bottom CTA */}
              {contactCta ? (
                <Reveal delay={0.1}>
                  <div className="mt-16 rounded-2xl border border-brand-yellow/20 bg-brand-black/60 p-6 sm:p-8">
                    {contactCta}
                  </div>
                </Reveal>
              ) : null}
            </div>
          </div>
        </div>
      </section>

      {/* Floating back-to-top */}
      <BackToTopInline />
    </PageShell>
  );
}

/* ---------- small helpers for body content ---------- */

export function P({ children }: { children: React.ReactNode }) {
  return <p className="leading-relaxed">{children}</p>;
}

export function Ul({ children }: { children: React.ReactNode }) {
  return (
    <ul className="ml-5 list-disc space-y-2 marker:text-brand-yellow">
      {children}
    </ul>
  );
}

export function Strong({ children }: { children: React.ReactNode }) {
  return <strong className="font-semibold text-white">{children}</strong>;
}
