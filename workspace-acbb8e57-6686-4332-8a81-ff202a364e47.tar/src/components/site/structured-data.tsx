import * as React from "react";
import { SERVICES, NAV_LINKS } from "@/lib/site-data";

/**
 * StructuredData — JSON-LD for Organization + WebSite + 6 Service schemas.
 * Renders <script type="application/ld+json"> blocks.
 * Logo URL: https://kyvroxa.com/logo.png
 */
const ORG = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "KYVROXA Creatives",
  url: "https://kyvroxa.com",
  logo: "https://kyvroxa.com/logo.png",
  image: "https://kyvroxa.com/logo.png",
  description:
    "KYVROXA Creatives is an independent creative & digital studio specializing in graphic design, branding, UI/UX, web design, mobile app design, video editing, social media marketing, and digital media marketing.",
  email: "kyvroxacreatives@gmail.com",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Karachi",
    addressCountry: "PK",
  },
  sameAs: [
    "https://instagram.com/kyvroxa",
    "https://linkedin.com/company/kyvroxa",
    "https://facebook.com/kyvroxa",
  ],
};

const WEBSITE = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "KYVROXA Creatives",
  url: "https://kyvroxa.com",
  publisher: {
    "@type": "Organization",
    name: "KYVROXA Creatives",
    logo: {
      "@type": "ImageObject",
      url: "https://kyvroxa.com/logo.png",
    },
  },
  potentialAction: {
    "@type": "SearchAction",
    target: "https://kyvroxa.com/search?q={search_term_string}",
    "query-input": "required name=search_term_string",
  },
};

function buildServiceSchema(slug: string) {
  const svc = SERVICES.find((s) => s.slug === slug);
  if (!svc) return null;
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name: svc.title,
    alternateName: svc.shortName,
    description: svc.description,
    url: `https://kyvroxa.com/services/${svc.slug}`,
    provider: {
      "@type": "Organization",
      name: "KYVROXA Creatives",
      url: "https://kyvroxa.com",
      logo: "https://kyvroxa.com/logo.png",
    },
    areaServed: "Worldwide",
    serviceType: svc.eyebrow,
    offers: svc.packages.map((p) => ({
      "@type": "Offer",
      name: p.name,
      price: p.price.replace(/[^\d]/g, ""),
      priceCurrency: "PKR",
      description: p.description,
    })),
  };
}

export function StructuredData() {
  const serviceSchemas = SERVICES.map((s) =>
    buildServiceSchema(s.slug),
  ).filter(Boolean) as Record<string, unknown>[];

  const breadcrumb = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: NAV_LINKS.map((link, idx) => ({
      "@type": "ListItem",
      position: idx + 1,
      name: link.label,
      item: `https://kyvroxa.com${link.href}`,
    })),
  };

  const blocks = [ORG, WEBSITE, breadcrumb, ...serviceSchemas];

  return (
    <>
      {blocks.map((block, i) => (
        <script
          key={`ld-${i}`}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(block) }}
        />
      ))}
    </>
  );
}

export default StructuredData;
