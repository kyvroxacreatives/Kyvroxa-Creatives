"use client";

import * as React from "react";
import { motion, useScroll } from "framer-motion";
import { cn } from "@/lib/utils";
import { Reveal } from "./reveal";
import { PROCESS_STEPS } from "@/lib/site-data";

interface TimelineEntry {
  label: string;
  value: string;
}

function buildEntries(): TimelineEntry[][] {
  return PROCESS_STEPS.map((s) => [
    { label: "What you provide", value: s.clientProvides },
    { label: "What we deliver", value: s.agencyDelivers },
    { label: "Approval needed", value: s.approvalNeeded },
  ]);
}

export function ProcessTimeline() {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = React.useState(0);

  const entries = React.useMemo(() => buildEntries(), []);

  // Drive the side progress bar from scroll position
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  // Track active step via IntersectionObserver for accessibility
  React.useEffect(() => {
    const stepEls = Array.from(
      containerRef.current?.querySelectorAll<HTMLElement>("[data-step]") ?? [],
    );
    if (stepEls.length === 0) return;

    const observer = new IntersectionObserver(
      (entriesObs) => {
        for (const e of entriesObs) {
          if (e.isIntersecting) {
            const idx = Number(
              (e.target as HTMLElement).dataset.stepIndex ?? 0,
            );
            setActiveIndex(idx);
          }
        }
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: 0 },
    );

    stepEls.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative grid grid-cols-1 gap-8 lg:grid-cols-[3rem_1fr]"
    >
      {/* Sticky side progress (desktop only) */}
      <div className="pointer-events-none hidden lg:block">
        <div className="sticky top-24 flex h-[60vh] flex-col items-center">
          <div className="relative h-full w-px bg-white/10">
            <motion.div
              className="absolute left-0 top-0 w-px bg-brand-yellow"
              style={{
                height: "100%",
                scaleY: scrollYProgress,
                transformOrigin: "top",
              }}
            />
            {PROCESS_STEPS.map((s, i) => (
              <div
                key={s.number}
                className="absolute -left-[5px] -translate-y-1/2"
                style={{ top: `${(i / (PROCESS_STEPS.length - 1)) * 100}%` }}
              >
                <span
                  className={cn(
                    "block h-3 w-3 rounded-full transition-all",
                    activeIndex === i
                      ? "bg-brand-yellow ring-4 ring-brand-yellow/20"
                      : "bg-white/20",
                  )}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Steps container */}
      <div className="relative">
        {/* Vertical line on the left for mobile */}
        <div
          className="absolute left-[15px] top-2 bottom-2 w-px bg-white/10 lg:hidden"
          aria-hidden
        />

        <ol className="space-y-10 lg:space-y-16">
          {PROCESS_STEPS.map((step, i) => (
            <li
              key={step.number}
              data-step
              data-step-index={i}
              className="relative"
            >
              <Reveal delay={Math.min(i * 0.04, 0.2)}>
                <StepCard
                  number={step.number}
                  title={step.title}
                  entries={entries[i]}
                  isLast={i === PROCESS_STEPS.length - 1}
                />
              </Reveal>

              {/* Mobile dot */}
              <span
                className="absolute left-[10px] top-7 h-3 w-3 rounded-full border-2 border-brand-yellow bg-brand-black lg:hidden"
                aria-hidden
              />
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

function StepCard({
  number,
  title,
  entries,
  isLast,
}: {
  number: string;
  title: string;
  entries: TimelineEntry[];
  isLast: boolean;
}) {
  return (
    <article
      className={cn(
        "ml-10 rounded-2xl border bg-brand-charcoal p-6 transition-all duration-300 lg:ml-0",
        isLast
          ? "border-brand-yellow/50"
          : "border-white/10 hover:border-white/20",
      )}
    >
      <div className="flex items-start gap-4">
        <div className="font-display text-4xl font-bold leading-none text-brand-yellow sm:text-5xl">
          {number}
        </div>
        <div className="pt-1">
          <h3 className="font-display text-lg font-bold tracking-tight text-foreground sm:text-xl">
            {title}
          </h3>
          {!isLast ? (
            <div className="mt-1 text-[10px] uppercase tracking-widest text-brand-gray">
              Step in Progression
            </div>
          ) : (
            <div className="mt-1 text-[10px] uppercase tracking-widest text-brand-yellow">
              Continuous
            </div>
          )}
        </div>
      </div>

      <dl className="mt-6 space-y-4">
        {entries.map((e) => (
          <div
            key={e.label}
            className="rounded-xl border border-white/5 bg-brand-black/40 p-4"
          >
            <dt className="text-[10px] font-semibold uppercase tracking-widest text-brand-yellow">
              {e.label}
            </dt>
            <dd className="mt-1.5 text-sm text-foreground/85">{e.value}</dd>
          </div>
        ))}
      </dl>
    </article>
  );
}
