import * as React from "react";
import { ScrollProgress } from "./scroll-progress";
import { Header } from "./header";
import { Footer } from "./footer";
import { BackToTop } from "./back-to-top";
import { cn } from "@/lib/utils";

/**
 * PageShell — wraps every page.
 * ScrollProgress + Header + main + Footer + BackToTop.
 * min-h-screen flex flex-col for sticky footer (main flex-1, footer mt-auto).
 * topPad default true → adds pt-16 to main to offset fixed header.
 */
export function PageShell({
  children,
  className,
  topPad = true,
}: {
  children: React.ReactNode;
  className?: string;
  topPad?: boolean;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-brand-black">
      <ScrollProgress />
      <Header />
      <main
        className={cn(
          "flex-1",
          topPad && "pt-16",
          className,
        )}
      >
        {children}
      </main>
      <Footer />
      <BackToTop />
    </div>
  );
}

export default PageShell;
