import Link from "next/link";
import { Mail, Instagram, Linkedin, Facebook } from "lucide-react";
import { SERVICES, NAV_LINKS } from "@/lib/site-data";
import { Logo } from "./logo";

/**
 * Footer — 4-column footer with sticky behavior.
 * Layout uses parent's flex column (PageShell: min-h-screen flex flex-col),
 * footer sits at the bottom naturally via mt-auto.
 */
type StudioLink = { label: string; href: string };
const STUDIO_LINKS: StudioLink[] = [
  ...NAV_LINKS.map<StudioLink>((l) => ({ label: l.label, href: l.href })),
  { label: "Privacy", href: "/privacy" },
  { label: "Terms", href: "/terms" },
];

const SOCIALS = [
  { label: "Instagram", href: "https://instagram.com/kyvroxa", Icon: Instagram },
  { label: "LinkedIn", href: "https://linkedin.com/company/kyvroxa", Icon: Linkedin },
  { label: "Facebook", href: "https://facebook.com/kyvroxa", Icon: Facebook },
];

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer
      id="site-footer"
      className="mt-auto w-full border-t border-white/5 bg-brand-black"
    >
      {/* Top accent gradient line */}
      <div
        aria-hidden="true"
        className="h-px w-full bg-gradient-to-r from-transparent via-brand-yellow/60 to-transparent"
      />

      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand block */}
          <div className="flex flex-col gap-5">
            <Link href="/" aria-label="KYVROXA Creatives home">
              <Logo size="sm" />
            </Link>
            <p className="max-w-xs text-sm leading-relaxed text-brand-gray">
              Independent creative &amp; digital studio turning ideas into
              measurable digital impact.
            </p>
            <div className="flex flex-col gap-2 text-sm">
              <a
                href="mailto:kyvroxacreatives@gmail.com"
                className="link-underline inline-flex items-center gap-2 text-white/85 transition-colors hover:text-brand-yellow"
              >
                <Mail className="h-4 w-4 text-brand-yellow" />
                kyvroxacreatives@gmail.com
              </a>

            </div>
            <div className="flex items-center gap-2">
              {SOCIALS.map(({ label, href, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-md border border-white/10 text-white/70 transition-all hover:border-brand-yellow hover:text-brand-yellow"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Services list */}
          <div className="flex flex-col gap-3">
            <h3 className="font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow">
              Services
            </h3>
            <ul className="flex flex-col gap-2">
              {SERVICES.map((svc) => (
                <li key={svc.slug}>
                  <Link
                    href={`/services/${svc.slug}`}
                    className="link-underline text-sm text-white/80 transition-colors hover:text-white"
                  >
                    {svc.shortName}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Studio / pages list */}
          <div className="flex flex-col gap-3">
            <h3 className="font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow">
              Studio
            </h3>
            <ul className="flex flex-col gap-2">
              {STUDIO_LINKS.map((link) => (
                <li key={link.href + link.label}>
                  <Link
                    href={link.href}
                    className="link-underline text-sm text-white/80 transition-colors hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* CTA block */}
          <div className="flex flex-col gap-4 rounded-2xl border border-white/5 bg-brand-charcoal p-6">
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow">
              Available for select projects
            </span>
            <h4 className="font-display text-2xl font-bold leading-tight text-white">
              Start a Project
            </h4>
            <p className="text-sm leading-relaxed text-brand-gray">
              Tell us about your goals. We&apos;ll respond with a clear scope,
              timeline, and price.
            </p>
            <Link
              href="/contact"
              className="inline-flex h-11 items-center justify-center rounded-md border border-brand-yellow bg-brand-yellow px-5 text-xs font-medium uppercase tracking-wider text-brand-black transition-colors hover:bg-white"
            >
              Start a Project
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom strip */}
      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-brand-gray sm:flex-row sm:px-6 lg:px-8">
          <p>
            © {year} KYVROXA Creatives. All rights reserved.
          </p>
          <p className="font-mono uppercase tracking-wider">
            Karachi · Pakistan
          </p>
          <p className="font-mono uppercase tracking-wider text-brand-yellow">
            Available for select projects
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
