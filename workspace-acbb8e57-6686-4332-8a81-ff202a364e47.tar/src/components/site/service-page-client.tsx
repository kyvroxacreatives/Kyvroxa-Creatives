"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowUpRight, ArrowRight, Info, Sparkles } from "lucide-react";
import type { ServiceData, ServiceSlug } from "@/lib/site-data";
import { SERVICES } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { Scene3D, type Scene3DKind } from "./scene-3d";
import { Button } from "./button";
import { Reveal, RevealText, Eyebrow, SectionHeading } from "./reveal";
import { PricingCard } from "./pricing-card";
import { ServiceCard } from "./service-card";
import { FaqList } from "./faq-list";

/* -------------------------------------------------------------------------- */
/*  Per-service lookup tables                                                  */
/* -------------------------------------------------------------------------- */

/** Headline words highlighted yellow per service. */
const HIGHLIGHT_WORDS: Record<ServiceSlug, string[]> = {
  "graphic-designing": ["DESIGN", "BRAND", "IGNORE"],
  "website-designing": ["IMPRESS.", "BUILT", "PERFORM."],
  "mobile-app-designing": ["MOBILE", "EXPERIENCES", "LOVE"],
  "video-editing": ["SECOND", "PURPOSE."],
  "social-media-marketing": ["SCROLLS", "MEANINGFUL", "CONNECTIONS."],
  "digital-marketing": ["SMARTER", "CAMPAIGNS.", "CLEARER", "PERFORMANCE."],
};

/** Per-service clarifying note shown below the services grid. */
const SERVICE_NOTE: Record<ServiceSlug, string> = {
  "graphic-designing":
    "Printing, paid fonts, stock assets, complex illustrations, and additional deliverables may cost extra. Prices are starting estimates and should be configurable by the agency.",
  "website-designing":
    "Clearly distinguish between website UI/UX design and full website development. Specify which packages include coding, CMS setup, integrations, hosting configuration, and content entry.",
  "mobile-app-designing":
    "State clearly that these packages cover design and prototyping only, not native app development, backend engineering, app-store publication, or ongoing maintenance.",
  "video-editing":
    "Mention that the client must supply footage and necessary assets unless otherwise agreed. Advanced animation, filming, voice-over talent, premium stock footage, and extensive AI-generated video production may require additional fees.",
  "social-media-marketing":
    "State that ad spend, influencer fees, professional photography, on-location filming, and additional platforms are not included unless explicitly specified. Make it clear that follower growth, virality, leads, and sales cannot be guaranteed.",
  "digital-marketing":
    "Distinguish digital media marketing from organic social media management. Explain that this service focuses on paid campaigns, traffic acquisition, campaign measurement, and optimization.",
};

/** Per-service creative-process caption. */
const PROCESS_CAPTION: Record<ServiceSlug, string> = {
  "graphic-designing":
    "The number of initial concepts, revision rounds, file formats, and delivery timelines depend on the selected package.",
  "website-designing":
    "Timelines and revision rounds vary by selected package — see pricing below for details.",
  "mobile-app-designing":
    "Timelines and revision rounds vary by selected package — see pricing below for details.",
  "video-editing":
    "Timelines and revision rounds vary by selected package — see pricing below for details.",
  "social-media-marketing":
    "Timelines and revision rounds vary by selected package — see pricing below for details.",
  "digital-marketing":
    "Timelines and revision rounds vary by selected package — see pricing below for details.",
};

/** Section padding helper. */
const SECTION = "mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8";

/* -------------------------------------------------------------------------- */
/*  ServicePageClient — 7-section shared template                               */
/* -------------------------------------------------------------------------- */

export function ServicePageClient({ service }: { service: ServiceData }) {
  const heroKind = service.heroVisual as Scene3DKind;
  const otherServices = SERVICES.filter((s) => s.slug !== service.slug);

  return (
    <>
      {/* 1. HERO -------------------------------------------------------------- */}
      <HeroSection service={service} heroKind={heroKind} />

      {/* 2. SERVICE OFFERINGS ------------------------------------------------- */}
      <section className={cn(SECTION, "py-20 sm:py-24 md:py-28")}>
        <SectionHeading
          eyebrow="WHAT'S INCLUDED"
          title={<RevealText text="SERVICES WE OFFER" />}
        />
        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-12 lg:gap-8">
          {/* services list — long list with max height + scroll */}
          <Reveal
            className="lg:col-span-8"
            as="div"
          >
            <div className="max-h-96 overflow-y-auto rounded-2xl border border-white/8 bg-brand-charcoal p-4 sm:p-6">
              <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 sm:gap-3">
                {service.services.map((s, i) => (
                  <li
                    key={s}
                    className="flex items-start gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-white/[0.03]"
                  >
                    <span className="mt-0.5 font-mono text-xs text-brand-yellow">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-brand-yellow" aria-hidden="true">
                      ▹
                    </span>
                    <span className="text-sm leading-snug text-white/90 sm:text-base">
                      {s}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          {/* clarifying note callout */}
          <Reveal className="lg:col-span-4" delay={0.1} as="div">
            <aside className="flex h-full flex-col gap-3 rounded-2xl border border-brand-yellow/30 bg-brand-yellow/[0.04] p-6">
              <div className="flex items-center gap-2">
                <Info className="h-4 w-4 text-brand-yellow" />
                <span className="font-mono text-xs uppercase tracking-[0.2em] text-brand-yellow">
                  Scope Note
                </span>
              </div>
              <p className="text-sm leading-relaxed text-brand-gray">
                {SERVICE_NOTE[service.slug]}
              </p>
            </aside>
          </Reveal>
        </div>
      </section>

      {/* 3. CREATIVE PROCESS ------------------------------------------------- */}
      <section className="relative overflow-hidden border-y border-white/5 bg-brand-charcoal/40">
        <div className="absolute inset-0 bg-grid opacity-30" aria-hidden="true" />
        <div className={cn(SECTION, "relative z-10 py-20 sm:py-24 md:py-28")}>
          <SectionHeading
            eyebrow="HOW WE WORK"
            title={<RevealText text="OUR CREATIVE PROCESS" />}
          />
          <Reveal className="mt-12" as="div">
            <ol className="relative flex flex-col">
              {/* connecting vertical line */}
              <span
                aria-hidden="true"
                className="pointer-events-none absolute bottom-4 left-[19px] top-4 w-px bg-gradient-to-b from-brand-yellow/70 via-brand-yellow/30 to-transparent"
              />
              {service.process.map((p, i) => (
                <li
                  key={p.step}
                  className="relative flex gap-4 border-b border-white/8 py-5 last:border-b-0 sm:gap-6 sm:py-6"
                >
                  <span className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-brand-yellow bg-brand-black font-mono text-xs text-brand-yellow">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="flex flex-col gap-1.5">
                    <h3 className="font-display text-lg font-semibold text-white sm:text-xl">
                      {p.step}
                    </h3>
                    <p className="max-w-2xl text-sm leading-relaxed text-brand-gray sm:text-base">
                      {p.detail}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </Reveal>
          <Reveal className="mt-8" delay={0.1} as="div">
            <p className="max-w-3xl text-sm italic leading-relaxed text-brand-gray">
              {PROCESS_CAPTION[service.slug]}
            </p>
          </Reveal>
        </div>
      </section>

      {/* 4. PRICING ---------------------------------------------------------- */}
      <section className={cn(SECTION, "py-20 sm:py-24 md:py-28")}>
        <SectionHeading
          eyebrow="PRICING"
          title={<RevealText text="PACKAGES BUILT FOR YOUR STAGE" />}
          description="Starting estimates in PKR. Final quotes depend on scope, complexity, and timeline — request a custom proposal for your project."
          align="center"
        />
        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-3">
          {service.packages.map((pkg, i) => (
            <Reveal key={pkg.name} delay={i * 0.08} className="h-full" as="div">
              <PricingCard
                pkg={pkg}
                ctaHref="/contact"
                ctaLabel="Start with this plan"
                className="h-full"
              />
            </Reveal>
          ))}
        </div>

        {/* exclusions scope note */}
        {service.exclusions ? (
          <Reveal className="mt-10" as="div">
            <aside className="mx-auto flex max-w-4xl items-start gap-3 rounded-xl border border-white/8 bg-brand-charcoal/60 p-5">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-brand-yellow" />
              <p className="text-xs leading-relaxed text-brand-gray sm:text-sm">
                <span className="font-mono uppercase tracking-[0.2em] text-brand-yellow">
                  Scope note:&nbsp;
                </span>
                {service.exclusions}
              </p>
            </aside>
          </Reveal>
        ) : null}

        {/* bottom CTAs */}
        <Reveal className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row" as="div">
          <Button href="/contact" magnetic variant="primary" size="lg">
            Get a Custom Quote
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button href="/pricing" variant="outline" size="lg">
            Compare All Services
          </Button>
        </Reveal>
      </section>

      {/* 5. FAQs ------------------------------------------------------------- */}
      <section className="relative overflow-hidden border-t border-white/5 bg-brand-charcoal/40">
        <div className={cn(SECTION, "py-20 sm:py-24 md:py-28")}>
          <SectionHeading
            eyebrow="FAQ"
            title={<RevealText text="FREQUENTLY ASKED QUESTIONS" />}
            align="center"
          />
          <Reveal className="mx-auto mt-10 max-w-3xl" as="div">
            <FaqList faqs={service.faqs} />
          </Reveal>
        </div>
      </section>

      {/* 6. CROSS-LINKS ------------------------------------------------------ */}
      <section className={cn(SECTION, "py-20 sm:py-24 md:py-28")}>
        <SectionHeading
          eyebrow="EXPLORE MORE"
          title={<RevealText text="OTHER CREATIVE SERVICES" />}
          description="One studio, six disciplines. See how the rest of our work fits together."
        />
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {otherServices.map((svc, i) => (
            <Reveal key={svc.slug} delay={i * 0.06} className="h-full" as="div">
              <ServiceCard service={svc} index={SERVICES.findIndex((s) => s.slug === svc.slug)} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* 7. FINAL CTA -------------------------------------------------------- */}
      <FinalCtaSection />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Hero section                                                                */
/* -------------------------------------------------------------------------- */

function HeroSection({
  service,
  heroKind,
}: {
  service: ServiceData;
  heroKind: Scene3DKind;
}) {
  return (
    <section className="relative isolate flex min-h-[88vh] items-center overflow-hidden bg-brand-black pt-16">
      {/* full-bleed 3D scene */}
      <div className="absolute inset-0" aria-hidden="true">
        <Scene3D kind={heroKind} interactive className="opacity-70" />
      </div>
      {/* dim overlay so foreground text stays readable */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-brand-black/60 via-brand-black/70 to-brand-black"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-r from-brand-black/80 via-transparent to-transparent"
      />

      <div className={cn(SECTION, "relative z-10 w-full py-20")}>
        <div className="max-w-3xl">
          <Reveal>
            <Eyebrow>{service.eyebrow}</Eyebrow>
          </Reveal>
          <h1 className="mt-6 font-poster text-4xl uppercase leading-[0.92] text-white sm:text-5xl md:text-6xl lg:text-7xl">
            <RevealText
              text={service.headline}
              highlightWords={HIGHLIGHT_WORDS[service.slug]}
              delay={0.15}
            />
          </h1>
          <Reveal delay={0.4}>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
              {service.description}
            </p>
          </Reveal>
          <Reveal delay={0.55} as="div">
            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <Button href="/contact" magnetic variant="primary" size="lg">
                Get a Quote
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button href="#pricing" variant="outline" size="lg">
                View Pricing
              </Button>
            </div>
          </Reveal>
          <Reveal delay={0.7} as="div">
            <p className="mt-8 font-mono text-xs uppercase tracking-[0.25em] text-brand-gray">
              {service.tagline}
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Final CTA section                                                           */
/* -------------------------------------------------------------------------- */

function FinalCtaSection() {
  return (
    <section className="relative isolate flex min-h-[70vh] items-center overflow-hidden bg-brand-black">
      <div className="absolute inset-0" aria-hidden="true">
        <Scene3D kind="cta" interactive className="opacity-60" />
      </div>
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-brand-black/70 via-brand-black/60 to-brand-black"
      />
      <div className={cn(SECTION, "relative z-10 w-full py-24")}>
        <div className="mx-auto flex max-w-4xl flex-col items-center text-center">
          <Reveal>
            <Eyebrow>LET'S BUILD</Eyebrow>
          </Reveal>
          <h2 className="mt-6 font-poster text-4xl uppercase leading-[0.92] text-white sm:text-5xl md:text-6xl lg:text-7xl">
            <RevealText
              text="READY TO START YOUR PROJECT?"
              highlightWords={["READY", "START", "PROJECT?"]}
              delay={0.15}
            />
          </h2>
          <Reveal delay={0.4}>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg">
              Tell us about your brand, your goals, and your timeline. We&apos;ll
              send a tailored proposal with clear scope, deliverables, and
              pricing — usually within 1–2 working days.
            </p>
          </Reveal>
          <Reveal
            delay={0.55}
            as="div"
            className="mt-10 flex flex-col gap-4 sm:flex-row"
          >
            <Button href="/contact" magnetic variant="primary" size="lg">
              Start a Project
              <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button href="/services" variant="outline" size="lg">
              View All Services
            </Button>
          </Reveal>
          <Reveal delay={0.7} as="div">
            <div className="mt-10 inline-flex items-center gap-2 rounded-full border border-white/10 bg-brand-charcoal/60 px-4 py-2">
              <Sparkles className="h-3.5 w-3.5 text-brand-yellow" />
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-brand-gray">
                KYVROXA Creatives
              </span>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export default ServicePageClient;
