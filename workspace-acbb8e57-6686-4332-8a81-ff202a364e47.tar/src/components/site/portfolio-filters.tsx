"use client";

import * as React from "react";
import { motion, AnimatePresence, LayoutGroup } from "framer-motion";
import { PORTFOLIO_ITEMS, type PortfolioItem, type ServiceSlug } from "@/lib/site-data";
import { PortfolioCard } from "@/components/site/portfolio-card";
import { cn } from "@/lib/utils";

type FilterValue = "ALL" | ServiceSlug;

interface Pill {
  value: FilterValue;
  label: string;
}

const SERVICE_PILLS: Pill[] = [
  { value: "ALL", label: "All Work" },
  { value: "graphic-designing", label: "Brand Identity" },
  { value: "website-designing", label: "Web Design" },
  { value: "mobile-app-designing", label: "Mobile App UI/UX" },
  { value: "video-editing", label: "Video & Motion" },
  { value: "social-media-marketing", label: "Social Media" },
  { value: "digital-marketing", label: "Digital Marketing" },
];

/**
 * PortfolioFilters — client component that maintains the active category
 * pill state and animates the filtered grid using framer-motion's `layout`
 * + AnimatePresence for smooth re-layout on filter change.
 */
export function PortfolioFilters({ items }: { items: PortfolioItem[] }) {
  const [active, setActive] = React.useState<FilterValue>("ALL");

  const filtered = React.useMemo(() => {
    if (active === "ALL") return items;
    return items.filter((item) => item.categorySlug === active);
  }, [active, items]);

  return (
    <div>
      {/* Pill toggles */}
      <div
        role="tablist"
        aria-label="Filter portfolio by category"
        className="flex flex-wrap gap-2"
      >
        {SERVICE_PILLS.map((pill) => {
          const isActive = pill.value === active;
          return (
            <button
              key={pill.value}
              role="tab"
              type="button"
              aria-selected={isActive}
              onClick={() => setActive(pill.value)}
              className={cn(
                "relative inline-flex h-9 items-center rounded-full border px-4 font-mono text-xs uppercase tracking-wider transition-colors",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black",
                isActive
                  ? "border-brand-yellow bg-brand-yellow text-brand-black"
                  : "border-white/10 bg-transparent text-white/80 hover:border-brand-yellow/60 hover:text-white",
              )}
            >
              {pill.label}
              {isActive ? (
                <motion.span
                  layoutId="pill-underline"
                  className="absolute inset-0 -z-10 rounded-full bg-brand-yellow"
                  transition={{ type: "spring", stiffness: 380, damping: 32 }}
                />
              ) : null}
            </button>
          );
        })}
      </div>

      {/* Filtered grid */}
      <LayoutGroup>
        <motion.div
          layout
          className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          <AnimatePresence mode="popLayout" initial={false}>
            {filtered.map((item) => (
              <motion.div
                key={item.slug}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              >
                <PortfolioCard item={item} />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Empty state */}
        {filtered.length === 0 ? (
          <p className="mt-12 text-center font-mono text-sm text-brand-gray">
            No projects in this category yet.
          </p>
        ) : null}
      </LayoutGroup>

      {/* Visible items count (accessibility hint) */}
      <p className="sr-only" aria-live="polite">
        Showing {filtered.length} of {items.length} projects.
      </p>
    </div>
  );
}

export default PortfolioFilters;
