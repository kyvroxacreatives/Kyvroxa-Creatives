"use client";

import { ArrowUp } from "lucide-react";

/** Inline back-to-top control used at the bottom of legal pages. */
export function BackToTopInline() {
  return (
    <div className="border-t border-white/5 bg-brand-charcoal">
      <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-gray transition-colors hover:text-brand-yellow"
        >
          <ArrowUp className="h-3.5 w-3.5" />
          Back to top
        </button>
      </div>
    </div>
  );
}

export default BackToTopInline;
