"use client";

import * as React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { PricingCard } from "@/components/site/pricing-card";
import {
  SERVICES,
  type ServiceData,
  type ServiceSlug,
} from "@/lib/site-data";
import { cn } from "@/lib/utils";

type FilterValue = "ALL" | ServiceSlug;

const ALL: { value: FilterValue; label: string } = { value: "ALL", label: "All Services" };

const SERVICE_FILTERS: { value: ServiceSlug; label: string }[] = SERVICES.map(
  (s) => ({ value: s.slug, label: s.shortName }),
);

/** Helper: best-effort parse of a starting price like "PKR 8,000" → numeric. */
function parsePrice(price: string): number {
  const m = price.match(/[\d,]+/);
  if (!m) return 0;
  return Number(m[0].replace(/,/g, ""));
}

function startingPrice(s: ServiceData): number {
  return Math.min(...s.packages.map((p) => parsePrice(p.price)));
}

function formatPKR(n: number): string {
  return `from PKR ${n.toLocaleString("en-PK")}`;
}

/**
 * PricingFilter — client component that exposes pill toggles for each
 * service (plus an "All Services" pill), then renders the selected service
 * section(s). On desktop each section is a 3-card grid; on mobile it
 * collapses into a shadcn <Accordion> where the collapsed summary shows
 * the service title + starting price, and the expanded panel shows the
 * three <PricingCard> components.
 *
 * Cadence badge: "MONTHLY" if any package in the service has a `cadence`
 * value, otherwise "ONE-TIME PROJECT".
 */
export function PricingFilter() {
  const [active, setActive] = React.useState<FilterValue>("ALL");

  const visibleServices =
    active === "ALL"
      ? SERVICES
      : SERVICES.filter((s) => s.slug === active);

  return (
    <div>
      {/* Pills */}
      <div
        role="tablist"
        aria-label="Filter pricing by service"
        className="flex flex-wrap gap-2"
      >
        {[ALL, ...SERVICE_FILTERS].map((pill) => {
          const isActive = pill.value === active;
          return (
            <button
              key={pill.value}
              role="tab"
              type="button"
              aria-selected={isActive}
              onClick={() => setActive(pill.value)}
              className={cn(
                "relative inline-flex h-9 items-center rounded-full border px-4 font-mono text-xs uppercase tracking-wider transition-colors",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black",
                isActive
                  ? "border-brand-yellow bg-brand-yellow text-brand-black"
                  : "border-white/10 bg-transparent text-white/80 hover:border-brand-yellow/60 hover:text-white",
              )}
            >
              {pill.label}
            </button>
          );
        })}
      </div>

      {/* Desktop grid sections */}
      <div className="mt-10 hidden flex-col gap-16 md:flex">
        {visibleServices.map((service) => (
          <PricingSection
            key={service.slug}
            service={service}
          />
        ))}
      </div>

      {/* Mobile accordion sections */}
      <div className="mt-8 md:hidden">
        <Accordion type="single" collapsible className="flex flex-col gap-3">
          {visibleServices.map((service) => (
            <AccordionItem
              key={service.slug}
              value={service.slug}
              className="overflow-hidden rounded-2xl border border-white/8 bg-brand-charcoal px-4 data-[state=open]:border-brand-yellow/40"
            >
              <AccordionTrigger className="items-center text-left hover:no-underline">
                <div className="flex w-full items-center justify-between gap-3 pr-2">
                  <div className="flex flex-col items-start gap-0.5">
                    <span className="font-display text-base font-semibold text-white">
                      {service.shortName}
                    </span>
                    <span className="font-mono text-[11px] uppercase tracking-wider text-brand-gray">
                      {formatPKR(startingPrice(service))}
                    </span>
                  </div>
                  <CadenceBadge service={service} />
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4">
                <div className="flex flex-col gap-4">
                  {service.packages.map((pkg) => (
                    <PricingCard key={pkg.name} pkg={pkg} />
                  ))}
                  {service.exclusions ? (
                    <ScopeNote note={service.exclusions} />
                  ) : null}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}

function PricingSection({ service }: { service: ServiceData }) {
  return (
    <section id={`pricing-${service.slug}`}>
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h3 className="font-display text-2xl font-bold text-white sm:text-3xl">
            {service.title}
          </h3>
          <p className="mt-1 text-sm text-brand-gray">
            {formatPKR(startingPrice(service))} · {service.packages.length} packages
          </p>
        </div>
        <CadenceBadge service={service} />
      </div>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        {service.packages.map((pkg) => (
          <PricingCard key={pkg.name} pkg={pkg} />
        ))}
      </div>
      {service.exclusions ? (
        <div className="mt-6">
          <ScopeNote note={service.exclusions} />
        </div>
      ) : null}
    </section>
  );
}

function CadenceBadge({ service }: { service: ServiceData }) {
  const hasMonthly = service.packages.some(
    (p) => typeof p.cadence === "string" && p.cadence.length > 0,
  );
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em]",
        hasMonthly
          ? "border-brand-yellow/40 bg-brand-yellow/5 text-brand-yellow"
          : "border-white/10 bg-white/5 text-white/70",
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          "inline-block h-1.5 w-1.5 rounded-full",
          hasMonthly ? "bg-brand-yellow" : "bg-white/40",
        )}
      />
      {hasMonthly ? "Monthly" : "One-time Project"}
    </span>
  );
}

function ScopeNote({ note }: { note: string }) {
  return (
    <aside
      role="note"
      className="rounded-lg border-l-2 border-brand-yellow/60 bg-brand-black/40 p-4"
    >
      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-brand-yellow">
        Scope Note
      </p>
      <p className="mt-2 text-xs leading-relaxed text-brand-gray">{note}</p>
    </aside>
  );
}

export default PricingFilter;
