"use client";

import * as React from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { Check, Loader2, Send, Upload, X } from "lucide-react";

import {
  CONTACT_FORM_SERVICES,
  BUDGET_RANGES,
  TIMELINE_OPTIONS,
} from "@/lib/site-data";
import {
  contactSchema,
  type ContactInput,
  ACCEPTED_FILE_TYPES,
  MAX_FILE_BYTES,
} from "@/lib/validations/contact";
import { cn } from "@/lib/utils";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/site/button";

interface FileMeta {
  name: string;
  type: string;
  size: number;
}

/**
 * ContactForm — react-hook-form + zod validated client form.
 *
 * Fields:
 *   - fullName* (min 2)
 *   - businessName (optional)
 *   - email* (validated)
 *   - whatsapp (optional)
 *   - service* (select)
 *   - budget* (select)
 *   - timeline* (select)
 *   - description* (textarea, min 30)
 *   - file (optional — PDF/images, max 5MB; only metadata is sent)
 *
 * Honeypot: `company_website` — visually hidden, must stay empty. The
 * API silently rejects honeypot submissions while returning success.
 *
 * POSTs to /api/contact, shows Sonner toasts on success / error, and
 * replaces the form with a success panel after a clean submit.
 */
export function ContactForm() {
  const [submitted, setSubmitted] = React.useState(false);
  const [fileMeta, setFileMeta] = React.useState<FileMeta | null>(null);
  const [fileError, setFileError] = React.useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    control,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ContactInput>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      fullName: "",
      businessName: "",
      email: "",
      whatsapp: "",
      description: "",
      company_website: "",
    },
  });

  const service = useWatch({ control, name: "service" });
  const budget = useWatch({ control, name: "budget" });
  const timeline = useWatch({ control, name: "timeline" });

  // Radix Select is controlled, so we need to register its value via setValue.
  const onSelectChange = (field: keyof ContactInput) => (value: string) => {
    setValue(field, value as ContactInput[typeof field], {
      shouldValidate: true,
      shouldDirty: true,
    });
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null);
    const f = e.target.files?.[0];
    if (!f) {
      setFileMeta(null);
      return;
    }
    if (!ACCEPTED_FILE_TYPES.includes(f.type as (typeof ACCEPTED_FILE_TYPES)[number])) {
      setFileMeta(null);
      setFileError("Unsupported file type. Please upload a PDF or image (PNG, JPG, WEBP, GIF).");
      e.target.value = "";
      return;
    }
    if (f.size > MAX_FILE_BYTES) {
      setFileMeta(null);
      setFileError("File exceeds the 5MB limit.");
      e.target.value = "";
      return;
    }
    setFileMeta({ name: f.name, type: f.type, size: f.size });
  };

  const clearFile = () => {
    setFileMeta(null);
    setFileError(null);
    const el = document.getElementById("file-input") as HTMLInputElement | null;
    if (el) el.value = "";
  };

  const onSubmit = async (values: ContactInput) => {
    if (fileError) return;

    const payload = { ...values, file: fileMeta ?? undefined };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as
        | { ok: true; id?: string; spam?: true }
        | { ok: false; errors: { field: string; message: string }[] };

      if (!res.ok || !data.ok) {
        const errs = "errors" in data ? data.errors : [];
        if (errs.length > 0) {
          errs.forEach((e) =>
            toast.error(e.message, {
              description: e.field !== "form" ? `Field: ${e.field}` : undefined,
            }),
          );
        } else {
          toast.error("Something went wrong. Please try again.");
        }
        return;
      }

      // Silent honeypot — pretend success without disclosing.
      toast.success("Message received", {
        description: "We'll review your brief and reply within 1–2 working days.",
      });
      setSubmitted(true);
      reset();
      clearFile();
    } catch {
      toast.error("Network error. Please check your connection and try again.");
    }
  };

  if (submitted) {
    return (
      <div
        role="status"
        className="flex h-full flex-col items-center justify-center gap-5 rounded-2xl border border-brand-yellow/40 bg-brand-charcoal p-8 text-center sm:p-12"
      >
        <span
          aria-hidden="true"
          className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-yellow text-brand-black shadow-[0_0_40px_-5px_rgba(255,213,0,0.5)]"
        >
          <Check className="h-8 w-8" strokeWidth={3} />
        </span>
        <h3 className="font-display text-2xl font-bold text-white">
          Message received
        </h3>
        <p className="max-w-sm text-sm leading-relaxed text-brand-gray">
          We&apos;ll review your brief and reply within 1–2 working days.
        </p>
        <Button href="/" variant="primary" size="md" className="mt-2">
          Back to Home
        </Button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      noValidate
      className="flex flex-col gap-5 rounded-2xl border border-white/10 bg-brand-charcoal p-6 sm:p-8"
      aria-label="Contact form"
    >
      {/* Honeypot — visually hidden, must remain empty */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor="company_website">Website</label>
        <input
          id="company_website"
          type="text"
          tabIndex={-1}
          autoComplete="off"
          {...register("company_website")}
        />
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <Field label="Full name" htmlFor="fullName" required error={errors.fullName?.message}>
          <Input
            id="fullName"
            placeholder="Your name"
            autoComplete="name"
            aria-invalid={!!errors.fullName}
            aria-describedby={errors.fullName ? "fullName-error" : undefined}
            {...register("fullName")}
          />
        </Field>

        <Field label="Business name" htmlFor="businessName" error={errors.businessName?.message}>
          <Input
            id="businessName"
            placeholder="Optional"
            autoComplete="organization"
            {...register("businessName")}
          />
        </Field>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <Field label="Email" htmlFor="email" required error={errors.email?.message}>
          <Input
            id="email"
            type="email"
            placeholder="you@example.com"
            autoComplete="email"
            aria-invalid={!!errors.email}
            {...register("email")}
          />
        </Field>

        <Field label="WhatsApp" htmlFor="whatsapp" error={errors.whatsapp?.message}>
          <Input
            id="whatsapp"
            type="tel"
            placeholder="Optional"
            autoComplete="tel"
            {...register("whatsapp")}
          />
        </Field>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <Field label="Service required" htmlFor="service" required error={errors.service?.message}>
          <Select value={service} onValueChange={onSelectChange("service")}>
            <SelectTrigger
              id="service"
              className={cn(
                "h-9 w-full border-white/10 bg-transparent text-white",
                errors.service && "border-destructive",
              )}
              aria-invalid={!!errors.service}
            >
              <SelectValue placeholder="Choose a service" />
            </SelectTrigger>
            <SelectContent>
              {CONTACT_FORM_SERVICES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        <Field label="Budget range" htmlFor="budget" required error={errors.budget?.message}>
          <Select value={budget} onValueChange={onSelectChange("budget")}>
            <SelectTrigger
              id="budget"
              className={cn(
                "h-9 w-full border-white/10 bg-transparent text-white",
                errors.budget && "border-destructive",
              )}
              aria-invalid={!!errors.budget}
            >
              <SelectValue placeholder="Select range" />
            </SelectTrigger>
            <SelectContent>
              {BUDGET_RANGES.map((b) => (
                <SelectItem key={b} value={b}>
                  {b}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        <Field label="Project timeline" htmlFor="timeline" required error={errors.timeline?.message}>
          <Select value={timeline} onValueChange={onSelectChange("timeline")}>
            <SelectTrigger
              id="timeline"
              className={cn(
                "h-9 w-full border-white/10 bg-transparent text-white",
                errors.timeline && "border-destructive",
              )}
              aria-invalid={!!errors.timeline}
            >
              <SelectValue placeholder="Select timeline" />
            </SelectTrigger>
            <SelectContent>
              {TIMELINE_OPTIONS.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      </div>

      <Field
        label="Project description"
        htmlFor="description"
        required
        error={errors.description?.message}
        hint="Minimum 30 characters — share your goals, audience, references, and any constraints."
      >
        <Textarea
          id="description"
          rows={5}
          placeholder="Briefly describe your project, goals, and any key context."
          aria-invalid={!!errors.description}
          {...register("description")}
        />
      </Field>

      {/* File upload (optional) */}
      <Field
        label="Brief or reference file (optional)"
        htmlFor="file-input"
        error={fileError ?? undefined}
        hint="PDF or images up to 5MB. Files aren't stored — we only record the file name."
      >
        <div className="flex flex-wrap items-center gap-3">
          <label
            htmlFor="file-input"
            className="inline-flex h-9 cursor-pointer items-center gap-2 rounded-md border border-white/15 px-4 font-display text-xs font-medium uppercase tracking-wider text-white transition-colors hover:border-brand-yellow hover:text-brand-yellow focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-yellow focus-within:ring-offset-2 focus-within:ring-offset-brand-black"
          >
            <Upload className="h-3.5 w-3.5" />
            Choose file
            <input
              id="file-input"
              type="file"
              accept={ACCEPTED_FILE_TYPES.join(",")}
              onChange={handleFile}
              className="sr-only"
            />
          </label>
          {fileMeta ? (
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-yellow/40 bg-brand-yellow/5 px-3 py-1 text-xs text-white/85">
              <span className="max-w-[180px] truncate">{fileMeta.name}</span>
              <span className="font-mono text-[10px] text-brand-gray">
                {(fileMeta.size / 1024).toFixed(0)} KB
              </span>
              <button
                type="button"
                onClick={clearFile}
                aria-label="Remove file"
                className="text-brand-gray transition-colors hover:text-brand-yellow"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </span>
          ) : (
            <span className="text-xs text-brand-gray">No file selected</span>
          )}
        </div>
      </Field>

      <div className="mt-2 flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-brand-gray">
          By submitting, you agree to be contacted about your inquiry. We never
          share your information.
        </p>
        <Button
          type="submit"
          variant="primary"
          size="lg"
          magnetic={false}
          className={cn(isSubmitting && "pointer-events-none opacity-80")}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Send className="h-4 w-4" />
          )}
          {isSubmitting ? "Sending…" : "Send Message"}
        </Button>
      </div>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  required,
  error,
  hint,
  children,
}: {
  label: string;
  htmlFor: string;
  required?: boolean;
  error?: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={htmlFor} className="text-xs uppercase tracking-wider text-white/85">
        {label}
        {required ? (
          <span aria-hidden="true" className="ml-1 text-brand-yellow">
            *
          </span>
        ) : null}
      </Label>
      {children}
      {hint && !error ? (
        <p className="text-[11px] leading-relaxed text-brand-gray">{hint}</p>
      ) : null}
      {error ? (
        <p
          id={`${htmlFor}-error`}
          role="alert"
          className="text-[11px] leading-relaxed text-red-400"
        >
          {error}
        </p>
      ) : null}
    </div>
  );
}

export default ContactForm;
