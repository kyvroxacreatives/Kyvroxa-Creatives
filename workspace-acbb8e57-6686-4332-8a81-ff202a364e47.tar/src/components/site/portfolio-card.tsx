import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import type { PortfolioItem } from "@/lib/site-data";
import { cn } from "@/lib/utils";

/**
 * PortfolioCard — 4/3 aspect preview image + status badge + arrow + meta.
 * Uses <Image src="/portfolio/{slug}.png"> (mockups generated separately).
 * Hover: scale 1.05 on image, yellow border.
 */
export function PortfolioCard({
  item,
  className,
}: {
  item: PortfolioItem;
  className?: string;
}) {
  return (
    <Link
      href={`/portfolio/${item.slug}`}
      className={cn(
        "group relative block h-full overflow-hidden rounded-2xl border border-white/8 bg-brand-charcoal transition-all duration-300 hover:border-brand-yellow",
        className,
      )}
    >
      {/* 4/3 preview area */}
      <div className="relative aspect-[4/3] overflow-hidden bg-brand-black">
        {/* fallback gradient layer (visible if image missing) */}
        <div
          aria-hidden="true"
          className={cn(
            "absolute inset-0 bg-gradient-to-br",
            item.accent || "from-brand-yellow/30 to-transparent",
          )}
        />
        <Image
          src={`/portfolio/${item.slug}.png`}
          alt={item.title}
          fill
          sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
          className="relative object-cover transition-transform duration-500 ease-out group-hover:scale-[1.05]"
        />
        {/* status badge top-left */}
        <span className="absolute left-3 top-3 inline-flex items-center rounded-full border border-white/15 bg-brand-black/70 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-white/85 backdrop-blur">
          {item.status}
        </span>
        {/* arrow icon top-right */}
        <span className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-brand-black/70 text-white backdrop-blur transition-all duration-300 group-hover:border-brand-yellow group-hover:bg-brand-yellow group-hover:text-brand-black">
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </span>
      </div>

      {/* meta */}
      <div className="flex flex-col gap-2 p-5">
        <span className="font-mono text-xs uppercase tracking-[0.2em] text-brand-yellow">
          {item.category}
        </span>
        <h3 className="font-display text-lg font-bold leading-tight text-white transition-colors group-hover:text-brand-yellow">
          {item.title}
        </h3>
        <p className="line-clamp-2 text-sm leading-relaxed text-brand-gray">
          {item.summary}
        </p>
        <div className="mt-1 flex flex-wrap gap-1.5">
          {item.services.map((s) => (
            <span
              key={s}
              className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] text-white/75"
            >
              {s}
            </span>
          ))}
        </div>
      </div>
    </Link>
  );
}

export default PortfolioCard;
