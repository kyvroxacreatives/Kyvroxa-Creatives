"use client";

import { motion, useScroll, useSpring } from "framer-motion";

/**
 * ScrollProgress — thin yellow top progress bar.
 * Uses framer-motion useScroll + useSpring.
 */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 28,
    restDelta: 0.001,
  });

  return (
    <motion.div
      aria-hidden="true"
      className="fixed left-0 right-0 top-0 z-[60] h-0.5 origin-left bg-brand-yellow shadow-[0_0_10px_rgba(255,213,0,0.7)]"
      style={{ scaleX }}
    />
  );
}

export default ScrollProgress;
