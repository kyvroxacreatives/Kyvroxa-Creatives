import Link from "next/link";
import { ArrowUpRight, Box } from "lucide-react";
import type { ServiceData } from "@/lib/site-data";
import { cn } from "@/lib/utils";

/**
 * ServiceCard — uniform card for services grid (NOT asymmetric).
 * Number (01-06), title, tagline, 3 deliverables as pills, "Explore Service" link.
 * Hover: yellow border + sweep gradient + scale cube accent.
 * Uses h-full so cards fill their grid cell.
 */
export function ServiceCard({
  service,
  index,
  className,
}: {
  service: ServiceData;
  index: number;
  className?: string;
}) {
  const num = String(index + 1).padStart(2, "0");
  const href = `/services/${service.slug}`;

  return (
    <Link
      href={href}
      className={cn(
        "group relative block h-full overflow-hidden rounded-2xl border border-white/8 bg-brand-charcoal p-6 transition-all duration-300 hover:border-brand-yellow",
        className,
      )}
    >
      {/* sweep gradient on hover */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-br from-brand-yellow/10 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"
      />

      <div className="relative z-10 flex h-full flex-col gap-5">
        <div className="flex items-start justify-between">
          <span className="font-mono text-xs text-brand-yellow">{num}</span>
          {/* scale cube accent on hover */}
          <Box className="h-5 w-5 text-white/20 transition-all duration-300 group-hover:scale-110 group-hover:text-brand-yellow" />
        </div>

        <div className="flex flex-col gap-2">
          <h3 className="font-display text-xl font-bold leading-tight text-white transition-colors group-hover:text-brand-yellow">
            {service.title}
          </h3>
          <p className="text-sm leading-relaxed text-brand-gray">
            {service.tagline}
          </p>
        </div>

        {/* deliverables as pills — take first 3 */}
        <div className="flex flex-wrap gap-1.5">
          {service.deliverables.slice(0, 3).map((d) => (
            <span
              key={d}
              className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-white/80"
            >
              {d}
            </span>
          ))}
        </div>

        <div className="mt-auto flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider text-white transition-colors group-hover:text-brand-yellow">
          Explore Service
          <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </div>
      </div>
    </Link>
  );
}

export default ServiceCard;
