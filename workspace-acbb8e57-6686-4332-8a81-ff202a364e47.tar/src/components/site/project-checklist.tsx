"use client";

import * as React from "react";
import { Printer, CheckCircle2 } from "lucide-react";
import { Reveal } from "@/components/site/reveal";
import { cn } from "@/lib/utils";

const CHECKLIST_ITEMS = [
  {
    title: "Business background",
    detail:
      "What your business does, who you serve, and what makes you different. A short brief is enough to start.",
  },
  {
    title: "Target audience",
    detail:
      "Who you're trying to reach — demographics, behaviours, pain points, and the single most important action you want them to take.",
  },
  {
    title: "Goals and success metrics",
    detail:
      "What does a successful outcome look like? Where possible, define it in measurable terms (sign-ups, leads, ROAS, etc.).",
  },
  {
    title: "References and inspiration",
    detail:
      "Brands, designs, or campaigns you love (and what you like about them). Helps us calibrate direction quickly.",
  },
  {
    title: "Brand assets",
    detail:
      "Logos, fonts, colors, existing guidelines, photography, or product imagery you already have.",
  },
  {
    title: "Content and copy",
    detail:
      "Final or draft copy, messaging pillars, value propositions, and any legal or compliance constraints.",
  },
  {
    title: "Access to platforms",
    detail:
      "Logins or permissions for relevant platforms (CMS, social accounts, ad managers, analytics) when applicable.",
  },
];

/**
 * ProjectChecklist — a client component containing the 7-item client
 * preparation checklist and a "Print Checklist" button that triggers
 * `window.print()`.
 */
export function ProjectChecklist() {
  const [checked, setChecked] = React.useState<Record<number, boolean>>({});

  const toggle = (i: number) =>
    setChecked((prev) => ({ ...prev, [i]: !prev[i] }));

  const handlePrint = () => {
    if (typeof window !== "undefined") window.print();
  };

  return (
    <Reveal>
      <div
        id="project-checklist"
        className="rounded-2xl border border-white/10 bg-brand-charcoal p-6 sm:p-8 print:border-brand-yellow"
      >
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-[0.25em] text-brand-yellow">
              <span
                aria-hidden="true"
                className="inline-block h-1.5 w-1.5 rounded-full bg-brand-yellow shadow-[0_0_8px_rgba(255,213,0,0.7)]"
              />
              CLIENT PREP
            </span>
            <h3 className="mt-3 font-display text-2xl font-bold text-white sm:text-3xl">
              Project Checklist
            </h3>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-brand-gray">
              Seven things to prepare before we start. The clearer your brief,
              the faster we can move.
            </p>
          </div>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex h-10 items-center gap-2 rounded-md border border-brand-yellow px-4 font-display text-xs font-medium uppercase tracking-wider text-brand-yellow transition-colors hover:bg-brand-yellow hover:text-brand-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black print:hidden"
          >
            <Printer className="h-4 w-4" />
            Print Checklist
          </button>
        </div>

        <ul className="flex flex-col gap-3 print:gap-2">
          {CHECKLIST_ITEMS.map((item, i) => {
            const isChecked = !!checked[i];
            return (
              <li key={item.title}>
                <button
                  type="button"
                  onClick={() => toggle(i)}
                  aria-pressed={isChecked}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-lg border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black",
                    isChecked
                      ? "border-brand-yellow/40 bg-brand-yellow/5"
                      : "border-white/8 bg-brand-black/40 hover:border-white/15",
                  )}
                >
                  <span
                    aria-hidden="true"
                    className={cn(
                      "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-colors",
                      isChecked
                        ? "border-brand-yellow bg-brand-yellow text-brand-black"
                        : "border-white/15 text-transparent",
                    )}
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  </span>
                  <span className="flex flex-col">
                    <span className="font-display text-sm font-semibold text-white">
                      {item.title}
                    </span>
                    <span className="mt-1 text-sm leading-relaxed text-brand-gray">
                      {item.detail}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </Reveal>
  );
}

export default ProjectChecklist;
