"use client";

import * as React from "react";
import Link from "next/link";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { cn } from "@/lib/utils";

type Variant = "primary" | "outline" | "ghost" | "white" | "dark";
type Size = "sm" | "md" | "lg";

const VARIANT_CLASSES: Record<Variant, string> = {
  primary:
    "bg-brand-yellow text-brand-black hover:bg-white hover:text-brand-black border border-transparent",
  outline:
    "bg-transparent text-white border border-brand-yellow hover:bg-brand-yellow hover:text-brand-black",
  ghost:
    "bg-transparent text-white border border-transparent hover:text-brand-yellow",
  white:
    "bg-white text-brand-black hover:bg-brand-yellow hover:text-brand-black border border-transparent",
  dark: "bg-brand-charcoal text-white border border-white/10 hover:bg-white/5 hover:text-brand-yellow",
};

const SIZE_CLASSES: Record<Size, string> = {
  sm: "h-9 px-4 text-xs",
  md: "h-11 px-6 text-sm",
  lg: "h-14 px-8 text-base",
};

// Motion-enabled Link — declared OUTSIDE the render function so we don't
// create components during render (framer-motion v12 uses motion.create).
const MotionLink = motion.create(Link);

// Drag/animation handler names collide between framer-motion and React's
// native DOM handlers (e.g. onDragStart, onAnimationStart). We omit them from
// our public ButtonProps so the spread into motion.button stays type-safe.
type ConflictingHandlers =
  | "onDrag"
  | "onDragStart"
  | "onDragEnd"
  | "onAnimationStart"
  | "onAnimationIteration"
  | "onAnimationEnd"
  | "onTransitionEnd";

interface ButtonProps
  extends Omit<React.ComponentProps<"button">, "ref" | ConflictingHandlers> {
  variant?: Variant;
  size?: Size;
  magnetic?: boolean;
  href?: string;
  children: React.ReactNode;
}

/**
 * MagneticButton — KYVROXA brand button.
 * - 5 variants: primary (yellow), outline (yellow border), ghost, white, dark.
 * - 3 sizes.
 * - magnetic: when true, the button translates toward the cursor on hover
 *   using framer-motion + useSpring for a smooth elastic pull.
 * - href: when provided, renders as a Next.js <Link>.
 */
export function Button({
  variant = "primary",
  size = "md",
  magnetic = false,
  href,
  className,
  children,
  ...props
}: ButtonProps) {
  const ref = React.useRef<HTMLAnchorElement | HTMLButtonElement | null>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 200, damping: 14, mass: 0.3 });
  const sy = useSpring(y, { stiffness: 200, damping: 14, mass: 0.3 });

  const handleMove = (e: React.MouseEvent) => {
    if (!magnetic || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const relX = e.clientX - (rect.left + rect.width / 2);
    const relY = e.clientY - (rect.top + rect.height / 2);
    x.set(relX * 0.25);
    y.set(relY * 0.35);
  };
  const handleLeave = () => {
    x.set(0);
    y.set(0);
  };

  const classes = cn(
    "relative inline-flex items-center justify-center gap-2 rounded-md font-display font-medium uppercase tracking-wider transition-colors duration-200 outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black",
    VARIANT_CLASSES[variant],
    SIZE_CLASSES[size],
    className,
  );

  const inner = (
    <span className="relative z-10 inline-flex items-center gap-2">
      {children}
    </span>
  );

  if (href) {
    if (magnetic) {
      return (
        <MotionLink
          ref={ref as React.Ref<HTMLAnchorElement>}
          href={href}
          className={classes}
          style={{ x: sx, y: sy }}
          onMouseMove={handleMove}
          onMouseLeave={handleLeave}
        >
          {inner}
        </MotionLink>
      );
    }
    return (
      <Link href={href} className={classes}>
        {inner}
      </Link>
    );
  }

  if (magnetic) {
    return (
      <motion.button
        ref={ref as React.Ref<HTMLButtonElement>}
        className={classes}
        style={{ x: sx, y: sy }}
        onMouseMove={handleMove}
        onMouseLeave={handleLeave}
        {...props}
      >
        {inner}
      </motion.button>
    );
  }

  return (
    <button className={classes} {...props}>
      {inner}
    </button>
  );
}

export default Button;
