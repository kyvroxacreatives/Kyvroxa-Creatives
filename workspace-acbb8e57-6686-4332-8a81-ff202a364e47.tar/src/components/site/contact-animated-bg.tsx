"use client";

import * as React from "react";
import { motion } from "framer-motion";

/**
 * ContactAnimatedBg — subtle, premium animated background for the contact page.
 * Replaces the messy Scene3D with breathing gradients + floating particles.
 */
export function ContactAnimatedBg() {
  const particles = React.useMemo(
    () =>
      Array.from({ length: 20 }).map((_, i) => ({
        id: i,
        left: `${Math.random() * 100}%`,
        size: 2 + Math.random() * 3,
        duration: 14 + Math.random() * 16,
        delay: Math.random() * 8,
        opacity: 0.2 + Math.random() * 0.4,
      })),
    [],
  );

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      <div className="absolute inset-0 bg-grid opacity-[0.03]" />
      <motion.div
        className="absolute h-[600px] w-[600px] rounded-full bg-brand-yellow/[0.06] blur-[100px]"
        animate={{ x: ["-10%", "10%", "-10%"], y: ["-5%", "5%", "-5%"], scale: [1, 1.1, 1], opacity: [0.4, 0.6, 0.4] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        style={{ top: "20%", left: "30%" }}
      />
      <motion.div
        className="absolute h-[400px] w-[400px] rounded-full bg-brand-yellow/[0.04] blur-[80px]"
        animate={{ x: ["5%", "-5%", "5%"], y: ["10%", "-10%", "10%"], scale: [1, 1.15, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        style={{ bottom: "10%", right: "20%" }}
      />
      {particles.map((p) => (
        <motion.span
          key={p.id}
          className="absolute rounded-full bg-brand-yellow"
          style={{ left: p.left, bottom: "-10px", width: p.size, height: p.size }}
          animate={{ y: [0, -600 - Math.random() * 200], opacity: [0, p.opacity, 0], scale: [0.5, 1, 0.5] }}
          transition={{ duration: p.duration, repeat: Infinity, delay: p.delay, ease: "linear" }}
        />
      ))}
      <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-brand-black to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-brand-black to-transparent" />
    </div>
  );
}
