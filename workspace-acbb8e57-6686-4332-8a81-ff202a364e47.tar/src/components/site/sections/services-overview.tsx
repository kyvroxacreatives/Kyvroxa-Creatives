"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  SectionHeading,
  Reveal,
  RevealText,
  ServiceCard,
  Button,
} from "@/components/site";
import { SERVICES } from "@/lib/site-data";
import { ArrowRight } from "lucide-react";

export function ServicesOverview() {
  return (
    <section
      aria-labelledby="services-overview-title"
      className="relative w-full bg-brand-black px-4 py-20 sm:py-24 md:py-28"
    >
      <div className="mx-auto w-full max-w-7xl">
        <SectionHeading
          eyebrow="WHAT WE DO"
          title={
            <RevealText
              text="CREATIVE SERVICES. REAL-WORLD IMPACT."
              highlightWords={["IMPACT."]}
            />
          }
          description="Six focused practices under one studio. Each one is built around your business objectives — not a generic template — so the work you receive fits your brand and your market."
          align="center"
        />

        <motion.div
          variants={{
            hidden: {},
            show: {
              transition: { staggerChildren: 0.08, delayChildren: 0.05 },
            },
          }}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px 0px -80px 0px" }}
          className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3 lg:gap-6"
        >
          {SERVICES.map((service, i) => (
            <motion.div
              key={service.slug}
              variants={{
                hidden: { opacity: 0, y: 24 },
                show: {
                  opacity: 1,
                  y: 0,
                  transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] },
                },
              }}
            >
              <ServiceCard service={service} index={i} />
            </motion.div>
          ))}
        </motion.div>

        <Reveal
          delay={0.1}
          className="mt-10 flex justify-center sm:mt-12"
        >
          <Button href="/services" variant="outline" size="md">
            View All Services
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

export default ServicesOverview;
