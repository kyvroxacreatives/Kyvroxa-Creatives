"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Eyebrow, Button } from "@/components/site";
import { SERVICES } from "@/lib/site-data";
import { ArrowRight } from "lucide-react";

/* -------------------------------------------------------------------------- */
/*  Sparkle — 4-pointed yellow star with a soft breathing animation          */
/* -------------------------------------------------------------------------- */

function Sparkle({
  className,
  size = 28,
  delay = 0,
}: {
  className?: string;
  size?: number;
  delay?: number;
}) {
  return (
    <motion.svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      initial={{ opacity: 0, scale: 0.4, rotate: -30 }}
      animate={{
        opacity: [0, 0.85, 0.55, 0.85],
        scale: [0.6, 1.05, 0.95, 1.05],
        rotate: [-30, 0, 12, 0],
      }}
      transition={{
        duration: 4,
        delay,
        repeat: Infinity,
        repeatType: "mirror",
        ease: "easeInOut",
      }}
    >
      <path
        d="M12 0 C12.5 6 14 9.5 24 12 C14 14.5 12.5 18 12 24 C11.5 18 10 14.5 0 12 C10 9.5 11.5 6 12 0 Z"
        fill="#FFD500"
      />
    </motion.svg>
  );
}

/* -------------------------------------------------------------------------- */
/*  ServicesMarquee — full-width yellow strip with SERVICES names             */
/* -------------------------------------------------------------------------- */

function ServicesMarquee() {
  // Build a label list (shortName + tagline slug) for marquee.
  const labels = SERVICES.map((s) => s.shortName);
  const items = [...labels, ...labels]; // duplicate for seamless loop

  return (
    <div
      className="relative w-full overflow-hidden border-y border-brand-yellow/40 bg-brand-yellow py-3"
      role="marquee"
      aria-label="KYVROXA services"
    >
      <div className="flex w-max animate-marquee items-center gap-6 pr-6">
        {items.map((label, i) => (
          <React.Fragment key={`${label}-${i}`}>
            <span className="font-poster text-base uppercase tracking-tight text-brand-black sm:text-lg">
              {label}
            </span>
            <span
              aria-hidden="true"
              className="inline-block h-1.5 w-1.5 rounded-full bg-brand-black"
            />
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  HomeHero                                                                   */
/* -------------------------------------------------------------------------- */

export function HomeHero() {
  return (
    <section
      aria-label="KYVROXA Creatives — hero"
      className="relative flex min-h-[88vh] w-full flex-col items-center justify-start overflow-hidden bg-brand-black px-4 pb-0 pt-24 sm:min-h-[92vh] sm:pt-28"
    >
      {/* background: subtle grid + spotlight */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-grid opacity-70"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-spotlight"
      />
      {/* radial vignette to focus the eye on center */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 45%, transparent 0%, rgba(5,5,5,0.4) 55%, rgba(5,5,5,0.85) 100%)",
        }}
      />

      {/* sparkles in corners */}
      <Sparkle className="absolute left-[6%] top-[22%]" size={26} delay={0.2} />
      <Sparkle className="absolute right-[8%] top-[18%]" size={20} delay={0.9} />
      <Sparkle
        className="absolute left-[14%] bottom-[22%]"
        size={18}
        delay={1.6}
      />
      <Sparkle
        className="absolute right-[12%] bottom-[28%]"
        size={30}
        delay={2.4}
      />

      <div className="relative z-10 flex w-full max-w-5xl flex-1 flex-col items-center justify-center text-center">
        {/* availability chip */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.05 }}
          className="mb-7 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.22em] text-white/85 backdrop-blur"
        >
          <motion.span
            aria-hidden="true"
            className="inline-block h-1.5 w-1.5 rounded-full bg-brand-yellow"
            animate={{ opacity: [0.4, 1, 0.4], scale: [0.9, 1.15, 0.9] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            style={{ boxShadow: "0 0 10px rgba(255,213,0,0.8)" }}
          />
          Available for select projects
        </motion.div>

        {/* eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.12 }}
          className="mb-5 flex justify-center"
        >
          <Eyebrow className="justify-center">
            INDEPENDENT CREATIVE &amp; DIGITAL STUDIO
          </Eyebrow>
        </motion.div>

        {/* headline — mixed small + big typography, stacked, centered */}
        <h1 className="font-poster flex flex-col items-center justify-center leading-[0.92]">
          <motion.span
            className="font-display text-base font-medium uppercase tracking-[0.4em] text-brand-gray sm:text-lg"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
          >
            We Turn
          </motion.span>

          <motion.span
            className="block text-white"
            style={{
              fontSize: "clamp(2.75rem, 11vw, 9.5rem)",
              lineHeight: 0.92,
            }}
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.26, ease: [0.22, 1, 0.36, 1] }}
          >
            Creative Ideas
          </motion.span>

          <motion.span
            className="font-display text-base font-medium uppercase tracking-[0.4em] text-brand-gray sm:text-lg"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.34, ease: [0.22, 1, 0.36, 1] }}
          >
            Into
          </motion.span>

          <motion.span
            className="block text-brand-yellow"
            style={{
              fontSize: "clamp(2.75rem, 11vw, 9.5rem)",
              lineHeight: 0.92,
            }}
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.42, ease: [0.22, 1, 0.36, 1] }}
          >
            Digital Impact.
          </motion.span>
        </h1>

        {/* description */}
        <motion.p
          className="mt-8 max-w-2xl text-base leading-relaxed text-brand-gray sm:text-lg"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.55, ease: [0.22, 1, 0.36, 1] }}
        >
          KYVROXA Creatives is a design and digital studio building brand
          identities, websites, mobile UI, video, social, and growth campaigns —
          work that looks sharp and earns its place in the market.
        </motion.p>

        {/* CTA */}
        <motion.div
          className="mt-9 flex flex-col items-center gap-4 sm:flex-row"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.68, ease: [0.22, 1, 0.36, 1] }}
        >
          <Button
            href="/services/graphic-designing"
            variant="primary"
            size="lg"
            magnetic
            className="w-full sm:w-auto"
          >
            Explore Our Services
            <ArrowRight className="h-4 w-4" />
          </Button>
        </motion.div>
      </div>

      {/* spacer to push marquee to bottom of hero block */}
      <div className="relative z-10 mt-16 w-full">
        <ServicesMarquee />
      </div>
    </section>
  );
}

export default HomeHero;
