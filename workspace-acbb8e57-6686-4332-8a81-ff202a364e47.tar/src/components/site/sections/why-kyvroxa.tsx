"use client";

import * as React from "react";
import {
  motion,
  useInView,
  useSpring,
  useMotionValue,
  useScroll,
  useTransform,
  animate,
  type MotionValue,
} from "framer-motion";
import { SectionHeading, RevealText } from "@/components/site";
import { DIFFERENTIATORS } from "@/lib/site-data";

/* -------------------------------------------------------------------------- */
/*  CountUpNumber — animates from 00 → NN when in view, uses Anton font,      */
/*  outlined (WebkitTextStroke 1.5px yellow) default; fills solid on hover.   */
/* -------------------------------------------------------------------------- */

function CountUpNumber({ value }: { value: number }) {
  const ref = React.useRef<HTMLSpanElement | null>(null);
  const inView = useInView(ref, { once: true, margin: "-60px 0px -60px 0px" });
  const mv: MotionValue<number> = useMotionValue(0);
  const spring = useSpring(mv, { stiffness: 90, damping: 22, mass: 1.1 });

  React.useEffect(() => {
    if (inView) {
      const controls = animate(mv, value, {
        duration: 1.2,
        ease: [0.22, 1, 0.36, 1],
      });
      return controls.stop;
    }
  }, [inView, value, mv]);

  const [display, setDisplay] = React.useState("00");

  React.useEffect(() => {
    return spring.on("change", (v) => {
      const n = Math.round(v);
      setDisplay(String(n).padStart(2, "0"));
    });
  }, [spring]);

  return (
    <span
      ref={ref}
      className="font-poster text-5xl leading-none text-transparent transition-[color] duration-300 group-hover:text-brand-yellow sm:text-6xl md:text-7xl"
      style={{
        WebkitTextStroke: "1.5px var(--color-brand-yellow)",
      }}
      aria-label={String(value).padStart(2, "0")}
    >
      {display}
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/*  DifferentiatorCard                                                        */
/* -------------------------------------------------------------------------- */

function DifferentiatorCard({
  index,
  title,
  description,
}: {
  index: number;
  title: string;
  description: string;
}) {
  const value = index + 1;
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 24 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] },
        },
      }}
      whileHover={{ y: -4 }}
      className="group relative flex gap-5 overflow-hidden rounded-2xl border border-white/8 bg-brand-charcoal p-6 transition-colors duration-300 hover:border-brand-yellow/50 sm:gap-6 sm:p-7"
    >
      {/* yellow left accent bar — grows on hover */}
      <span
        aria-hidden="true"
        className="absolute left-0 top-0 h-full w-1 origin-top scale-y-0 bg-brand-yellow transition-transform duration-300 group-hover:scale-y-100"
      />

      {/* shine sweep gradient on hover */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-brand-yellow/10 to-transparent transition-transform duration-700 group-hover:translate-x-full"
      />

      {/* number column */}
      <div className="relative z-10 shrink-0">
        <CountUpNumber value={value} />
      </div>

      {/* text column */}
      <div className="relative z-10 flex flex-col gap-2">
        <h3 className="font-display text-lg font-bold leading-tight text-white transition-colors duration-300 group-hover:text-brand-yellow sm:text-xl">
          {title}
        </h3>
        <p className="text-sm leading-relaxed text-brand-gray sm:text-[15px]">
          {description}
        </p>
      </div>
    </motion.article>
  );
}

/* -------------------------------------------------------------------------- */
/*  WhyKyvroxa — premium differentiators section                               */
/* -------------------------------------------------------------------------- */

export function WhyKyvroxa() {
  const sectionRef = React.useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });
  const scaleY = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 26,
    mass: 0.4,
  });

  return (
    <section
      aria-labelledby="why-kyvroxa-title"
      ref={sectionRef}
      className="relative w-full overflow-hidden border-t border-white/5 bg-brand-black px-4 py-20 sm:py-24 md:py-28"
    >
      {/* left-edge vertical scroll progress line */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-0 top-0 hidden h-full w-px bg-white/5 md:block"
      >
        <motion.div
          style={{ scaleY, transformOrigin: "top" }}
          className="h-full w-full bg-gradient-to-b from-brand-yellow via-brand-yellow/60 to-transparent"
        />
      </div>

      <div className="mx-auto w-full max-w-7xl">
        <SectionHeading
          eyebrow="WHY KYVROXA"
          title={
            <RevealText text="CREATIVE THINKING WITH BUSINESS OUTCOMES." />
          }
          description="Six reasons brands choose to work with us — and stay with us."
          align="center"
        />

        <motion.div
          variants={{
            hidden: {},
            show: {
              transition: { staggerChildren: 0.12, delayChildren: 0.06 },
            },
          }}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px 0px -80px 0px" }}
          className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2 md:gap-6"
        >
          {DIFFERENTIATORS.map((d, i) => (
            <DifferentiatorCard
              key={d.title}
              index={i}
              title={d.title}
              description={d.description}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

export default WhyKyvroxa;
