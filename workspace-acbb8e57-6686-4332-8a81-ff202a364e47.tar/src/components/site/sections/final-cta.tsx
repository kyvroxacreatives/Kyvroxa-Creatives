"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  RevealText,
  Reveal,
  Button,
} from "@/components/site";
import { ArrowRight, Sparkles } from "lucide-react";

/**
 * FinalCta — premium box-type card on clean black background.
 *
 * Scene3D (animated circles) removed per request.
 * Content is wrapped in a rounded-3xl glassmorphism box with:
 *  - Yellow border + glow shadow
 *  - Top accent line (glass rim)
 *  - Corner brackets (L-shapes) at all 4 corners
 *  - Hover shine sweep
 *  - Subtle grid + spotlight backdrop (no animated circles)
 */
export function FinalCta() {
  return (
    <section
      aria-labelledby="final-cta-title"
      className="relative w-full overflow-hidden bg-brand-black px-4 py-20 sm:py-24 md:py-28"
    >
      {/* ---------- Clean backdrop (no animated circles) ---------- */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-grid opacity-[0.04]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-spotlight"
      />

      {/* ---------- Premium box card ---------- */}
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        viewport={{ once: true, margin: "-80px 0px -80px 0px" }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        whileHover={{ y: -4 }}
        className="relative z-10 mx-auto w-full max-w-4xl"
      >
        <div className="group relative overflow-hidden rounded-[28px] border border-brand-yellow/25 bg-gradient-to-b from-brand-charcoal to-[#0a0a0a] p-8 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.85),0_0_60px_-20px_rgba(255,213,0,0.25)] sm:rounded-[36px] sm:p-12 md:p-16">
          {/* Top accent line (glass rim) */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-r from-transparent via-brand-yellow/60 to-transparent sm:inset-x-12 md:inset-x-16"
          />
          {/* Inner top highlight */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/10"
          />

          {/* Corner brackets */}
          <CornerBracket position="top-left" />
          <CornerBracket position="top-right" />
          <CornerBracket position="bottom-left" />
          <CornerBracket position="bottom-right" />

          {/* Hover shine sweep */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-brand-yellow/[0.06] to-transparent transition-transform duration-[1200ms] ease-out group-hover:translate-x-full"
          />

          {/* ---------- Box content ---------- */}
          <div className="relative flex flex-col items-center text-center">
            {/* Eyebrow pill */}
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="inline-flex items-center gap-2 rounded-full border border-brand-yellow/40 bg-brand-yellow/10 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-yellow"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Let&rsquo;s build
            </motion.div>

            {/* Headline */}
            <h2
              id="final-cta-title"
              className="mt-6 font-poster text-3xl uppercase leading-[0.95] tracking-tight text-white sm:text-4xl md:text-5xl lg:text-6xl"
            >
              <RevealText
                text="YOUR NEXT BIG IDEA STARTS HERE."
                highlightWords={["HERE."]}
              />
            </h2>

            {/* Description */}
            <Reveal delay={0.15}>
              <p className="mx-auto mt-5 max-w-2xl text-sm leading-relaxed text-brand-gray sm:text-base md:text-lg">
                Have a project in mind? Let&rsquo;s turn your vision into
                something purposeful, memorable, and built for growth.
              </p>
            </Reveal>

            {/* CTAs */}
            <Reveal delay={0.2}>
              <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:gap-4">
                <Button href="/contact" variant="primary" size="lg" magnetic className="w-full sm:w-auto">
                  Start a Project
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button href="/pricing" variant="outline" size="lg" className="w-full sm:w-auto">
                  Explore Pricing
                </Button>
              </div>
            </Reveal>

            {/* Bottom micro-trust line */}
            <Reveal delay={0.25}>
              <div className="mt-8 inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-brand-gray/70">
                <Sparkles className="h-3 w-3 text-brand-yellow" />
                KYVROXA Creatives · Independent Studio
              </div>
            </Reveal>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

/* ---------- Corner bracket decoration ---------- */

function CornerBracket({
  position,
}: {
  position: "top-left" | "top-right" | "bottom-left" | "bottom-right";
}) {
  const positionClasses: Record<typeof position, string> = {
    "top-left": "left-3 top-3 border-l-2 border-t-2 sm:left-4 sm:top-4",
    "top-right": "right-3 top-3 border-r-2 border-t-2 sm:right-4 sm:top-4",
    "bottom-left":
      "bottom-3 left-3 border-b-2 border-l-2 sm:bottom-4 sm:left-4",
    "bottom-right":
      "bottom-3 right-3 border-b-2 border-r-2 sm:bottom-4 sm:right-4",
  };
  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none absolute h-5 w-5 border-brand-yellow/50 sm:h-7 sm:w-7 ${positionClasses[position]}`}
    />
  );
}

export default FinalCta;
