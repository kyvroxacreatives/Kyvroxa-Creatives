"use client";

import * as React from "react";
import {
  SectionHeading,
  RevealText,
  PortfolioCard,
  Reveal,
  Button,
} from "@/components/site";
import { PORTFOLIO_ITEMS } from "@/lib/site-data";
import { ArrowRight } from "lucide-react";

export function FeaturedPortfolio() {
  const featured = PORTFOLIO_ITEMS.slice(0, 3);

  return (
    <section
      aria-labelledby="featured-portfolio-title"
      className="relative w-full border-t border-white/5 bg-brand-charcoal px-4 py-20 sm:py-24 md:py-28"
    >
      <div className="mx-auto w-full max-w-7xl">
        <SectionHeading
          eyebrow="SELECTED WORK"
          title={
            <RevealText
              text="IDEAS BUILT TO STAND OUT."
              highlightWords={["STAND OUT."]}
            />
          }
          description="A look at recent concept projects that show how we approach brand, product, content, and campaign work. Each one starts from a business brief and ends with a system built to scale."
          align="center"
        />

        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((item, i) => (
            <Reveal key={item.slug} delay={i * 0.08}>
              <PortfolioCard item={item} />
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1} className="mt-10 flex justify-center sm:mt-12">
          <Button href="/portfolio" variant="outline" size="md">
            View All Projects
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

export default FeaturedPortfolio;
