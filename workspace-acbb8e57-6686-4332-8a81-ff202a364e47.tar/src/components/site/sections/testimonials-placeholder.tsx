"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SectionHeading } from "@/components/site";
import { Quote, Star, Trash2, ShieldAlert } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";

interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  rating: number;
  approved: boolean;
  createdAt: string;
}

interface TestimonialsResponse {
  testimonials: Testimonial[];
  isAdmin: boolean;
}

/**
 * Testimonials section — fetches from /api/testimonials and renders each
 * testimonial as a card. Negative feedbacks (rating 1–3) are flagged with a
 * red "Negative feedback" badge so the admin can spot them at a glance.
 *
 * The delete button only renders when `isAdmin === true` (server-confirmed
 * via httpOnly cookie). A hidden admin login lives at /admin — the button
 * shows a small lock icon to remind the admin it's restricted.
 */
export function TestimonialsPlaceholder() {
  const [data, setData] = React.useState<TestimonialsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  const fetchTestimonials = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/testimonials", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json: TestimonialsResponse = await res.json();
      setData(json);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load testimonials.");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchTestimonials();
  }, [fetchTestimonials]);

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      const res = await fetch(`/api/testimonials/${id}`, { method: "DELETE" });
      if (res.status === 401) {
        alert("Your admin session has expired. Please log in again at /admin.");
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      // Remove from local state
      setData((prev) =>
        prev
          ? { ...prev, testimonials: prev.testimonials.filter((t) => t.id !== id) }
          : prev,
      );
    } catch (e) {
      alert(e instanceof Error ? e.message : "Failed to delete testimonial.");
    } finally {
      setDeletingId(null);
    }
  }

  const testimonials = data?.testimonials ?? [];
  const isAdmin = data?.isAdmin ?? false;

  return (
    <section
      id="testimonials"
      aria-labelledby="testimonials-title"
      className="relative w-full border-t border-white/5 bg-brand-black px-4 py-20 sm:py-24 md:py-28"
    >
      {/* Decorative atmospheric layers */}
      <div
        className="pointer-events-none absolute inset-0 bg-grid opacity-[0.04]"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-0 bg-spotlight"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl">
        <SectionHeading
          eyebrow="CLIENT VOICES"
          title="TRUSTED BY BRANDS THAT TAKE CREATIVITY SERIOUSLY."
          align="center"
          description="Honest feedback from clients who've worked with the studio across brand, web, app, video, social, and digital marketing."
        />

        {/* Admin banner — only shows when logged in */}
        {isAdmin && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto mt-6 flex max-w-2xl items-center justify-center gap-2 rounded-full border border-brand-yellow/40 bg-brand-yellow/10 px-4 py-2 text-[10px] font-semibold uppercase tracking-widest text-brand-yellow"
          >
            <ShieldAlert className="h-3.5 w-3.5" />
            Admin mode — delete buttons are visible to you only
          </motion.div>
        )}

        {/* Loading state */}
        {loading && (
          <div className="mx-auto mt-12 grid max-w-7xl grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="h-56 animate-pulse rounded-2xl border border-white/10 bg-brand-charcoal/60"
              />
            ))}
          </div>
        )}

        {/* Error state */}
        {error && !loading && (
          <div className="mx-auto mt-12 max-w-md rounded-2xl border border-red-500/30 bg-red-500/10 p-6 text-center">
            <p className="text-sm text-red-200">{error}</p>
            <button
              onClick={fetchTestimonials}
              className="mt-3 text-xs font-bold uppercase tracking-wider text-brand-yellow"
            >
              Try again
            </button>
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && testimonials.length === 0 && (
          <div className="mx-auto mt-12 max-w-md rounded-2xl border border-white/10 bg-brand-charcoal p-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-brand-yellow/40 bg-brand-yellow/10 text-brand-yellow">
              <Quote className="h-6 w-6" />
            </div>
            <p className="mt-6 text-sm leading-relaxed text-brand-gray">
              Verified client testimonials will appear here. KYVROXA Creatives
              only publishes feedback from confirmed clients — contact us to
              share yours.
            </p>
          </div>
        )}

        {/* Testimonials grid */}
        {!loading && !error && testimonials.length > 0 && (
          <AnimatePresence mode="popLayout">
            <motion.div
              layout
              className="mx-auto mt-12 grid max-w-7xl grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
            >
              {testimonials.map((t, i) => {
                const isNegative = t.rating < 4;
                return (
                  <motion.article
                    key={t.id}
                    layout
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-40px 0px -40px 0px" }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{
                      duration: 0.5,
                      delay: i * 0.05,
                      ease: [0.22, 1, 0.36, 1],
                    }}
                    whileHover={{ y: -4 }}
                    className={cn(
                      "group relative flex flex-col overflow-hidden rounded-2xl border bg-brand-charcoal p-6 transition-colors duration-300",
                      isNegative
                        ? "border-red-500/30"
                        : "border-white/10 hover:border-brand-yellow/40",
                    )}
                  >
                    {/* Hover sweep */}
                    <div
                      className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-brand-yellow/[0.06] to-transparent transition-transform duration-1000 ease-out group-hover:translate-x-full"
                      aria-hidden="true"
                    />

                    {/* Top row: quote icon + stars */}
                    <div className="relative flex items-center justify-between">
                      <span
                        className={cn(
                          "flex h-10 w-10 items-center justify-center rounded-full border",
                          isNegative
                            ? "border-red-500/40 bg-red-500/10 text-red-300"
                            : "border-brand-yellow/40 bg-brand-yellow/10 text-brand-yellow",
                        )}
                      >
                        <Quote className="h-4 w-4" />
                      </span>

                      {/* Star rating */}
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, idx) => (
                          <Star
                            key={idx}
                            className={cn(
                              "h-3.5 w-3.5",
                              idx < t.rating
                                ? "fill-brand-yellow text-brand-yellow"
                                : "fill-white/10 text-white/10",
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Negative badge (only renders if admin OR always? — show always so visitors see honest feedback) */}
                    {isNegative && (
                      <div className="relative mt-3 inline-flex w-fit items-center gap-1.5 rounded-full border border-red-500/40 bg-red-500/10 px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-widest text-red-300">
                        <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-400" />
                        Negative feedback
                      </div>
                    )}

                    {/* Quote content */}
                    <blockquote className="relative mt-4 flex-1 text-sm leading-relaxed text-foreground/90">
                      &ldquo;{t.content}&rdquo;
                    </blockquote>

                    {/* Author */}
                    <footer className="relative mt-5 border-t border-white/5 pt-4">
                      <div className="font-display text-sm font-bold text-foreground">
                        {t.name}
                      </div>
                      <div className="mt-0.5 text-xs text-brand-gray">
                        {t.role} · {t.company}
                      </div>
                    </footer>

                    {/* Admin-only delete button — only renders if isAdmin is true */}
                    {isAdmin && (
                      <motion.button
                        type="button"
                        onClick={() => handleDelete(t.id)}
                        disabled={deletingId === t.id}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className={cn(
                          "absolute right-3 top-3 inline-flex h-9 w-9 items-center justify-center rounded-full border transition-colors",
                          isNegative
                            ? "border-red-500/50 bg-red-500/15 text-red-300 hover:bg-red-500 hover:text-white"
                            : "border-white/15 bg-brand-black/60 text-brand-gray hover:border-brand-yellow hover:text-brand-yellow",
                          deletingId === t.id && "opacity-50",
                        )}
                        title={
                          isNegative
                            ? "Remove this negative feedback (admin only)"
                            : "Remove this testimonial (admin only)"
                        }
                        aria-label="Remove testimonial"
                      >
                        {deletingId === t.id ? (
                          <motion.span
                            animate={{ rotate: 360 }}
                            transition={{
                              duration: 1,
                              repeat: Infinity,
                              ease: "linear",
                            }}
                            className="inline-block h-4 w-4 rounded-full border-2 border-current border-t-transparent"
                          />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                      </motion.button>
                    )}
                  </motion.article>
                );
              })}
            </motion.div>
          </AnimatePresence>
        )}

        {/* Admin login hint — only shows when NOT logged in, points to /admin */}
        {!loading && !error && !isAdmin && testimonials.length > 0 && (
          <div className="mt-8 text-center">
            <Link
              href="/admin"
              className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-widest text-brand-gray/50 transition-colors hover:text-brand-gray"
            >
              Studio login
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}

export default TestimonialsPlaceholder;
