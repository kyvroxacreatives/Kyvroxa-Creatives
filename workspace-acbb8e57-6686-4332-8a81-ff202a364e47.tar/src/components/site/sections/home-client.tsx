"use client";

import * as React from "react";
import { HomeHero } from "./home-hero";
import { ServicesOverview } from "./services-overview";
import { FeaturedPortfolio } from "./featured-portfolio";
import { WhyKyvroxa } from "./why-kyvroxa";
import { ProcessPreview } from "./process-preview";
import { TestimonialsPlaceholder } from "./testimonials-placeholder";
import { FinalCta } from "./final-cta";

/**
 * HomeClient — composes the homepage sections in order.
 * Kept as a client component so framer-motion hooks in child sections
 * stay client-side. Rendered inside <PageShell> by the server route.
 */
export function HomeClient() {
  return (
    <>
      <HomeHero />
      <ServicesOverview />
      <FeaturedPortfolio />
      <WhyKyvroxa />
      <ProcessPreview />
      <TestimonialsPlaceholder />
      <FinalCta />
    </>
  );
}

export default HomeClient;
