"use client";

import * as React from "react";
import {
  motion,
  useInView,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import {
  SectionHeading,
  RevealText,
  Button,
  Reveal,
} from "@/components/site";
import { ArrowRight } from "lucide-react";

/* Local 5-step preview — written inline, NOT from PROCESS_STEPS (which is 7) */
const PREVIEW_STEPS: { number: number; title: string; description: string }[] = [
  { number: 1, title: "Discover", description: "We learn your business, audience, and goals before any design begins." },
  { number: 2, title: "Strategize", description: "We translate the brief into a clear creative direction and plan." },
  { number: 3, title: "Create", description: "We design and produce the first concepts aligned to the strategy." },
  { number: 4, title: "Refine", description: "We iterate based on focused feedback within the agreed revision rounds." },
  { number: 5, title: "Deliver & Improve", description: "We hand off final files or launch — then review what to refine next." },
];

export function ProcessPreview() {
  // Section-level scroll progress drives the line-draw animation
  const sectionRef = React.useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start 80%", "end 60%"],
  });
  const lineScaleX = useSpring(scrollYProgress, {
    stiffness: 80,
    damping: 24,
    restDelta: 0.001,
  });

  return (
    <section
      ref={sectionRef}
      aria-labelledby="process-preview-title"
      className="relative w-full overflow-hidden border-t border-white/5 bg-brand-charcoal px-4 py-20 sm:py-24 md:py-28"
    >
      {/* Decorative atmospheric layers */}
      <div
        className="pointer-events-none absolute inset-0 bg-grid opacity-[0.04]"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-0 bg-spotlight"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl">
        <SectionHeading
          eyebrow="HOW WE WORK"
          title={<RevealText text="FROM IDEA TO IMPACT IN FIVE STEPS." />}
          description="A simplified look at how we move a project from the first conversation to measurable outcomes."
          align="center"
        />

        {/* ----------------- Desktop: animated horizontal timeline ----------------- */}
        <div className="relative mt-16 hidden md:block">
          {/* Background track (faint) */}
          <div
            aria-hidden="true"
            className="absolute left-0 right-0 top-[60px] h-[2px] w-full bg-white/5"
          />
          {/* Animated yellow progress line — draws from left to right as user scrolls */}
          <motion.div
            aria-hidden="true"
            style={{ scaleX: lineScaleX, transformOrigin: "left" }}
            className="absolute left-0 right-0 top-[60px] h-[2px] w-full bg-gradient-to-r from-brand-yellow via-brand-yellow to-brand-yellow/30"
          />
          {/* Pulsing dots on the line */}
          <div
            aria-hidden="true"
            className="absolute left-0 right-0 top-[60px] flex w-full justify-between px-[8px]"
          >
            {PREVIEW_STEPS.map((step, i) => (
              <PulsingDot key={step.number} index={i} scrollProgress={scrollYProgress} />
            ))}
          </div>

          {/* Step cards — staggered reveal + count-up numbers */}
          <motion.ol
            variants={{
              hidden: {},
              show: { transition: { staggerChildren: 0.15, delayChildren: 0.05 } },
            }}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px 0px -80px 0px" }}
            className="grid grid-cols-5 gap-4 pt-20"
          >
            {PREVIEW_STEPS.map((step) => (
              <StepCard key={step.number} step={step} />
            ))}
          </motion.ol>
        </div>

        {/* ----------------- Mobile: animated vertical timeline ----------------- */}
        <ol className="relative mt-12 flex flex-col gap-8 md:hidden">
          {/* Vertical animated line */}
          <motion.div
            aria-hidden="true"
            style={{ scaleY: lineScaleX, transformOrigin: "top" }}
            className="absolute left-[15px] top-2 bottom-2 w-[2px] bg-gradient-to-b from-brand-yellow via-brand-yellow/70 to-brand-yellow/30"
          />
          {/* Background track */}
          <div
            aria-hidden="true"
            className="absolute left-[15px] top-2 bottom-2 w-[2px] bg-white/5"
          />
          {PREVIEW_STEPS.map((step, i) => (
            <MobileStep key={step.number} step={step} index={i} />
          ))}
        </ol>

        <Reveal delay={0.1} className="mt-12 flex justify-center sm:mt-14">
          <Button href="/process" variant="ghost" size="md">
            View Full Process
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

/* ----------------- Pulsing dot on the timeline ----------------- */

function PulsingDot({
  index,
  scrollProgress,
}: {
  index: number;
  scrollProgress: { get: () => number; on: (e: string, cb: (v: number) => void) => () => void };
}) {
  // Each dot activates at a different scroll threshold (0.1, 0.3, 0.5, 0.7, 0.9)
  const threshold = 0.1 + (index / (PREVIEW_STEPS.length - 1)) * 0.8;
  const [active, setActive] = React.useState(false);

  React.useEffect(() => {
    const unsub = scrollProgress.on("change", (v) => {
      setActive(v >= threshold);
    });
    return () => unsub();
  }, [scrollProgress, threshold]);

  return (
    <div className="relative -translate-y-1/2">
      {/* Expanding pulse ring (when active) */}
      <motion.span
        className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-yellow"
        animate={active ? { scale: [1, 2.5, 1], opacity: [0.7, 0, 0.7] } : { scale: 1, opacity: 0 }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* Solid dot */}
      <motion.span
        className="relative block h-2.5 w-2.5 rounded-full bg-brand-yellow transition-all duration-300"
        animate={{
          boxShadow: active
            ? "0 0 14px rgba(255,213,0,0.9), 0 0 28px rgba(255,213,0,0.5)"
            : "0 0 6px rgba(255,213,0,0.3)",
          scale: active ? 1.3 : 1,
        }}
      />
    </div>
  );
}

/* ----------------- Desktop step card with count-up + hover ----------------- */

function StepCard({
  step,
}: {
  step: { number: number; title: string; description: string };
}) {
  const cardRef = React.useRef<HTMLLIElement>(null);
  const inView = useInView(cardRef, { once: true, margin: "-40px 0px -40px 0px" });

  return (
    <motion.li
      ref={cardRef}
      variants={{
        hidden: { opacity: 0, y: 30 },
        show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
      }}
      whileHover={{ y: -6 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className="group relative flex flex-col items-start gap-2 rounded-xl border border-transparent p-3 transition-colors duration-300 hover:border-brand-yellow/30 hover:bg-brand-black/30"
    >
      {/* Hover yellow accent bar */}
      <motion.div
        className="absolute left-0 top-3 h-6 w-[3px] origin-top rounded-full bg-brand-yellow"
        initial={{ scaleY: 0 }}
        whileHover={{ scaleY: 1 }}
        transition={{ duration: 0.3 }}
        style={{ transformOrigin: "top" }}
        aria-hidden="true"
      />

      {/* Count-up outlined Anton number — fills solid on hover */}
      <CountUpNumber target={step.number} inView={inView} />

      <h3 className="font-display text-base font-bold uppercase tracking-wide text-white transition-colors group-hover:text-brand-yellow">
        {step.title}
      </h3>
      <p className="text-sm leading-relaxed text-brand-gray">
        {step.description}
      </p>
    </motion.li>
  );
}

/* ----------------- Mobile step with count-up ----------------- */

function MobileStep({
  step,
  index,
}: {
  step: { number: number; title: string; description: string };
  index: number;
}) {
  const ref = React.useRef<HTMLLIElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px 0px -40px 0px" });

  return (
    <motion.li
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.6, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="relative pl-12"
    >
      {/* Dot */}
      <motion.span
        className="absolute left-[10px] top-3 h-2.5 w-2.5 rounded-full bg-brand-yellow"
        animate={{
          boxShadow: [
            "0 0 6px rgba(255,213,0,0.4)",
            "0 0 14px rgba(255,213,0,0.9), 0 0 24px rgba(255,213,0,0.5)",
            "0 0 6px rgba(255,213,0,0.4)",
          ],
        }}
        transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: index * 0.3 }}
      />
      <CountUpNumber target={step.number} inView={inView} small />
      <h3 className="mt-1 font-display text-base font-bold uppercase tracking-wide text-white">
        {step.title}
      </h3>
      <p className="mt-1 text-sm leading-relaxed text-brand-gray">
        {step.description}
      </p>
    </motion.li>
  );
}

/* ----------------- Count-up Anton number with hover fill ----------------- */

function CountUpNumber({
  target,
  inView,
  small = false,
}: {
  target: number;
  inView: boolean;
  small?: boolean;
}) {
  const spring = useSpring(0, { stiffness: 60, damping: 18 });
  const display = useTransform(spring, (v) => Math.round(v).toString().padStart(2, "0"));
  const [text, setText] = React.useState("00");

  React.useEffect(() => {
    const unsub = display.on("change", (v) => setText(v));
    return () => unsub();
  }, [display]);

  React.useEffect(() => {
    if (inView) spring.set(target);
    else spring.set(0);
  }, [inView, target, spring]);

  const sizeClass = small
    ? "text-3xl"
    : "text-3xl md:text-4xl";
  const sizePx = small ? 30 : 36;

  return (
    <div className="relative inline-block" style={{ height: sizePx + 6, width: sizePx * 1.4 }}>
      {/* Outline (default) */}
      <motion.span
        className={`font-poster absolute inset-0 flex items-center ${sizeClass} text-transparent transition-opacity duration-300 group-hover:opacity-0`}
        style={{ WebkitTextStroke: "1.5px rgba(255, 213, 0, 0.6)" }}
      >
        {text}
      </motion.span>
      {/* Solid yellow (hover) */}
      <motion.span
        className={`font-poster absolute inset-0 flex items-center ${sizeClass} text-brand-yellow opacity-0 transition-opacity duration-300 group-hover:opacity-100`}
      >
        {text}
      </motion.span>
    </div>
  );
}

export default ProcessPreview;
