"use client";

import * as React from "react";
import { motion } from "framer-motion";
import Image from "next/image";

/**
 * FounderPortraitBox — white-background card containing the 3D young male
 * portrait, with a gentle floating animation.
 *
 * Used in the About Us hero (right column) replacing the 3D KC monogram.
 * The white card creates a clean contrast against the dark site background
 * and gives the founder portrait a premium polaroid-like frame.
 */
export function FounderPortraitBox() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
      className="relative mx-auto w-full max-w-[420px]"
    >
      {/* Floating wrapper — gentle up/down + slight rotate */}
      <motion.div
        animate={{
          y: [0, -14, 0],
          rotate: [0, 1.2, 0],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="relative"
      >
        {/* Yellow glow behind card */}
        <div
          aria-hidden="true"
          className="absolute -inset-4 rounded-[2rem] bg-brand-yellow/20 blur-3xl"
        />

        {/* White card */}
        <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] border border-brand-yellow/30 bg-white shadow-[0_30px_80px_-15px_rgba(0,0,0,0.6),0_0_60px_-20px_rgba(255,213,0,0.35)]">
          {/* Top inner highlight (glass rim) */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white to-transparent"
          />

          {/* The 3D portrait — pure white bg blends seamlessly with the card */}
          <Image
            src="/about-founder.png"
            alt="KYVROXA Creatives founder portrait"
            fill
            priority
            sizes="(max-width: 768px) 80vw, 420px"
            className="object-cover object-center"
          />

          {/* Soft gradient at top for the badge legibility */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-white/60 to-transparent"
          />
          {/* Soft gradient at bottom for the caption legibility */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-white/85 via-white/40 to-transparent"
          />

          {/* Top badge — "FOUNDER" */}
          <div className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-brand-black/15 bg-white/80 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.22em] text-brand-black backdrop-blur-sm">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-brand-yellow" />
            Founder
          </div>

          {/* Bottom caption */}
          <div className="absolute inset-x-0 bottom-0 px-5 pb-5 text-center">
            <div className="font-display text-base font-bold uppercase tracking-tight text-brand-black sm:text-lg">
              KYVROXA Creatives
            </div>
            <div className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.25em] text-brand-black/60">
              Creative &amp; Digital Studio
            </div>
          </div>
        </div>

        {/* Decorative yellow sparkles around the card */}
        <motion.svg
          viewBox="0 0 24 24"
          fill="currentColor"
          aria-hidden="true"
          className="absolute -right-3 top-10 h-6 w-6 text-brand-yellow drop-shadow-[0_0_8px_rgba(255,213,0,0.6)]"
          animate={{ scale: [1, 1.25, 1], opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        >
          <path d="M12 0 C13 7 17 11 24 12 C17 13 13 17 12 24 C11 17 7 13 0 12 C7 11 11 7 12 0 Z" />
        </motion.svg>
        <motion.svg
          viewBox="0 0 24 24"
          fill="currentColor"
          aria-hidden="true"
          className="absolute -left-3 top-1/2 h-4 w-4 text-brand-yellow drop-shadow-[0_0_6px_rgba(255,213,0,0.5)]"
          animate={{ scale: [1, 1.25, 1], opacity: [0.6, 1, 0.6] }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
        >
          <path d="M12 0 C13 7 17 11 24 12 C17 13 13 17 12 24 C11 17 7 13 0 12 C7 11 11 7 12 0 Z" />
        </motion.svg>
        <motion.svg
          viewBox="0 0 24 24"
          fill="currentColor"
          aria-hidden="true"
          className="absolute -right-2 bottom-16 h-3 w-3 text-brand-yellow/80 drop-shadow-[0_0_5px_rgba(255,213,0,0.4)]"
          animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.9, 0.5] }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5,
          }}
        >
          <path d="M12 0 C13 7 17 11 24 12 C17 13 13 17 12 24 C11 17 7 13 0 12 C7 11 11 7 12 0 Z" />
        </motion.svg>
      </motion.div>

      {/* Subtle ground shadow under the floating card */}
      <motion.div
        aria-hidden="true"
        className="mx-auto mt-4 h-3 w-3/4 rounded-full bg-black/40 blur-xl"
        animate={{
          scaleX: [1, 0.92, 1],
          opacity: [0.4, 0.3, 0.4],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </motion.div>
  );
}

export default FounderPortraitBox;
