import Link from "next/link";
import { Check, Sparkles } from "lucide-react";
import type { PricingPackage } from "@/lib/site-data";
import { cn } from "@/lib/utils";

/**
 * PricingCard — package card with popular highlight (yellow border + glow + badge).
 * name, price (+ optional cadence), description, feature list, CTA button.
 * Server component (no interactivity needed).
 */
export function PricingCard({
  pkg,
  className,
  ctaHref = "/contact",
  ctaLabel = "Start with this plan",
}: {
  pkg: PricingPackage;
  className?: string;
  ctaHref?: string;
  ctaLabel?: string;
}) {
  const popular = pkg.popular === true;

  return (
    <article
      className={cn(
        "relative flex h-full flex-col rounded-2xl border bg-brand-charcoal p-6 transition-all duration-300",
        popular
          ? "border-brand-yellow shadow-[0_0_40px_-5px_rgba(255,213,0,0.35)]"
          : "border-white/8 hover:border-white/15",
        className,
      )}
    >
      {popular ? (
        <span className="absolute -top-3 left-6 inline-flex items-center gap-1.5 rounded-full border border-brand-yellow bg-brand-black px-3 py-1 font-mono text-[10px] uppercase tracking-[0.25em] text-brand-yellow">
          <Sparkles className="h-3 w-3" />
          Popular
        </span>
      ) : null}

      <div className="flex flex-col gap-2">
        <h3 className="font-display text-xl font-bold text-white">
          {pkg.name}
        </h3>
        <p className="text-sm leading-relaxed text-brand-gray">
          {pkg.description}
        </p>
      </div>

      <div className="mt-5 flex items-end gap-1.5">
        <span
          className={cn(
            "font-poster text-4xl leading-none",
            popular ? "text-brand-yellow" : "text-white",
          )}
        >
          {pkg.price}
        </span>
        {pkg.cadence ? (
          <span className="pb-1 font-mono text-xs text-brand-gray">
            {pkg.cadence}
          </span>
        ) : null}
      </div>

      <ul className="mt-6 flex flex-1 flex-col gap-3">
        {pkg.features.map((f) => (
          <li key={f} className="flex items-start gap-2.5 text-sm text-white/85">
            <span
              className={cn(
                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full",
                popular
                  ? "bg-brand-yellow text-brand-black"
                  : "bg-white/10 text-brand-yellow",
              )}
            >
              <Check className="h-3 w-3" />
            </span>
            <span className="leading-snug">{f}</span>
          </li>
        ))}
      </ul>

      <Link
        href={ctaHref}
        className={cn(
          "mt-6 inline-flex h-11 items-center justify-center rounded-md px-5 text-xs font-medium uppercase tracking-wider transition-colors",
          popular
            ? "border border-brand-yellow bg-brand-yellow text-brand-black hover:bg-white"
            : "border border-white/15 bg-transparent text-white hover:border-brand-yellow hover:text-brand-yellow",
        )}
      >
        {ctaLabel}
      </Link>
    </article>
  );
}

export default PricingCard;
