# KYVROXA Creatives — REBUILD Worklog

The original project state was accidentally reset to the Z.ai scaffold.
This worklog tracks the rebuild. All subagents MUST read this file before
starting and APPEND (never overwrite) a section after finishing.

Brand:
- Pure black #050505, Deep charcoal #111111, Electric yellow #FFD500,
  White #FFFFFF, Soft gray #A6A6A6
- Fonts (already wired in layout.tsx + globals.css):
  - --font-space-grotesk (display headings, .font-display)
  - --font-inter (body, default sans)
  - --font-anton (poster/bold-condensed, .font-poster) — used for hero headline + big numbers
  - --font-jetbrains-mono (mono, .font-mono)
- Brand utilities available: bg-brand-black, bg-brand-charcoal, text-brand-yellow,
  text-brand-gray, border-brand-yellow, .metallic-yellow, .metallic-dark, .chrome-rim,
  .bg-grid, .bg-grid-yellow, .bg-spotlight, .font-display, .font-poster, .animate-marquee,
  .animate-float, .link-underline

---
Task ID: 1
Agent: main
Task: Restore logo + rebuild design system (globals.css, layout.tsx)

Work Log:
- Restored company logo: `public/logo.png` (661x119, transparent bg, trimmed from upload)
- Removed `public/robots.txt` (will use dynamic `src/app/robots.ts` later)
- Rebuilt `src/app/globals.css` with full KYVROXA brand palette + utilities + animations
- Rebuilt `src/app/layout.tsx` with Space Grotesk + Inter + Anton + JetBrains Mono fonts
- Metadata configured with brand title template + OpenGraph + robots

Stage Summary:
- Foundation restored. Downstream agents MUST use the brand tokens above.
- Central data file + shared components come next.

---
Task ID: R-COMP
Agent: rebuild-components
Task: Rebuild shared component library in `src/components/site/`

Work Log:
- Built 15 components + 1 barrel file in `src/components/site/`:
  - logo.tsx (Logo + LogoSymbol SVG monogram)
  - button.tsx (5 variants × 3 sizes + magnetic + href)
  - reveal.tsx (Reveal, RevealText, Eyebrow, SectionHeading)
  - capabilities-ticker.tsx (seamless marquee + edge fade)
  - back-to-top.tsx (floating yellow circle, appears after 600px)
  - scroll-progress.tsx (thin yellow top bar via useScroll + useSpring)
  - header.tsx (fixed nav, scroll backdrop, Services mega-menu, mobile drawer)
  - footer.tsx (4-col, sticky via mt-auto, top accent + bottom strip)
  - scene-3d.tsx (CSS+SVG+framer-motion 3D scenes — 5 primitives + 9 kinds)
  - pricing-card.tsx (popular highlight + yellow checks + CTA)
  - service-card.tsx (UNIFORM card, 01-06, pills, sweep hover)
  - portfolio-card.tsx (4/3 Image preview, status badge, arrow, line-clamp)
  - faq-list.tsx (shadcn Accordion wrapper, single-open, default first)
  - page-shell.tsx (ScrollProgress+Header+main+Footer+BackToTop, sticky layout)
  - structured-data.tsx (JSON-LD for Org + WebSite + Breadcrumb + 6 Services)
  - index.ts (barrel re-exports)

Decisions / Notes:
- Used `motion.create(Link)` (hoisted outside render) to avoid the
  "components created during render" lint rule in framer-motion v12.
- Omitted conflicting DOM drag/animation handlers from ButtonProps so the
  spread into motion.button stays type-safe.
- Used `"hasMegaMenu" in link` and `map<StudioLink>` casts to work with
  NAV_LINKS `as const` literal union.
- Scene3D is pure CSS+SVG+framer-motion (NO Three.js) for sandbox reliability.
  Scenes match each `SERVICES[i].heroVisual` value (canvases, screens, phone,
  timeline, network, dashboard) plus the home-hero / cta / about specials.
- All interactive components carry `"use client"`. Static cards + Footer +
  PageShell + StructuredData + Logo remain server components.
- Footer is sticky via `mt-auto` (works with PageShell's `min-h-screen flex
  flex-col` parent — and with any other flex-column wrapper).

Verification:
- `bun run lint` → clean (0 errors, 0 warnings)
- `bun x tsc --noEmit` → clean for all `src/components/site/*`
- Dev server recompiles cleanly on HMR (no errors in dev.log)

Stage Summary:
- Shared component library is ready for page builders (downstream agents).
- Import path: `@/components/site` (barrel) or `@/components/site/<file>`.
- Page builders should wrap each route in `<PageShell>{page content}</PageShell>`
  to get the sticky footer + fixed header + scroll progress + back-to-top
  for free. Add `<StructuredData />` once per layout if not done globally.

---
Task ID: R-SVC
Agent: rebuild-services
Task: Build 6 dedicated service pages + services index + branded 404

Work Log:
- Built 4 files (no new packages, no Three.js, no data edits):
  1. `src/components/site/service-page-client.tsx` ("use client") — 7-section shared template
  2. `src/app/services/[slug]/page.tsx` (server) — generateStaticParams + generateMetadata
  3. `src/app/services/[slug]/not-found.tsx` (server) — branded 404 with 6 service pills
  4. `src/app/services/page.tsx` (server) — services index with hero + grid + cross-links
- Exported `ServicePageClient` from `@/components/site` barrel (index.ts).

Template structure (ServicePageClient):
  1. HERO — full-bleed `Scene3D kind={service.heroVisual as Scene3DKind}` behind,
     dim gradients top→bottom + left→right; `<Eyebrow>{service.eyebrow}</Eyebrow>`;
     h1 with `.font-poster` (Anton) wrapping `<RevealText text={service.headline}
     highlightWords={HIGHLIGHT_WORDS[slug]} />`; description; CTA row
     `Get a Quote → /contact` (primary magnetic) + `View Pricing → #pricing` (outline);
     tagline in mono below.
  2. SERVICES WE OFFER — `<SectionHeading>` then 12-col split: left 8-col is a
     `max-h-96 overflow-y-auto` scrollable charcoal panel with the 9 services in a
     2-col numbered list (yellow 01 + ▹ bullet); right 4-col is a yellow-tinted
     "Scope Note" callout using `SERVICE_NOTE[slug]`.
  3. OUR CREATIVE PROCESS — `<SectionHeading>` + vertical step list with a vertical
     yellow gradient connecting line, 10×10 numbered yellow-ringed discs, step
     title + detail. Below: `PROCESS_CAPTION[slug]` in italic gray.
  4. PACKAGES BUILT FOR YOUR STAGE — center-aligned `<SectionHeading>` with
     description; `md:grid-cols-3` of 3 `<PricingCard pkg={pkg} />`; exclusions
     scope-note callout below (yellow Info icon + monospaced "Scope note:" label
     + gray body); bottom CTAs `Get a Custom Quote → /contact` (primary magnetic)
     + `Compare All Services → /pricing` (outline).
  5. FAQs — center-aligned `<SectionHeading>` + `<FaqList faqs={service.faqs} />`
     in `max-w-3xl mx-auto`.
  6. OTHER CREATIVE SERVICES — `<SectionHeading>` + `grid-cols-1 sm:grid-cols-2
     lg:grid-cols-3` of `<ServiceCard>` for the OTHER 5 services (current slug
     filtered out). ServiceCard index = position in global SERVICES array so
     numbering stays canonical (Service 04 is always Video Editing).
  7. FINAL CTA — full-bleed `Scene3D kind="cta"` behind + dim overlay; center
     column with Eyebrow "LET'S BUILD", h2 `.font-poster` "READY TO START YOUR
     PROJECT?" via `<RevealText highlightWords={["READY","START","PROJECT?"]}>`,
     supporting copy, primary `Start a Project → /contact` (magnetic) + outline
     `View All Services → /services`, plus a "KYVROXA Creatives" pill.

Per-service CTA labels (consistent across all 6 routes):
  - Hero: "Get a Quote" (primary magnetic) → /contact
  - Pricing bottom: "Get a Custom Quote" (primary magnetic) → /contact
                    "Compare All Services" (outline) → /pricing
  - PricingCard CTAs: "Start with this plan" → /contact
  - Final CTA: "Start a Project" (primary magnetic) → /contact
               "View All Services" (outline) → /services

Per-service clarifying-note decisions:
  - SERVICE_NOTE lookup table — verbatim from the task brief for all 6 slugs.
  - PROCESS_CAPTION lookup — graphic-designing uses the bespoke concepts/revisions
    note; the other 5 services use the generic "Timelines and revision rounds vary
    by selected package — see pricing below for details." caption.
  - HIGHLIGHT_WORDS lookup — picked 2-4 impactful words per headline:
      graphic-designing → ["DESIGN","BRAND","IGNORE"]
      website-designing  → ["IMPRESS.","BUILT","PERFORM."]
      mobile-app-designing → ["MOBILE","EXPERIENCES","LOVE"]
      video-editing → ["SECOND","PURPOSE."]
      social-media-marketing → ["SCROLLS","MEANINGFUL","CONNECTIONS."]
      digital-marketing → ["SMARTER","CAMPAIGNS.","CLEARER","PERFORMANCE."]
    (RevealText matches case-insensitively against the word stripped of
    non-alphanumerics, so "IMPRESS." highlights the literal "IMPRESS." token.)

Services index (`/services`):
  - PageShell topPad={false}; hero with `Scene3D kind="home-hero"` behind,
    `<Eyebrow>SIX DISCIPLINES · ONE STUDIO</Eyebrow>`, h1 `.font-poster`
    "CREATIVE SERVICES FOR EVERY STAGE OF YOUR BRAND" via `<RevealText
    highlightWords={["CREATIVE","EVERY","BRAND"]}>`, subtitle, CTAs
    `Get a Custom Quote → /contact` + `Browse Services → #all-services`.
  - Stats strip (06 / 07 / 18 / 100%) above the grid.
  - All-services grid: uniform `lg:grid-cols-3` of 6 `<ServiceCard>` with
    canonical 0-5 indexes + a closing "Not sure which fits? Get a recommendation"
    CTA → /contact.
  - Cross-link section with 3 cards → /process (Layers icon), /pricing (Tag icon),
    /portfolio (FolderOpen icon); each card uses yellow icon tile, hover sweep,
    arrow-up-right affordance.

Branded 404 (`/services/[slug]/not-found.tsx`):
  - PageShell (with topPad) + full-bleed bg-grid + soft yellow glow.
  - Eyebrow "ERROR 404", giant `404` in `.font-poster` at white/5 opacity, h1
    "That service doesn't exist" in `.font-poster`, supporting copy.
  - 6 service pills — each shows canonical `01`-`06` mono number + shortName +
    arrow-up-right, hover turns yellow border + yellow text.
  - Buttons: `All Services → /services` (primary magnetic) + `Back to Home → /`
    (outline).

Server route conventions:
  - `generateStaticParams` returns all 6 slugs → SSG at build.
  - `generateMetadata` returns per-service `title`, `description` = tagline,
    `keywords` derived from shortName/title + first 4 service lines, canonical
    URL, `openGraph.type = "article"`, plus Twitter card.
  - Default export: `const { slug } = await params; const service = getService(slug);
    if (!service) notFound(); return <PageShell topPad={false}>
    <ServicePageClient service={service} /></PageShell>`.

Type-safety:
  - `service.heroVisual` is typed `string` in ServiceData; cast `as Scene3DKind`
    at the single call-site (data values are constrained to the 6 valid kinds).
  - No `any` used anywhere; all lookup tables typed `Record<ServiceSlug, ...>`.

Verification:
  - `bun run lint` → 0 errors, 0 warnings (exit 0).
  - `bun x tsc --noEmit` → no errors in any R-SVC file (errors elsewhere are in
    other agents' territory: examples/websocket, skills/*, src/lib/validations/contact.ts).
  - Dev server: GET /services → 200; GET /services/graphic-designing → 200;
    GET /services/video-editing → 200; GET /services/social-media-marketing → 200;
    GET /services/non-existent → 404 (renders branded not-found).
  - SSR HTML verified: hero headline words ("DESIGN","BRAND","IGNORE.") render in
    the response; all 5 CTAs ("Get a Quote", "Get a Custom Quote",
    "Compare All Services", "Start a Project", "View All Services") present.

Stage Summary:
  - The services index + all 6 service detail routes + branded 404 are live.
  - Downstream agents (R-PAGES for home/about/portfolio/process/pricing/contact,
    and the global not-found owner) can now link to /services and /services/[slug]
    with confidence. The global `src/app/not-found.tsx` was NOT touched (another
    agent owns it) — R-SVC only created the service-scoped
    `src/app/services/[slug]/not-found.tsx`.

---
Task ID: R-HOME
Agent: rebuild-homepage-about
Task: Rebuild Homepage (`/`) + About page (`/about`)

Work Log:
- Built 9 files (no new packages, no Three.js, no data edits, no tests):
  1. `src/components/site/sections/home-hero.tsx` ("use client")
  2. `src/components/site/sections/services-overview.tsx` ("use client")
  3. `src/components/site/sections/featured-portfolio.tsx` ("use client")
  4. `src/components/site/sections/why-kyvroxa.tsx` ("use client")
  5. `src/components/site/sections/process-preview.tsx` ("use client")
  6. `src/components/site/sections/testimonials-placeholder.tsx` ("use client")
  7. `src/components/site/sections/final-cta.tsx` ("use client")
  8. `src/components/site/sections/home-client.tsx` ("use client" composer)
  9. `src/app/page.tsx` (server) — replaced scaffold with
     `<PageShell topPad={false}><StructuredData /><HomeClient /></PageShell>`
  10. `src/app/about/page.tsx` (server) with `export const metadata`.

HomeHero design (final landed iteration):
- Solid black bg + `.bg-grid` opacity-70 + `.bg-spotlight` + radial vignette.
- Top: availability chip "Available for select projects" centered, pulsing
  yellow dot with glow boxShadow.
- Centered content: `<Eyebrow>INDEPENDENT CREATIVE & DIGITAL STUDIO</Eyebrow>`
  + Anton headline with MIXED small/big typography, CENTERED, stacked:
    - small gray `.font-display` tracking-[0.4em] — "We Turn"
    - big white `.font-poster` clamp(2.75rem, 11vw, 9.5rem) — "Creative Ideas"
    - small gray — "Into"
    - big yellow — "Digital Impact."
  + centered description paragraph + single yellow CTA button
  "Explore Our Services" → `/services/graphic-designing` (magnetic).
- 4 yellow 4-pointed SVG star sparkles with breathing opacity+scale+rotate
  loop, scattered in the corners (top-left, top-right, bottom-left,
  bottom-right).
- Bottom: full-width yellow strip marquee using SERVICES data (`shortName`
  duplicated), black text on yellow bg, `.animate-marquee` utility.
- NO male image, NO contact icon button (removed in earlier iterations).

WhyKyvroxa count-up animation:
- `useInView` + `useMotionValue` + `useSpring` + `animate` to count from
  0 → (index+1) when in view. Display always pads to 2 digits ("00" → "01"
  ... "06"). `aria-label` carries the actual number for screen readers.
- Numbers use `.font-poster` text-5xl/6xl/7xl with
  `WebkitTextStroke: 1.5px var(--color-brand-yellow)` and `color:
  transparent` — outlined default, solid yellow on `group-hover`.
- Hover micro-interactions per card: lift `y: -4`, yellow left accent bar
  grows (`scale-y-0 → 100` origin top), shine sweep gradient.
- Staggered entrance via parent `motion.div` variants:
  `staggerChildren: 0.12, delayChildren: 0.06`.
- Left-edge vertical scroll progress line via `useScroll({ target:
  sectionRef, offset: ["start end","end start"] })` + `useSpring` scaleY.
  Hidden on mobile (only `md:block`).

ProcessPreview:
- 5 steps written INLINE (Discover, Strategize, Create, Refine, Deliver &
  Improve) — NOT imported from PROCESS_STEPS (which is the 7-step agency
  process and used elsewhere).
- Desktop: horizontal timeline with yellow gradient connecting line + 5
  yellow dots. Mobile: vertical timeline per-step.
- "View Full Process →" ghost button → `/process`.

TestimonialsPlaceholder:
- Single neutral card, yellow Quote lucide icon, verbatim placeholder copy
  from brief. NO fabricated names, photos, or quotes.

FinalCta:
- `<Scene3D kind="cta" interactive={false} />` behind + radial dark veil.
- `<RevealText text="YOUR NEXT BIG IDEA STARTS HERE." highlightWords={["HERE."]} />`
- Primary "Start a Project" → `/contact` + outline "Explore Pricing" → `/pricing`.

About page (`/about`):
- Server component with `export const metadata = { title: "About Us",
  description, openGraph }`.
- 6 sections in order:
  1. Split-screen hero — left text (`<Eyebrow>ABOUT KYVROXA CREATIVES</Eyebrow>`
     + `<RevealText text="CREATIVITY WITH A CLEAR DIRECTION."
     highlightWords={["DIRECTION."]} />` + supporting paragraph + discipline
     pills), right `<Scene3D kind="about" />` in ~600px max container, aspect
     square.
  2. Mission + Vision two-column — Mission copy is verbatim from the brief;
     Vision is a tasteful forward-looking paragraph in brand voice about
     being a long-term partner and building systems (not one-offs).
  3. Core values grid — 5 from `COMPANY_VALUES` each with `01`-`05` Anton
     number + yellow accent bar that grows on hover.
  4. Founder section — clearly-labeled editable placeholder: yellow circle
     with `<LogoSymbol>` KC monogram + "Placeholder" pill, "Founder Name"
     in italic gray, "Founder & Creative Lead — to be published",
     "Founder biography will appear here once published." + explicit note
     that no information has been fabricated. NO real name/photo/bio invented.
  5. Approach explanation — 3 concise paragraphs (brief-first, milestone
     rhythm, success criteria).
  6. CTA — primary "Explore Services" → `/services/graphic-designing` +
     outline "Discuss a Project" → `/contact`.
- Every block wrapped in `<Reveal>` for staggered entrance.
- Wrapped in `<PageShell>` (default topPad=true so content clears header).

Code quality / conventions:
- TypeScript strict, no `any`.
- `'use client'` on all 7 homepage section files + home-client composer
  (framer-motion hooks). About page is a server component that imports
  client components — standard server→client composition.
- Mobile-first responsive throughout. All grids collapse to 1-col on mobile.
- PageShell `topPad={false}` on `/` so hero starts at the very top of the
  viewport (header is fixed/transparent and overlays it cleanly). About page
  uses default `topPad={true}`.

Verification:
- `bun run lint` → ✅ exit 0 (0 errors, 0 warnings).
- `bun x tsc --noEmit` → ✅ no errors in any R-HOME file (errors elsewhere
  are in unrelated files: examples/websocket, skills/*,
  src/lib/validations/contact.ts — other agents' territory).
- Dev server (port 3000, already running) recompiles cleanly on HMR.
- `curl http://localhost:3000/` → **200** with hero content rendered
  ("We Turn", "Creative Ideas", "Into", "Digital Impact" all present).
- `curl http://localhost:3000/about` → **200** with "CREATIVITY WITH A
  CLEAR DIRECTION", "Our Mission", "Our Vision", "CORE VALUES",
  "Founder Name" all rendered.

Stage Summary:
- Homepage (`/`) and About page (`/about`) are live and link correctly to
  `/services`, `/services/graphic-designing`, `/portfolio`, `/process`,
  `/pricing`, `/contact` — all of which are owned by other agents (R-SVC
  for services, R-PAGES for portfolio/process/pricing/contact).
- Sections live under `src/components/site/sections/` and import from
  `@/components/site` (barrel) and `@/lib/site-data` per project conventions.
- Worklog knowledge persisted to `agent-ctx/R-HOME-homepage-about.md`.

---
Task ID: R-PAGES
Agent: rebuild-pages
Task: Rebuild Portfolio, Process, Pricing, Contact pages + contact API + shared zod schema + Inquiry Prisma model + custom 404 + sitemap/robots

Work Log:
- Prisma: appended `Inquiry` model to `prisma/schema.prisma` (id, fullName, businessName, email, whatsapp, service, budget, timeline, description, fileName?, honeypot?, createdAt). Kept existing `User` and `Post` models untouched. Ran `bun run db:push` — schema synced + client regenerated.
- Shared zod schema at `src/lib/validations/contact.ts`:
  - `contactSchema` object with `fullName` (min 2 / max 80), `businessName` (optional / max 120), `email` (zod email), `whatsapp` (optional / max 40), `service` (`z.enum(CONTACT_FORM_SERVICES)`), `budget` (`z.enum(BUDGET_RANGES)`), `timeline` (`z.enum(TIMELINE_OPTIONS)`), `description` (min 30 / max 4000), `company_website` (honeypot — accepts any string; server silently rejects).
  - Exports `ACCEPTED_FILE_TYPES` (pdf + png/jpg/jpeg/webp/gif) and `MAX_FILE_BYTES` (5MB) and `ContactApiResult` discriminated union.
  - IMPORTANT: zod v4 dropped `errorMap` on `z.enum` in favour of `error: string | $ZodErrorMap` — schema uses the new `error: "..."` form.
- Contact API route at `src/app/api/contact/route.ts` (nodejs runtime):
  - `POST`: parses JSON body, runs `contactSchema.safeParse`, returns `{ok:false, errors:[{field,message}[]]}` (422) on validation failure. On success: checks honeypot — silently returns `{ok:true, spam:true}` WITHOUT persisting. Otherwise inserts an `Inquiry` row via `db.inquiry.create` and returns `{ok:true, id}` (200). DB errors return `{ok:false, errors:[{field:'form', ...}]}` (500). File metadata (name/type/size) validated server-side; only the file name is persisted (no actual upload happens).
  - `GET`: 405.
- Portfolio index page (`src/app/portfolio/page.tsx`, server): hero `<SectionHeading>` with `RevealText` highlighting "STAND OUT.", then `<PortfolioFilters>` client grid with `useState` filter + framer-motion `layout` + `AnimatePresence` (popLayout) for smooth re-layout. Pill toggles: All + 6 service categories (active = yellow). Grid is `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6`. Bottom note: "These are illustrative concept projects created to demonstrate our creative approach. Verified client case studies will be added as they become available." Bottom outline CTA "Start a Similar Project" → `/contact`. All items labeled "Concept Project".
- Portfolio detail (`src/app/portfolio/[slug]/page.tsx`, server): `generateStaticParams` from `PORTFOLIO_ITEMS`; async `generateMetadata` per project (title `${item.title} | Portfolio`, description `item.summary`). Hero block → large `aspect-[16/9]` mockup showcase with `<Image src="/portfolio/{slug}.png" fill priority>` over a yellow fallback gradient → Overview (Business Challenge = `item.objective`, Creative Strategy = `item.summary`) → Services pills list → Execution block with generic copy → Deliverables derived from `item.services` → Results block with neutral copy "Results are presented for verified client projects only..." (DOES NOT fabricate metrics) → Related Projects (2 other items via `<PortfolioCard>`) → final CTA "Start a Similar Project" → `/contact`. Wrapped in `<PageShell>`.
  - FIXED: Next.js 16 requires `params` to be unwrapped with `await` (it's a Promise). Both `generateMetadata` and the page default export are now `async` and destructure `{ slug } = await params`.
- Process page (`src/app/process/page.tsx`, server): hero with `<Scene3D kind="home-hero" />` behind. 7-step timeline (`PROCESS_STEPS`) — vertical on mobile, alternating sides on desktop (every other step flipped via `md:flex-row-reverse`), each step wrapped in `<Reveal>`. Each step card has the big yellow `font-poster` number + title + 3 labeled rows ("What you provide", "What we deliver", "Approval needed" highlighted yellow) using `<dl>/<dt>/<dd>`. Project checklist card (new client component `src/components/site/project-checklist.tsx`) — 7 prep items with toggleable check state + "Print Checklist" button calling `window.print()`. Final CTAs "Start a Project" → `/contact` + "See Pricing" → `/pricing`.
- Pricing page (`src/app/pricing/page.tsx`, server): hero `RevealText` "CLEAR PRICING. NO SURPRISES." (highlighted "NO SURPRISES."). Transparent pricing note verbatim. Client `PricingFilter` component (`src/components/site/pricing-filter.tsx`): pill toggles (ALL + 6 services); desktop renders one section per service with 3 `<PricingCard>` in `md:grid-cols-3`; mobile collapses into shadcn `<Accordion>` (collapsed summary = service title + starting price; expanded = 3 cards). Cadence badge computed from `pkg.cadence` — MONTHLY for social-media-marketing & digital-marketing, ONE-TIME PROJECT for the rest. Each service section shows a "Scope Note" callout rendering `service.exclusions`. Bottom CTA "Don't see a fit?" + "Get a Custom Quote" → `/contact`.
- Contact page (`src/app/contact/page.tsx`, server): split-screen desktop (left text + `<Scene3D kind="cta" />` behind in column, right form); stacked on mobile. Left: `RevealText` "LET'S BUILD SOMETHING THAT MATTERS." (highlight "MATTERS."), supporting copy, contact info rows (email `hello@kyvroxa.com`, phone `+92 000 000 0000`, location "Pakistan"), caption "Verified contact details will replace these placeholders once published." Right: `<ContactForm />` client component (`src/components/site/contact-form.tsx`) using `react-hook-form` + `zodResolver(contactSchema)`. All fields wrapped in accessible `<Label>` + error `<p role="alert">`. Yellow focus rings via `--ring` token (already wired in globals.css). Honeypot `company_website` field is rendered off-screen (`absolute -left-[9999px]`), tabIndex=-1. Submit POSTs to `/api/contact`; success state replaces the form with a yellow `<Check>` circle, "Message received" heading, supporting copy, and "Back to Home" button → `/`. Sonner toast on success + per-field error toasts on failure. Optional file upload (PDF/images, 5MB max) — client-side type/size validation + server-side re-validation; only metadata (file name) is sent (no actual bytes uploaded).
- Custom 404 (`src/app/not-found.tsx`): branded — `<LogoSymbol>` KC monogram, huge yellow "404" in `font-poster` (28vw on mobile scaling down to 20rem on lg), "PAGE NOT FOUND" heading, "The page you're looking for doesn't exist or has moved." text, "Back to Home" button → `/`, secondary "Report an issue" link → `/contact`. Centered, full viewport height, `<Scene3D kind="cta" />` behind at 40% opacity. Wrapped in `<PageShell topPad={false}>`. Was not previously created — no duplicate.
- SEO files:
  - `src/app/sitemap.ts` — `MetadataRoute.Sitemap` listing all 23 routes (home, about, services index, 6 service pages, portfolio index, 6 portfolio detail pages, process, pricing, contact) using `BASE_URL = "https://kyvroxa.com"` and dynamic per-route priority.
  - `src/app/robots.ts` — `MetadataRoute.Robots` allowing "/", disallowing "/api/", with sitemap reference `${BASE_URL}/sitemap.xml`.

Verification:
- `bun run db:push` — schema synced, Inquiry model created.
- `bun run lint` — clean (0 errors, 0 warnings).
- `bun x tsc --noEmit` — clean for all `src/**` code (only pre-existing examples/skills errors remain outside our scope).
- End-to-end API tests via curl:
  - valid payload → 200 `{ok:true, id:"cmvj..."}` (row persisted, verified via Prisma client).
  - invalid payload (missing fields, bad email, short description) → 422 with per-field `errors` array.
  - honeypot filled → 200 `{ok:true, spam:true}` (NO row inserted).
  - unsupported file type → 422 `{errors:[{field:'file', message:'Unsupported file type...'}]}`.
  - oversized file (5MB+) → 422 `{errors:[{field:'file', message:'File exceeds the 5MB limit.'}]}`.
  - malformed JSON → 422 `{errors:[{field:'form', message:'Invalid request body.'}]}`.
- All routes return 200 in dev: `/portfolio`, `/process`, `/pricing`, `/contact`, `/portfolio/{slug}` (all 6 items), `/sitemap.xml`, `/robots.txt`. Missing routes return 404 rendered by the branded custom not-found page (verified "font-poster" + "404" markers in HTML).

Decisions / Notes:
- `useWatch` used instead of `watch()` in the ContactForm to avoid the React Compiler "incompatible library" warning emitted by `watch()`.
- Honeypot field accepts any string in the schema (so bots that fill it don't trip a 422) — the API server checks it post-validation and silently drops with `{ok:true, spam:true}`.
- Pricing cards reuse the existing `<PricingCard pkg={pkg} />` from R-COMP — no duplication.
- Portfolio detail's `notFound()` is called when `item` is undefined; TypeScript narrows `item` to defined afterwards because `notFound()` returns `never`.
- Used `motion.create(Link)` (already in Button) so all our pages simply import the shared `<Button href="..." />` for navigation CTAs.
- Print Checklist uses `window.print()` — wrapped in `typeof window !== "undefined"` guard. The whole `ProjectChecklist` is a client component; the rest of the Process page is server.

Stage Summary:
- All 4 public pages + portfolio detail (slug) + contact API + shared zod schema + Inquiry Prisma model + custom 404 + sitemap/robots are live and verified. Downstream agents can rely on:
  - `contactSchema` from `@/lib/validations/contact` for any other contact-shaped forms.
  - The `Inquiry` Prisma model for any analytics/lead dashboard.
  - The branded 404 catching any unmatched route automatically.
