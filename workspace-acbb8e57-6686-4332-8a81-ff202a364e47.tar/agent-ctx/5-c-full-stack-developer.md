# Task 5-c — Portfolio, Process, Pricing, Contact + 404

**Agent:** full-stack-developer
**Task:** Build the Portfolio (index + detail), Process, Pricing, Contact (+ form backend API), and a custom 404 page for KYVROXA Creatives.

## Files Built
- `prisma/schema.prisma` — appended `Inquiry` model
- `src/lib/validations/contact.ts` — shared zod schema (also used by the form)
- `src/app/api/contact/route.ts` — POST Route Handler that validates + persists
- `src/components/site/portfolio-filters.tsx` — filterable portfolio grid (client)
- `src/app/portfolio/page.tsx` — Portfolio index (server)
- `src/app/portfolio/[slug]/page.tsx` — Portfolio detail (server, generateStaticParams + generateMetadata)
- `src/components/site/process-timeline.tsx` — scroll-driven 7-step timeline (client)
- `src/components/site/project-checklist.tsx` — printable project checklist (client)
- `src/app/process/page.tsx` — Process page (server)
- `src/components/site/pricing-filter.tsx` — service filter + desktop grid + mobile accordion (client)
- `src/app/pricing/page.tsx` — Pricing page (server)
- `src/components/site/contact-form.tsx` — react-hook-form + zod form (client)
- `src/app/contact/page.tsx` — Contact page (server, split-screen layout)
- `src/app/not-found.tsx` — branded 404 page
- Barrel: `src/components/site/index.ts` — added new exports

## Prisma Model
```prisma
model Inquiry {
  id           String   @id @default(cuid())
  fullName     String
  businessName String?
  email        String
  whatsapp     String?
  service      String
  budget       String?
  timeline     String?
  description  String
  fileName     String?
  honeypot     String?
  createdAt    DateTime @default(now())
}
```

## Zod Schema Shape
- `fullName`: 2–100 chars, required
- `businessName`: optional, ≤100 chars
- `email`: required, valid email
- `whatsapp`: optional, ≤40 chars
- `service`: enum of CONTACT_FORM_SERVICES (required)
- `budget`: enum of BUDGET_RANGES (required)
- `timeline`: enum of TIMELINE_OPTIONS (required)
- `description`: 30–4000 chars, required
- `fileName`: optional, ≤255 chars (we record filename only — no binary upload)
- `company_website`: honeypot, accepts any string ≤255 chars. The API silently accepts (`{ok:true, spam:true}`) without persisting if filled.

## API Route Shape (`POST /api/contact`)
- Reads JSON body
- Parses with shared `contactSchema`
- On validation failure: 422 with `{ ok: false, error: "Validation failed.", fieldErrors }`
- Honeypot filled: returns 200 `{ ok: true, spam: true }` and does NOT persist
- On DB error: 500 with `{ ok: false, error: "<message>" }` — the client form then shows the error state
- On success: 200 `{ ok: true }`
- GET returns 405

## Verification Done
- `bun run db:push` ran cleanly (Prisma client regenerated)
- `bun run lint` passes with zero errors/warnings
- All routes verified via curl:
  - `/portfolio` → 200
  - `/portfolio/vertex-brand-identity` → 200 (static param generation)
  - `/process` → 200
  - `/pricing` → 200
  - `/contact` → 200
  - `/non-existent-route` → 404 (custom not-found)
- POST `/api/contact` end-to-end verified:
  - Valid payload → `{ ok: true }`, persisted to `Inquiry` table (verified with `prisma.inquiry.findMany()`)
  - Empty payload → 422 with fieldErrors
  - Honeypot filled → `{ ok: true, spam: true }`, no DB row inserted (verified with `prisma.inquiry.count()`)

## Notes
- Did NOT modify `site-data.ts` or existing components — only consumed.
- No fabricated client testimonials, results, or business metrics anywhere.
- All portfolio items shown as `Concept Project`; the detail page renders a neutral "Results are presented for verified client projects only" block — no fabricated metrics.
- Contact info placeholders (`hello@kyvroxa.com`, `+92 000 000 0000`, `Pakistan`) are clearly marked as unverified.
- Form uses `react-hook-form` + `zodResolver`, shadcn Input/Textarea/Select/Label, with yellow focus rings (via `--ring` global).
- After successful submit, the form is replaced with a success state (yellow check, "Message received", Back to Home button) + a sonner toast.
- Process checklist includes a Print Checklist button that calls `window.print()`.
- Mobile pricing uses shadcn Accordion; desktop shows all services expanded.
