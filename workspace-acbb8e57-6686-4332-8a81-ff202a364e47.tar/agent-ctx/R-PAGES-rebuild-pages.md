# R-PAGES — Rebuild Portfolio / Process / Pricing / Contact Pages + 404 + SEO

Agent: rebuild-pages
Task ID: R-PAGES
Predecessor tasks read: 1, R-COMP

## Files Built
- `src/app/portfolio/page.tsx` (server)
- `src/app/portfolio/[slug]/page.tsx` (server — async, awaits params)
- `src/components/site/portfolio-filters.tsx` (client — pill toggles + framer-motion layout/AnimatePresence)
- `src/app/process/page.tsx` (server)
- `src/components/site/project-checklist.tsx` (client — 7-item checklist + print button via `window.print()`)
- `src/app/pricing/page.tsx` (server)
- `src/components/site/pricing-filter.tsx` (client — pill toggles + desktop 3-card grid OR mobile shadcn Accordion)
- `src/app/contact/page.tsx` (server — split-screen desktop)
- `src/components/site/contact-form.tsx` (client — react-hook-form + zod + sonner + honeypot)
- `src/app/api/contact/route.ts` (POST Route Handler, nodejs runtime)
- `src/lib/validations/contact.ts` (shared zod schema)
- `src/app/not-found.tsx` (custom branded 404)
- `src/app/sitemap.ts` (23 routes)
- `src/app/robots.ts` (allow /, disallow /api/, sitemap ref)
- `prisma/schema.prisma` (APPENDED Inquiry model; existing User + Post untouched)

## Prisma Inquiry Model
```prisma
model Inquiry {
  id           String   @id @default(cuid())
  fullName     String
  businessName String?
  email        String
  whatsapp     String?
  service      String
  budget       String
  timeline     String
  description  String
  fileName     String?
  honeypot     String?
  createdAt    DateTime @default(now())
}
```

## Zod Schema Shape
`contactSchema`:
- `fullName` — min 2 / max 80
- `businessName` — optional, max 120
- `email` — `z.string().email()`
- `whatsapp` — optional, max 40
- `service` — `z.enum(CONTACT_FORM_SERVICES, { error: "Please choose a service." })`
- `budget` — `z.enum(BUDGET_RANGES, { error: "Please select a budget range." })`
- `timeline` — `z.enum(TIMELINE_OPTIONS, { error: "Please select a timeline." })`
- `description` — min 30 / max 4000
- `company_website` — honeypot, accepts any string (silently rejected server-side)

Exports `ACCEPTED_FILE_TYPES`, `MAX_FILE_BYTES` (5MB), `ContactApiResult` discriminated union.

Note: zod v4 changed `z.enum`'s param — `errorMap` is gone, use `error: string | $ZodErrorMap`.

## API Route Behaviour
`POST /api/contact`:
- 422 `{ok:false, errors:[{field,message}[]]}` — invalid JSON body OR validation failure
- 200 `{ok:true, spam:true}` — honeypot filled (NO row inserted)
- 200 `{ok:true, id}` — inserted Inquiry row via `db.inquiry.create`
- 422 `{ok:false, errors:[{field:'file', ...}]}` — unsupported file type OR > 5MB (only metadata is sent; no actual upload happens)
- 500 `{ok:false, errors:[{field:'form', message:'We couldn't save your message...'}]}` — DB failure (logged, error not exposed)

`GET /api/contact` → 405.

## Verification
- `bun run db:push` — synced.
- `bun run lint` — clean (0 errors, 0 warnings).
- `bun x tsc --noEmit` — clean for `src/**` (only pre-existing examples/skills errors remain outside scope).
- All routes return 200: `/portfolio`, `/process`, `/pricing`, `/contact`, `/portfolio/{6 slugs}`, `/sitemap.xml`, `/robots.txt`.
- Custom 404 catches missing routes (verified HTML contains `font-poster` + `404`).
- Contact API tested end-to-end with valid / invalid / honeypot / bad-file-type / oversized-file / malformed-JSON payloads — all return the documented response.

## Decisions / Notes
- `useWatch` (RHF) used instead of `watch()` to avoid React Compiler "incompatible library" warning.
- Portfolio detail page is `async` because Next.js 16 makes `params` a Promise — must `await params` before reading `.slug`.
- Honeypot accepts any string in schema (bots that fill it don't trip a 422). Server silently drops with `{ok:true, spam:true}`.
- Pricing cards reuse the shared R-COMP `<PricingCard pkg={pkg} />` — no duplication.
- The print button on the Process page is a small client component (`ProjectChecklist`); the rest of the page is server.
- All pages wrap content in `<PageShell>` for sticky footer + fixed header + scroll progress.
