# Task R-COMP — Shared Component Library (Rebuild)

**Agent:** R-COMP (rebuild-components)
**Date:** Rebuild phase, after Tasks 1–3 (foundation)
**Status:** ✅ Complete

## Scope
Rebuilt the entire KYVROXA Creatives shared component library in
`src/components/site/`. 16 files total (15 components + 1 barrel file).

## Files Built
- `src/components/site/logo.tsx` — `Logo` (sm/md/lg via next/image + logo.png) +
  `LogoSymbol` (48x48 SVG KC monogram for Scene3D plate).
- `src/components/site/button.tsx` — client component, 5 variants
  (primary/outline/ghost/white/dark) × 3 sizes, optional `magnetic` cursor
  pull using framer-motion `useMotionValue` + `useSpring`, optional `href`
  renders as a Next.js `<Link>` (via hoisted `motion.create(Link)`).
- `src/components/site/reveal.tsx` — client. `Reveal` (fade-up on in-view),
  `RevealText` (word-by-word stagger w/ highlight words),
  `Eyebrow` (yellow dot + label), `SectionHeading` (composer).
- `src/components/site/capabilities-ticker.tsx` — seamless marquee of
  CAPABILITIES with yellow dot separators + edge fade gradients.
- `src/components/site/back-to-top.tsx` — yellow circular floating button,
  appears after 600px scroll, smooth scroll-to-top, AnimatePresence.
- `src/components/site/scroll-progress.tsx` — thin yellow top bar,
  `useScroll` + `useSpring`.
- `src/components/site/header.tsx` — fixed top nav, transparent →
  `bg-brand-black/80 backdrop-blur-xl` on scroll, 7 NAV_LINKS,
  Services hover mega-menu (6 services, 2-col grid), mobile hamburger
  drawer with all nav + all 6 services. Body-scroll lock when open.
- `src/components/site/footer.tsx` — 4-column (Brand / Services / Studio
  w/ Privacy+Terms / CTA block). Top accent gradient line, bottom strip
  with copyright + Pakistan + "Available for select projects". Sticky via
  parent's flex (`mt-auto`).
- `src/components/site/scene-3d.tsx` — client. Mouse-reactive perspective
  tilt container + 5 primitives (ChromeSphere, FloatingRing, FloatingCube,
  WireframeShape, MonogramPlate) + 9 scene kinds (home-hero, canvases,
  screens, phone, timeline, network, dashboard, cta, about). All
  `aria-hidden="true"`, `interactive` prop default true. NO Three.js —
  pure CSS + SVG + framer-motion for sandbox reliability.
- `src/components/site/pricing-card.tsx` — server component, popular
  highlight (yellow border + glow + badge), yellow check icons, CTA.
- `src/components/site/service-card.tsx` — server, UNIFORM grid card
  (no asymmetric bug), number 01-06, title, tagline, 3 deliverable pills,
  "Explore Service" link, hover yellow border + sweep + scale cube accent.
  Uses `h-full` to fill grid cell.
- `src/components/site/portfolio-card.tsx` — server, 4/3 aspect image via
  `<Image src="/portfolio/{slug}.png">`, status badge top-left, arrow
  top-right, category (yellow), title, summary (line-clamp-2),
  3 service pills. Hover scale 1.05 + yellow border.
- `src/components/site/faq-list.tsx` — client. shadcn/ui Accordion wrapper.
  Single-open, default first item open.
- `src/components/site/page-shell.tsx` — server. ScrollProgress + Header +
  main (`flex-1`, `pt-16` when `topPad`) + Footer (`mt-auto`) + BackToTop.
  `min-h-screen flex flex-col` for sticky footer.
- `src/components/site/structured-data.tsx` — server. JSON-LD for
  Organization + WebSite + BreadcrumbList + 6 Service schemas. Logo URL
  `https://kyvroxa.com/logo.png`.
- `src/components/site/index.ts` — barrel re-exports.

## Decisions / Notes
1. **`motion.create(Link)`** used instead of `motion(Link)` (in-render
   creation lint rule) — hoisted `MotionLink` outside `Button`.
2. **Conflicting DOM handlers omitted** from `ButtonProps` (onDrag,
   onDragStart, onDragEnd, onAnimationStart/Iteration/End,
   onTransitionEnd) to keep `motion.button` spread type-safe.
3. **`NAV_LINKS` is `as const`** — used `"hasMegaMenu" in link` check in
   header, and `map<StudioLink>` cast in footer to allow Privacy/Terms
   extensions without breaking the literal union.
4. **Scene3D primitives kept as named internal functions** (not exported)
   to keep the public API minimal (only `Scene3D` + `Scene3DKind` exported).
5. **No Three.js** — all 9 scenes built with CSS gradients, SVG wireframes,
   and framer-motion transforms for sandbox reliability.
6. **LogoSymbol** drawn as a single 48x48 SVG: K stem (white rect) + two
   K diagonals (white paths) + yellow accent dot + C curve (yellow stroke).
7. **Footer** uses `mt-auto` on the `<footer>` element directly so it works
   whether the parent is `min-h-screen flex flex-col` (PageShell) or any
   other flex-column wrapper.
8. **PricingCard** uses `Link` with `href` ctaHref param defaulting to
   `/contact` so it can be reused on a service-specific page (passing
   the service's hash) without code changes.

## Verification
- `bun run lint` → ✅ clean (0 errors, 0 warnings)
- `bun x tsc --noEmit` → ✅ clean for all `src/components/site/*` files
  (only unrelated files in `examples/`, `skills/` produced errors)
- Dev server (`bun run dev`) on port 3000 → recompiles cleanly on HMR,
  no errors in `dev.log`

## Downstream usage
Page builders can:
```ts
import {
  PageShell, Header, Footer, Logo, Button, Reveal, RevealText,
  Eyebrow, SectionHeading, CapabilitiesTicker, BackToTop,
  ScrollProgress, Scene3D, PricingCard, ServiceCard, PortfolioCard,
  FaqList, StructuredData,
} from "@/components/site";
```

`Scene3D` accepts `kind` of: home-hero | canvases | screens | phone |
timeline | network | dashboard | cta | about — these match each
`SERVICES[i].heroVisual` value plus the home/cta/about special scenes.

`ServiceCard` and `PricingCard` are server components — safe to drop into
server-rendered route segments.

`FaqList`, `Button`, `Reveal`, `Scene3D`, `CapabilitiesTicker`,
`BackToTop`, `ScrollProgress`, `Header` are client components — they
already carry `"use client"`.
