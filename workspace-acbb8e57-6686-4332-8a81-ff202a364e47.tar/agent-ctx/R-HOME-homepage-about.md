# Task R-HOME — Homepage + About Page (Rebuild)

**Agent:** R-HOME
**Date:** Rebuild phase, after R-COMP (shared components)
**Status:** ✅ Complete

## Scope
Rebuilt the homepage (`/`) and About page (`/about`) for the KYVROXA
Creatives premium agency website. 9 new files + 1 replaced file.

## Files Built
- `src/app/page.tsx` — server component, renders
  `<PageShell topPad={false}><StructuredData /><HomeClient /></PageShell>`.
  `topPad={false}` so the hero starts at the very top of the viewport
  (header is fixed/transparent and overlays the hero).
- `src/components/site/sections/home-client.tsx` — client composer that
  stacks the 7 homepage sections in order.
- `src/components/site/sections/home-hero.tsx` — full-screen hero.
- `src/components/site/sections/services-overview.tsx` — uniform 3-col grid.
- `src/components/site/sections/featured-portfolio.tsx` — first 3 portfolio cards.
- `src/components/site/sections/why-kyvroxa.tsx` — 6 differentiator cards w/
  count-up Anton numbers + scroll-progress line.
- `src/components/site/sections/process-preview.tsx` — inline 5-step local
  timeline (NOT from PROCESS_STEPS which is 7-step).
- `src/components/site/sections/testimonials-placeholder.tsx` — single
  neutral placeholder card, NO fabricated names/quotes/photos.
- `src/components/site/sections/final-cta.tsx` — dramatic black CTA with
  `<Scene3D kind="cta" />` backdrop.
- `src/app/about/page.tsx` — server component, `export const metadata`.
  6 sections: split-screen hero, Mission+Vision, Core Values grid,
  Founder placeholder, Approach explanation, CTA.

## Decisions / Notes

### HomeHero (`home-hero.tsx`)
1. **Anton mixed small+big typography headline** centered and stacked:
   - small gray `.font-display` tracking-[0.4em] — "We Turn"
   - big white `.font-poster` clamp(2.75rem, 11vw, 9.5rem) — "Creative Ideas"
   - small gray — "Into"
   - big yellow — "Digital Impact."
   Each line is its own motion.span with a staggered entrance (y + opacity).
2. **Solid black bg** with `.bg-grid` opacity-70 + `.bg-spotlight` + an
   extra radial vignette to focus the eye center.
3. **Availability chip** at top with a pulsing yellow dot (motion.span
   animating opacity+scale + boxShadow glow).
4. **4 yellow sparkles** (4-pointed SVG star path) with breathing opacity
   + scale + rotate loop, scattered in the four corners.
5. **Bottom yellow strip** marquee uses SERVICES data (`shortName`),
   duplicated for seamless loop, `.animate-marquee` utility, black text
   on yellow bg with black dot separators.
6. **Single yellow CTA** "Explore Our Services" → `/services/graphic-designing`
   via `<Button variant="primary" size="lg" magnetic>`. NO male image,
   NO contact icon button (removed in earlier iterations as instructed).

### WhyKyvroxa count-up animation
1. Used `useInView` + `useMotionValue` + `useSpring` + `animate` from
   framer-motion to count from 0 → (index+1) when the number scrolls into
   view. Display always pads to 2 digits ("00" → "01", "02", ... "06").
2. Numbers use `.font-poster` (Anton) at `text-5xl/6xl/7xl` with
   `WebkitTextStroke: 1.5px var(--color-brand-yellow)` and `color: transparent`
   so they appear outlined (yellow stroke on transparent fill). On
   `group-hover` the text color flips to `text-brand-yellow` (solid fill).
3. `aria-label` carries the actual number for screen readers since the
   visible content is the animated string.
4. **Hover micro-interactions** per card: lift `y: -4`, yellow left
   accent bar grows (`scale-y-0 → 100` origin top), and a shine sweep
   gradient (`-translate-x-full → translate-x-full`).
5. **Staggered entrance** via parent `motion.div` variants:
   `staggerChildren: 0.12, delayChildren: 0.06` (the spec asked for
   `delayChildren: i*0.06` per card — interpreted as the start of the
   stagger which itself produces per-item offsets).
6. **Left-edge vertical scroll progress line** via `useScroll({ target:
   sectionRef, offset: ["start end","end start"] })` + `useSpring` +
   `useTransform` scaleY. Hidden on mobile (only `md:block`).

### ProcessPreview
1. 5 steps written **inline** in the file: Discover, Strategize, Create,
   Refine, Deliver & Improve (NOT imported from `PROCESS_STEPS` which is
   the 7-step agency-side process).
2. **Desktop**: horizontal timeline with a yellow connecting line via
   `bg-gradient-to-r from-transparent via-brand-yellow/40 to-transparent`
   and 5 yellow dots laid out via a flex justify-between overlay.
3. **Mobile**: vertical timeline with per-step yellow dot + line.
4. Each step: big yellow `.font-poster` number (3xl/4xl), title, one-line
   description.

### TestimonialsPlaceholder
1. Single neutral card with a yellow Quote lucide icon in a yellow-tinted
   circle. Copy is the brief's exact placeholder text — "Verified client
   testimonials will appear here. KYVROXA Creatives only publishes feedback
   from confirmed clients — contact us to share yours."
2. NO fabricated names, photos, or quotes (per instructions).

### FinalCta
1. `<Scene3D kind="cta" interactive={false} />` rendered behind content in
   a pointer-events-none absolute layer + a radial dark veil for
   legibility.
2. `<RevealText text="YOUR NEXT BIG IDEA STARTS HERE." highlightWords={["HERE."]} />`.
3. Two buttons: primary "Start a Project" → `/contact`, outline
   "Explore Pricing" → `/pricing`.

### About page (`src/app/about/page.tsx`)
1. **Server component** with `export const metadata = { title: "About Us",
   description, openGraph }`.
2. **Six sections** as specified in the brief:
   - Split-screen hero (left text + right `<Scene3D kind="about" />` in a
     600px max container, aspect-square).
   - Mission + Vision two-column (Mission copy is verbatim from brief;
     Vision is a tasteful forward-looking paragraph in brand voice —
     "long-term partner, not one-off vendor", "build systems, not
     one-offs").
   - Core values grid: 5 from `COMPANY_VALUES` with `01`-`05` Anton
     numbers + yellow accent bar that grows on hover.
   - Founder section: clearly-labeled editable placeholder — yellow
     circle with `<LogoSymbol>` KC monogram + "Placeholder" pill,
     italic gray "Founder Name" + "Founder & Creative Lead — to be
     published", and verbatim "Founder biography will appear here once
     published." + a second explicit note that no information has been
     fabricated. NO real name, photo, or bio invented.
   - Approach explanation: 3 concise paragraphs (brief-first, milestone
     rhythm, success criteria).
   - CTA: primary "Explore Services" → `/services/graphic-designing`
     + outline "Discuss a Project" → `/contact`.
3. Every block wrapped in `<Reveal>` for staggered entrance.
4. Wrapped in `<PageShell>` so sticky footer + fixed header + scroll
   progress + back-to-top come for free.

### Code quality
- TypeScript strict, no `any`.
- `'use client'` on all 7 homepage section files (they use framer-motion
  hooks). `home-client.tsx` is also client. `home-hero.tsx`'s helper
  sub-components (Sparkle, ServicesMarquee) stay inside the same client
  module.
- About page is a server component — but it imports client components
  (Reveal, RevealText, Eyebrow, Button, Scene3D, LogoSymbol). Next.js
  handles the boundary correctly; this is the standard server→client
  composition pattern.
- Mobile-first responsive throughout. All grids collapse to 1-col on
  mobile.

## Verification
- `bun run lint` → ✅ exit 0, 0 errors, 0 warnings.
- `bun x tsc --noEmit` → ✅ no errors in any of the new files (the only
  errors reported are in unrelated `examples/`, `skills/`, and
  `src/lib/validations/contact.ts` which are out of scope for this task).
- Dev server on port 3000 (already running) recompiles cleanly on HMR.
- `curl http://localhost:3000/` → **200** with hero content rendered
  ("We Turn", "Creative Ideas", "Into", "Digital Impact" all present).
- `curl http://localhost:3000/about` → **200** with "CREATIVITY WITH A
  CLEAR DIRECTION", "Our Mission", "Our Vision", "CORE VALUES",
  "Founder Name" all rendered.

## Downstream usage
- Homepage route (`/`) is fully wired. Other routes (`/services`, `/portfolio`,
  `/process`, `/pricing`, `/contact`) are handled by other agents — only
  the homepage and About page were built here.
- `HomeClient` and all section components live under
  `src/components/site/sections/`. They import from `@/components/site`
  (barrel) and `@/lib/site-data` per the project conventions.
- PageShell's `topPad={false}` on the homepage lets the hero start at the
  top of the viewport — the fixed transparent header overlays it cleanly.
  About page uses default `topPad={true}` so its content clears the header.

## Files NOT touched (per task constraints)
- `src/lib/site-data.ts` — unchanged.
- All shared components in `src/components/site/*` (R-COMP scope) — unchanged.
- No new packages installed. No Three.js. No tests written. No `bun run build`.
