// Seed realistic testimonials for KYVROXA Creatives.
// Run: `bun run scripts/seed-testimonials.ts`
//
// Client NAMES stay the same across reseedings so cards stay recognizable.
// DESIGNATIONS and COMPANY NAMES are intentionally random + fictional — they
// don't map to any real registered company. This keeps the demo testimonials
// believable without misrepresenting real businesses.
//
// Rating 4–5 = positive; rating 1–3 = "negative" feedback (admin can remove).

import { db } from "../src/lib/db";

// Names stay stable; designations + companies are randomized per reseed.
const PEOPLE: { name: string }[] = [
  { name: "Ayesha Khan" },
  { name: "Bilal Ahmed" },
  { name: "Sara Malik" },
  { name: "Hamza Raza" },
  { name: "Mahnoor Tariq" },
  { name: "Usman Sheikh" },
  { name: "Anonymous Client" },
  { name: "Imran Faisal" },
];

// Pool of fictional, distinctive company names — none of these are real
// registered companies (intentionally invented wordmarks).
const COMPANIES: string[] = [
  "Lumira Collective",
  "Northbeam Commerce",
  "Velnord Studio",
  "Pulsara Systems",
  "Horizonloop Labs",
  "Atellan Group",
  "Brightpath Media",
  "Ceder & Co",
  "Quovex Digital",
  "Marlowe Studio",
  "Veridian Works",
  "Asterly House",
];

// Pool of believable, varied designations.
const DESIGNATIONS: string[] = [
  "Founder & CEO",
  "Creative Director",
  "Head of Brand",
  "Marketing Lead",
  "Growth Strategist",
  "Product Lead",
  "Operations Manager",
  "Brand Strategist",
  "Digital Lead",
  "Design Partner",
  "VP Marketing",
  "Studio Director",
];

// Believable testimonial content (positive + 2 negative).
// We pair content + rating to the names by index.
const CONTENT_BY_INDEX: { content: string; rating: number }[] = [
  {
    content:
      "KYVROXA rebuilt our brand identity from scratch. The new visual system finally matches the ambition of the product — we've never looked more credible.",
    rating: 5,
  },
  {
    content:
      "The paid acquisition pilot paid for itself in the first three weeks. Clean campaign architecture, disciplined creative testing, transparent reporting throughout.",
    rating: 5,
  },
  {
    content:
      "Our social media finally feels like us. Calm, intentional, on-brand across every post. KYVROXA understood the voice we'd been chasing for two years.",
    rating: 5,
  },
  {
    content:
      "The mobile app screens were delivered ahead of schedule with a complete design system. Engineering handoff was the cleanest we've ever received.",
    rating: 4,
  },
  {
    content:
      "We went from a cluttered legacy site to a focused conversion platform. Lead form submissions are up and the homepage actually communicates what we do.",
    rating: 5,
  },
  {
    content:
      "The motion graphics system KYVROXA built travels cleanly across every surface — product, social, ads. It's become our most reused creative asset.",
    rating: 5,
  },
  // --- 2 negative testimonials (rating 1-3) — admin can remove these ---
  {
    content:
      "Communication was inconsistent during the middle stretch of the project. The final deliverables were good, but the timeline slipped twice without proactive updates.",
    rating: 2,
  },
  {
    content:
      "The creative direction was solid but revision rounds went by faster than expected. Felt like there wasn't enough room to give proper feedback before the next version arrived.",
    rating: 3,
  },
];

// Deterministic-ish shuffle so a single run doesn't repeat a company twice
// but stays random enough that no two reseeds give the same combo.
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function seed() {
  await db.testimonial.deleteMany({});
  console.log("Cleared existing testimonials.");

  // Shuffle once per run so each reseed gives a fresh, internally-unique
  // pairing of (person × designation × company).
  const shuffledCompanies = shuffle(COMPANIES);
  const shuffledDesignations = shuffle(DESIGNATIONS);

  for (let i = 0; i < PEOPLE.length; i++) {
    const person = PEOPLE[i];
    const { content, rating } = CONTENT_BY_INDEX[i];

    // Keep "Anonymous Client" + "Confidential" pairing for the negative anon
    // review so it reads naturally; everyone else gets a random company +
    // designation combo that no other card in this run shares.
    const isAnonymous = person.name === "Anonymous Client";
    const company = isAnonymous
      ? "Confidential"
      : shuffledCompanies[i % shuffledCompanies.length];
    const designation = isAnonymous
      ? "Operations"
      : shuffledDesignations[i % shuffledDesignations.length];

    await db.testimonial.create({
      data: {
        name: person.name,
        role: designation,
        company,
        content,
        rating,
      },
    });
    console.log(
      `  ${i + 1}. ${person.name} — ${designation} @ ${company} (rating ${rating})`,
    );
  }

  const count = await db.testimonial.count();
  console.log(`\nInserted ${count} testimonials.`);
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => process.exit(0));
